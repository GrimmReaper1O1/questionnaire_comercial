<?php 
include '../includes/header4.php';
if ($administrator['admin'] == 1) {
	$enter = 0;
$id = $_GET['id'] ?? 'no';

foreach($_SESSION['subjectsFromPage'] as $subject) {
	if ($subject['live'] == 0 && $subject['table_id'] == $id) {
		$enter = 1;
		}
	}

if ($enter == 1 || $administrator['root'] == 1) {
if ($id != 'no') {
	$result = $cms->getQuestions()->deleteAllEntriesFromQuesitonInformation($id);
	$result2 = $cms->getQuestions()->deleteQuestionIds($id);
	$result3 = $cms->getQuestions()->updateSubjectsTable($id);
	if ($result > 0) {
		echo "<h4>ALL ENTRIES WERE DELETED FROM THE QUESTION INFORMATION TABLE IN SUBJECT!</h4><br>";
	} else {
		echo "<h4>THERE WAS A PROBLEM DELETING THE QUESTION INFORMAITON FROM THE TABLE.<br>PLEASE TRY AGAIN.</h4>";
	}
	if ($result2 > 0) {
		echo "<h4>ALL QUESTION DESCRIPTIONS WERE DELETED!</h4><br>";
	} else {
		echo "<h4>THERE WAS A PROBLEM DELETING THE QUESTION DESCRIPTIONS.<br>PLEASE TRY AGAIN.</h4>";
	}
    if ($result3 > 0) {
		echo "<h4>ALL SUBJECTS WERE RESET TO EMPTY!</h4><br>";
	} else {
		echo "<h4>THERE WAS A PROBLEM UPDATING THE SUBJECTS TO EMPTY. <br>PLEASE TRY AGAIN.</h4>";
	}
}
?>
<br><a href="adminSubjectsAndQuestionClassifications.php">CLICK HERE TO GO BACK TO THE ADMINISTRATIVE SUBJECTS PAGE!</a>
<?php 
} else { 
	header("Location: adminSubjectsAndQuestionClassifications.php");
	exit();
}
} else {
    header("Location: how_dare_you.php");
    exit();
}