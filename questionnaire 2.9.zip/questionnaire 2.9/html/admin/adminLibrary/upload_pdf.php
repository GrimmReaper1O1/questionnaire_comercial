<?php
include '../../includes/header5.php';
if ($administrator['root'] == 1) {
$error = '';
$error2 = '';
$message = '';
if(isset($_SESSION['class'])) {
	
	$class = $_SESSION['class'];
} else {
	$class = 'empty';
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {

$moved = false;
    
	if($class != 'empty' || isset($_POST['ignoreClass'])) {
		
    $upload_path = '../../uploads/';
    $max_size = 2137552 * 3;
    $allowed_types = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',];
    $allowed_exts = ['pdf', 'doc', 'docx',];

      $error2 = ($_FILES['document']['size'] <= $max_size) ? '' : 'Your file is too large. It must be under 2MB';
      $type = mime_content_type($_FILES['document']['tmp_name']);
      $error2 .= in_array($type, $allowed_types) ? '' : 'Your file is of the wrong type. It must be a pdf, doc or docx.';
      $ext = strtolower(pathinfo($_FILES['document']['name'], PATHINFO_EXTENSION));
       $error2 .= in_array($ext, $allowed_exts) ? '' : 'It must have the right file extension.';

       if ($error2 === '') {
        $filename = create_filename($_FILES['document']['name'], $upload_path);
        $destination = $upload_path . $filename;
        $moved = move_uploaded_file($_FILES['document']['tmp_name'], $destination);
		$destination = "../uploads/" . $filename;
		echo "here2";
       }
	   
       if ($moved === true) {
		   echo "here";
		
   try {
if (isset($_POST['ignoreClass'])) {
	        $check = $cms->getLibrary()->insertIntoLibrary($_POST['author'], $_POST['name'], $destination, $_POST['description'], $_SESSION['id'], 0);
		$message .= "Your document updated successfully! ";
} else {
	   
	        $check = $cms->getLibrary()->insertIntoLibrary($_POST['author'], $_POST['name'], $destination, $_POST['description'], $_SESSION['id'], $class);
		$message .= "Your document updated successfully! ";
}
	
	} catch(Exception $e) {
        $error2 .= "We're sorry! There was a problem. Please try again.";
   }   
    
   }
	} else {
		$error .= "YOU WERE NOT IN A CLASS WHEN YOU ENTERED THIS PAGE.";
	}
}

echo $error . $message . '<br>';
if ($message == '' || $error2 != '' || $message != '') {
?>
<p>CLASS MUST BE ENTERED THROUGH EITHER ADMINISTER CLASSES OR CLASSES BEFORE UPLOADING.</p>

<form action="upload_pdf.php" method="POST" enctype="multipart/form-data">
    
	<input type="checkbox" name="ignoreClass"><label for="ignoreClass"> Insert into the main library without class.</label><br>
	<label for="name">Document name:</label>
	<input type="text" name="name"value="<?=  $_POST['name'] ?? '' ?>"><br>
	
    <label for="author">Author:</label>
    <input type="text" size="50" name="author" value="<?= $_POST['author'] ?? '' ?>"><br>
    Description of file:<br>
    <textarea name="description" rows="10" cols="80"> <?= $_POST['description'] ?? '' ?></textarea><br>
    <label for="document">Upload PDF file:</label>
    <input type="file" name="document"><br>
    <input type="submit" name="submit" value="SUBMIT!">
    </form>

    <?php }
	} else {
		header("Location: ../how_dare_you.php");
		exit();
	}