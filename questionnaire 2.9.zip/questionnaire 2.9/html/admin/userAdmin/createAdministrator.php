<?php 

include '../../includes/header5.php';
if ($administrator['root'] == 1) {
	$error = '';
if ($_SERVER['REQUEST_METHOD'] === "POST") {
	$timestamp = strtotime('now');
	
	$row = $cms->getMember()->selectViaEmail($_POST['email']);
	
	if (!isset($_POST['delete'])) {
	 try {
		if (isset($_POST['superUser'])) {
		$superUser = 1;	
		}
		
		
		$cms->getMember()->createAdmin($row['user_id'], $_SESSION['id'], $timestamp, $superUser);
		
		
		
		
		$error .= "THE USER WAS INSERTED INTO THE ADMINISTRATOR TABLE!";
		
	} catch(Exception $e) {
		
		$error .= "THE USER WAS NOT INSERTED INTO THE ADMINISTRATOR TABLE.";
	
	}
	} else { 
		$row = $cms->getMember()->deleteAdmin($row['user_id']);
	if ($row > 0) {
		$error .= "THE ADMINISTRATIVE ACCOUNT WAS DELETED!";
	} else {
		$error .= "THE ADMINISTRATIVE ACCOUNT WAS NOT DELETED.";
	}
	}
	
}
	if ($_SERVER['REQUEST_METHOD'] === 'POST') {
		print_r($_POST['superUser']);
	}

echo $error . "<br><br>";
?>
<form action="createAdministrator.php" method="POST">

<input type="checkbox" name="delete"><label for="delete">DELETE ADMINISTRATIVE ACCOUNT!</label><br>
<input type="checkbox" name="superUser"><label for="superUser">CREATE A SUPER USER!</label><br>


<label for="email">EMAIL:</label><br>
<input type="text" name="email" size="100"><br>
<input type="submit" value="SUBMIT!">
</form>

<?php
include "../../includes/footer.php";
} else {
    header("Location: how_dare_you.php");
    exit();
}