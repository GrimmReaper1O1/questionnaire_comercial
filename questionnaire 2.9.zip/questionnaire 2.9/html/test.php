<?php
	include "../src/bootstrap.php";
	$start = microtime(true);
	if (!isset($_GET['page'])) {
	$_SESSION['page'] = 1;
	} else {
	$_SESSION['page'] = $_GET['page'];
	}

	
	$_SESSION['class'] = 10007;
	$_SESSION['subject'] = 1;
	if (isset($_GET['reset'])) {	
	unset($_SESSION['questionDesc']);
	unset($_SESSION['sortedIds']);
	unset($_SESSION['countedNumberOfQuestionsPerQuestion']);
	unset($_SESSION['rowAndCounter']['counter']);
	unset($_SESSION['cnArray']);
	unset($_SESSION['countOfLoads']);
	unset($_SESSION['numberOfQuestionsOnPage']);
	unset($_SESSION['countOfPageQuestions']);
	unset($_SESSION['pageQuestionIds']);
	unset($_SESSION['pagesQuestionIds']);
	unset($_SESSION['sql']);
	unset($_SESSION['questionIds2']);
	unset($_SESSION['completedLoad']);
	unset($_SESSION['info']);
	unset($_SESSION['numeral']);
	unset($_SESSION['runs']);
	unset($_SESSION['ncl']);
	unset($_SESSION['lc']);
	unset($_SESSION['setFirst']);
	unset($_SESSION['questionLimitNumber']);
	unset($_SESSION['qr']);
	unset($_SESSION['pagesIds']);
	$questionPossition = $cms->getQuestions()->selectSubjectViaTableIdAndClassId();
	$_SESSION['numberOfQuestionsOnPage'] = 2;
	$numeralOfRem = $questionPossition['number_of_removal'];
		$_SESSION['numeralOfRem'] = $numeralOfRem;
		
	}
		
	if (isset($_GET['unset'])) {	
	unset($_SESSION['numberOfQuestionsOnPage']);
	unset($_SESSION['chosenNumbers']);
	unset($_SESSION['rowAndCounter']);
		unset($_SESSION['sortedIds']);
			unset($_SESSION['questionDesc']);
		unset($_SESSION['sortedIds']);
	
	}
	
	$numeralOfRem = $_SESSION['numeralOfRem'];





	

	
	
	
	
	if (isset($_SESSION['page_question_count']) && isset($_POST['submit2'])) {
	for($i = 0; $i < $_SESSION['page_question_count']; $i++) {
		
		for($c = 0; $c < $_SESSION['number_of_questions'] + 1; $c++) {
			if (isset($_POST[$i . 'a' . $c])) {
				echo "<b>Message:</b><br>";
				echo "<p>" . paragraph($_SESSION[$i .'answ' . $c]) . "</p><br>";
				echo "<b>Quesiton:</b><br>";
				echo "<p>" . paragraph($_SESSION[$i .'question']) . "</p><br>";
				echo "<b>Answer chosen:</b><br>";
				echo "<p>" . paragraph($_SESSION[$i .'pa' . $c]) . "</p><br>";
				echo "<b>Hint given:</b><br>";
				if($_SESSION[$i .'hint' . $c] !== "empty") {
				echo "<p>" . paragraph($_SESSION[$i .'hint' . $c]) . "</p><br><br>";
				}
			if ($_SESSION[$i . 'correct'] == 'answ' . $c && isset($_POST[$i . 'a' . $c])) {	
				$_SESSION['question' . $i]++;
						}
					}
				}
			}
			
		}	
		
	
if (isset($_SESSION['numeral2'])) {
for ($i = 0 ; $i < 2 ; $i++) {

	echo "<br>" . $_SESSION['questionId' . $i] . "<br>";
}
}
echo "<br>";

echo "<br><br>";
	$questionDesc = $cms->getQuestions()->selectAllQuestionsFromSubject();

	
	if(!isset($_SESSION['questionDesc'])) {
	$_SESSION['questionDesc'][1] = $cms->getQuestions()->sortArrayViaQuestionInformationAllAtOncePagination($questionDesc[1]);
	}
	
	 if(!isset($_SESSION['pageQuestionIds'])) {
	 $pageQuestionIds1 = $cms->getQuestions()->selectAllQuestionInformationIncludingId() ;
	$_SESSION['pageQuestionIds'] = $pageQuestionIds1;
	}
	
 if(!isset($_SESSION['sortedIds'])) {
$sortedIds = $cms->getQuestions()->sortArrayViaQuestionIdsArray($_SESSION['questionDesc'][1], $_SESSION['pageQuestionIds']);
print_r($sortedIds); echo "<br><br> over <br><br>";
$_SESSION['sortedIds'] = $sortedIds;
} 	else {
	$sortedIds = $_SESSION['sortedIds'];
}

	
	echo "<br><br>";
	
	

	

	
	echo "<br><br>";


		$pageQuestionIds = $_SESSION['questionDesc'][1];

	echo "<br><br>";


	if (!isset($_SESSION['countedNumberOfQuestionsPerQuestion'])) {
	unset($counted);
		$_SESSION['pagesIds'] = $sortedIds; 
		$counted = count($_SESSION['pagesIds']);	
		
	$pagesIds = $_SESSION['pagesIds'];
	for ($i = 0 ; $i < $counted ; $i++ ) {
	$countedNumberOfQuestionsPerQuestion['a' . $i] = count($pagesIds['a' . $i]);
	}
	$_SESSION['countOfPageQuestions'] = count($pageQuestionIds[1]);
	
	$_SESSION['countedNumberOfQuestionsPerQuestion'] = $countedNumberOfQuestionsPerQuestion;
	} else { 
	$countedNumberOfQuestionsPerQuestion = $_SESSION['countedNumberOfQuestionsPerQuestion'];
	$pagesIds = $_SESSION['pagesIds'];
	}
	
	$counted = count($_SESSION['pagesIds']);
	
	$countOfPageQuestions = $counted;
	if (!isset($countedNumberOfQuestionsPerQuestion)) {
	for ($c = 0 ; $c < $counted ; $c++) {
	$_countedNumberOfQuestionsPerQuestion['a' . $c]	= count($pagesIds['a' . 0]);
	
	}
	}
	
	$set = 0;
	
	
			if (!isset($_SESSION['loopNumber'])) {
				$loopNumber = count($countedNumberOfQuestionsPerQuestion);
				$_SESSION['loopNumber'] = $loopNumber;

			} else {
				$loopNumber = $_SESSION['loopNumber'];
			}

$info = $cms->getQuestions()->selectQuestionAllAtOnce($pagesIds, $countedNumberOfQuestionsPerQuestion);
if (isset($_SESSION['completedLoad'])) {
	echo $_SESSION['completedLoad'] . "<br><br>Above<br><br>";
}


$counted = count($_SESSION['countedNumberOfQuestionsPerQuestion']);


	//for($i = 0 ; $i < 2 ; $i++ )  {
		echo "<br>" . $_SESSION['tester2'];
//	echo "<br>" . $_SESSION['questionLimitNumber']['a' . 1];
//	echo "<br>" . $_SESSION['check'][0];
	
//	echo "<br>ncl" . $_SESSION['ncl'][0] . "<br>";
//	echo "<br>lc" . $_SESSION['lc'][0] . "<br>";
  
		
	//}



//print_r($_SESSION['info']);

print_r($pagesIds);
	if (isset($info)) {
			
		for ($c = 0 ; $c < count($countedNumberOfQuestionsPerQuestion) ; $c++) {
				echo "here";
			if (!isset($_SESSION['qr'][$c])) {
			$_SESSION['qr'][$c] = 0;
		}
			if (isset($info['a' . 0]['question'])) { ?>	
<?php 
			echo "here2";
				if ($_SESSION['qr'][$c] < $numeralOfRem) {
						echo "here2";
						echo "<p>" . $info['a'.$c]['question'] . "</p>" ?><br>
					
<?php			
						$_SESSION[$c . 'question'] = $info['a' . $c]['question'];
						$_SESSION[$c . 'correct'] = $info['a' . $c]['correct'];
				
					for($i = 1; $i <= 8; $i++) {

						if ($info['a' . $c]['pa' . $i] != 'empty') {
?>

<input type="radio" name="<?= $c . "a" . $i ?>"> <p>
<?php 
							echo paragraph($info['a' . $c]['pa' . $i]); ?></p>

<?php 
						}	
						if ($info['a' . $c]['hint' . $i] != 'empty') {
						if ($info['a' .$c]['hint' . $i] != 'empty') { echo paragraph($info['a' . $c]['hint' . $i]); } ?></p>	
<?php 
							$_SESSION[$c .'answ' . $i] = $info['a' . $c]['answ' . $i];
							$_SESSION[$c . 'pa' . $i] = $info['a' . $c]['pa' . $i];
							$_SESSION[$c . 'hint' . $i] = $info['a' . $c]['hint' . $i];
							
						}
					}
					}
					
				?> 
				
<br><br>
			<?php				
			} else { 
 
						echo "There is no question information assigned to question ID:"  ;

					}
				}	
			} 
		
		
		$end = microtime(true);
		echo ($end - $start);
	
	
	//print_r($_SESSION['counts']['count1']);
	echo "I'M ALIVE!!!!!";