letterString = 'A B C D E F G H I J K L M N O P Q R S T U V W X Y Z';
letterArray = letterString.split(' ');
$divLetters = $('#letters')
letterLinkArray = [];
for (let i = 0; i < 28; i++) {
    $divLetters.append($('span').text('-'));
    letterLinkArray[i] = $('<a>').attr('href', './admin/classes.php?unset=yes&letter='+letterArray[i]);
    letterLinkArray[i].text(letterArray[i]);
    $divLetters.append(letterLinkArray[i]);
    $divLetters.append($('span').text('-'));
    
}