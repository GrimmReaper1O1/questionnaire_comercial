<?php
?>
<html>
    <body>

<div>








</div>



<div>        
<div style="float: left; width: 700px: height: 400px;">
<div style="width: 50%;">
<div style="color: black; background: white; width: 100% padding: 25%;">Name of website.</div>
<div style=" color: white; width: 100%; height: 30px; margin: 0 auto; height: 30px; background-color: blue;  border-bottom: 1px solid black; ">
<div style="float: left; display: inline-block; height: 100%; width: 7%; background-color: blue; border-bottom: 2px solid black;"></div><div style="float: left; display: inline-block; height: 100%; width: 86%; text-align: center; border-bottom: 2px solid black;">Quesitonnaire!</div><div style="float: left; display: inline-block; width: 7%; background-color: blue; height: 100%; border-bottom: 2px solid black;"></div>
</div>
<div style="float: left; width: 7%; height: 400px; background-color: black;">
</div>
<div style=" display: inline-block; float: left; width: 86%; height: 400px; background-color: blue;">
<div style="position: relative; height: 370px; width: 100%; margin: 0 auto; ">    
<div style="text-align: center;">
    <div style="margin: 0 auto; width: 80%;">
<img style="width: 50%" src="../images/plants dancing.jpg" /></div> <figcaption>info</figcaption>
<h7> Here is your video or audio.</h7><br>
</div><div style="width: 100%; ">
    <div style="float: left; width: 70%;  height: 50%;"><div style="width: 80%; margin: 0 auto; height: auto; border: 2px solid; border-radius: 10px; background-color: white;"><p>This is some writing and it shows where the text is, so it needs to be here. Please don't complain about the content.</p></div>
</div>
    <div style="float: left; width: 30%; margin: 0 auto; height: 50%;"><img style="width: 75%; height: 40%;" src="../images/plants dancing.jpg" /> <figcaption>info</figcaption><img style="width: 75%; height: 40%;" src="../images/plants dancing.jpg" /> <figcaption>info</figcaption></div>
</div>
</div>
</div>
<div style="position: relative; float: left; width: 7%; height: 400px; background-color: black;">
</div>
</div>
</div>
</div>
</div>





</div>
<div style="float: left; width: 20%">









</div>
</div>
















</div>
