<?php
$currentPath = dirname(__DIR__); 
include "includes/header3.php";
?>

<a href="addition.php?reset=yes">Addition</a><br>
<a href="division.php?reset=yes">Division</a><br>
<a href="multiplication.php?reset=yes">Multiplication</a><br>
<a href="subtraction.php?reset=yes">Subtraction</a><br>
