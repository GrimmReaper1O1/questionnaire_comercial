//
// async function loadFromIndexedDB(storeName, key, databaseName) {
//     return new Promise((resolve, reject) => {
//         // Open the database connection
//         const dbRequest = indexedDB.open(databaseName);
//
//         // Handle errors during the open request
//         dbRequest.onerror = function(event) {
//             reject(new Error('Error opening IndexedDB: ' + event.target.error));
//         };
//
//         // Handle the upgrade needed event (database schema changes)
//         dbRequest.onupgradeneeded = function(event) {
//             const db = event.target.result;
//
//             // Check if the store exists, if not, create it
//             if (!db.objectStoreNames.contains(storeName)) {
//                 db.createObjectStore(storeName, { keyPath: 'id', autoIncrement: false });
//             }
//         };
//
//         // Handle success when the database is opened
//         dbRequest.onsuccess = function(event) {
//             const db = event.target.result;
//
//             // Start a transaction (readonly if we're just fetching data)
//             const transaction = db.transaction([storeName], 'readonly');
//             const objectStore = transaction.objectStore(storeName);
//
//             // Get the object by key
//             const objectRequest = objectStore.get(key);
//
//             objectRequest.onerror = function(event) {
//                 reject(new Error('Error fetching data from the store: ' + event.target.error));
//             };
//
//             objectRequest.onsuccess = function(event) {
//                 if (objectRequest.result) {
//                     resolve(objectRequest.result); // Data found, resolve the promise
//                 } else {
//                     reject(new Error('Key not found in the object store'));
//                 }
//             };
//         };
//     });
// }



async function loadFromIndexedDB(storeName, key, database) {
  return new Promise((resolve, reject) => {
    const dbRequest = indexedDB.open(database);

    dbRequest.onerror = (event) => {
      console.error('Database error:', event);
      reject(Error('Database open failed'));

    };

    dbRequest.onupgradeneeded = (event) => {
      const db = event.target.result;
      if (!db.objectStoreNames.contains(storeName)) {
        db.createObjectStore(storeName, { keyPath: 'id', autoIncremovalent: true });
      }
      // Optionally reject if you want to stop loading when upgrade is needed

      reject(Error('Database upgrade needed'));
    };

    dbRequest.onsuccess = (event) => {
      const db = event.target.result;
      const transaction = db.transaction([storeName], 'readwrite');
      const objectStore = transaction.objectStore(storeName);
      const objectRequest = objectStore.get(key);

      objectRequest.onsuccess = (event) => {
        if (objectRequest.result) {

          setTimeout(() => (resolve(objectRequest.result)),);
        } else {
          reject(Error('No data found for key: ' + key));
        }
      };

      objectRequest.onerror = (event) => {
        console.error('Object request error:', event);
        reject(Error('Error retrieving object'));

      };

      transaction.onerror = (event) => {
        console.error('Transaction error:', event);

        reject(Error('Transaction failed'));
      };
    };
  });
}




// async function loadFromIndexedDB(storeName, key, database){
//     return new Promise(
//       function(resolve, reject) {
//         var dbRequest = indexedDB.open(database);
//
//         dbRequest.onerror = function(event) {
//           var database    = event.target.result;
//           var objectStore = database.createObjectStore(storeName, {autoincrement: true});
//
//         }
//
//         dbRequest.onupgradeneeded = function(event) {
//           // Objectstore does not exist. Nothing to load
//           event.target.transaction.abort();
//           reject(Error('Not found'));
//         }
//
//         dbRequest.onsuccess = function(event) {
//           var database      = event.target.result;
//           var transaction   = database.transaction([storeName], 'readwrite');
//
//
//           transaction.onerror = function(event) {
//
//           }
//
//           var objectStore   = transaction.objectStore(storeName);
//           var objectRequest = objectStore.get(key);
//
//           objectRequest.onerror = function(event) {
//             var database    = event.target.result;
//
//
//           }
//
//           objectRequest.onsuccess = function(event) {
//             if (objectRequest.result) resolve(objectRequest.result);
//             else reject();
//
//           }
//
//         }
//
//       }
//     )
//
//   }


  function h4 (text) {
    var elemented = "<h4>" + text + "</h4>";
    return elemented;
  }
  function paragraph(text) {
    var para = "<p>"+text+"</p>";
    para.textContent = text;
    return para;
  }
  function paragraphs(text) {
  var paragraphs = text.split(/\r\r|\r\n/);

  var htmlParagraphs = [];

  paragraphs.forEach(function(paragraphText) {
    paragraphText = paragraphText.trim();

    var htmlParagraph = "<p>" + paragraphText + "</p>";

    htmlParagraphs.push(htmlParagraph);
  });

  var htmlOutput = htmlParagraphs.join("");


    return htmlOutput;
  }


  function countValues(obj) {
    let count = 0;

    for (let key in obj) {

        count++;
      }

    return count;
  }


  function runOne (arry, numeralOfRemoval) {

document.addEventListener("DOMContentLoaded", function() {
const radioGroup = {}
for (var i = 0 ; i < arry.qLength ; i++) {
radioGroup[i] = {
    init: function() {
        const radioButtons = document.querySelectorAll('.r'+i+'adio-button');
        radioButtons.forEach(function(radioButton) {
            radioButton.addEventListener('click', function() {
                // Disable all other radio buttons
                radioButtons.forEach(function(rb) {
                    if (rb !== radioButton) {
                        rb.disabled = true;
                    }
                });
            });
        });
    },
}
radioGroup[i].init()
}
})
var text = '';
var newtext = '';
var finalText = '';
for (let i = 0 ; i <= (arry.qLength - 1); i++) {
var div1 = document.getElementById('a'+i);
if (arry) {
}       var key = {}
    key[i] = 'a' + i;
if (numeralOfRemoval != arry.qAnsw.qNumeral[i]['right']) {
  console.log(arry['a' + i][arry['numeral'][i]]['question']);
  console.log(arry);
  console.log(arry['numeral']);
  console.log('' + i);
  // debugger;
text = arry['a' + i][arry['numeral'][i]]['question'];
newtext = paragraphs(text);
finalText = "Question: " + newtext;
for (let c = 1 ; c < 9 ; c++) {
var keyzero = {};
keyzero[c] = 'pa' + c;
if (arry['a' + i][arry['numeral'][i]][keyzero[c]] != 'empty') {
var text = arry['a' + i][arry['numeral'][i]][keyzero[c]];
newtext = paragraphs(text);
finalText += '<input type="radio" name="' + i + 'a' + c + '" class="r'+i+'adio-button" onclick="radioGroup['+i+']">' + "Answer: " + newtext;
var keyone = {};
    keyone[c] = 'hint' + c;
if (arry['a' + i][arry['numeral'][i]][keyone[c]] != 'empty') {
text = arry['a' + i ][arry['numeral'][i]][keyone[c]];
newtext = paragraphs(text);
finalText += "Hint: " + newtext;
            }
        }
    }
    div1.innerHTML += finalText;
} else {
    div1.innerHTML = "QUESTION COMPLETE!";
}
}
console.log('runhere');
return arry;
}

function runTwo (arry, posted, color, width, colorOfText, borderColour) {

  if (arry.hasOwnProperty('qr')) {
    var qr = arry['qr'];
    } else {
    var qr = {};
    for (var i = 0 ; i < arry.qLength ; i++ ) {
    qr['a'+i] = 0;
    }
    }
var replyDiv = document.getElementById('reply');
var qn = {}
for (var i = 0 ; i < arry.qLength; i++ ) {

    for (var c = 1 ; c < 9 ; c++ ) {
       if (posted[i+'a'+c] === 'on') {
           qn = i;
    }
}
for (var c = 1 ; c < 9 ; c++ ) {


        if (posted[i+'a'+c] == 'on') {
var text1 = arry['a' + i][arry['numeral'][i]]['question'];
var text2 = arry['a' + i][arry['numeral'][i]]['answ' + c];
var text3 = arry['a' + i][arry['numeral'][i]]['hint' + c];
var text4 = arry['a' + i][arry['numeral'][i]]['pa' + c];
var breakLine = '<br><br>';

replyDiv.innerHTML += breakLine;

var finalText = '<div class="qanswer2" >' +
'Question: <br>' + paragraphs(text1) + "Answer given:<br>" + paragraphs(text4) + "Reply: <br>" + paragraphs(text2);



if (arry['a' + i][arry['numeral'][i]]['hint' + c] != 'empty') {

    finalText += "Hint given: <br>" + paragraphs(text3) + '</div>';

            } else {
                finalText += '</div>';

            }

    replyDiv.innerHTML += finalText;

    if (arry['a' + qn][arry['numeral'][i]]['correct'] === 'answ'+ c && posted[i+'a'+c] === 'on' ) {
      qr['a' + qn]++;
      arry['qAnsw']['qNumeral'][i]['right']++;
    } else {
      arry['qAnsw']['qNumeral'][i]['wrong']++;
      }
    }
  }
}



arry['qAnsw'];
arry['qr'] = qr;
return arry;
}


function saveToIndexedDB(storeName, object, key, databaseName) {
  return new Promise(function(resolve, reject) {
    if (object.id === undefined) reject(Error('Object has no id.'));

    var dbRequest = indexedDB.open(databaseName);

    dbRequest.onerror = function(event) {
      reject(Error("IndexedDB database error"));
    };

    dbRequest.onupgradeneeded = function(event) {
      var database = event.target.result;

      // Create object store if it doesn't exist
      if (!database.objectStoreNames.contains(storeName)) {
        database.createObjectStore(storeName, { keyPath: key });
      }
    };

    dbRequest.onsuccess = function(event) {
      var database = event.target.result;
      var transaction = database.transaction([storeName], 'readwrite');
      var objectStore = transaction.objectStore(storeName);
      var objectRequest = objectStore.put(object, key); // Overwrite if exists

      objectRequest.onerror = function(event) {
        reject(Error('Error saving data: ' + event.target.error));
      };

      objectRequest.onsuccess = function(event) {
        resolve('Data saved OK');
      };
    };
  });
}



//
//
// function saveToIndexedDB(storeName, object, key, databaseName) {
//   return new Promise(function (resolve, reject) {
//     if (object.id === undefined) reject(Error('Object has no id.'));
//
//     var dbRequest = indexedDB.open(databaseName);
//
//     dbRequest.onerror = function(event) {
//       reject(new Error("IndexedDB database error"));
//     };
//
//     dbRequest.onupgradeneeded = function(event) {
//       var database = event.target.result;
//
//       // Create object store if it doesn't exist
//       if (!database.objectStoreNames.contains(storeName)) {
//         database.createObjectStore(storeName, { keyPath: "id" }); // Assumes 'id' is the keyPath
//       }
//     };
//
//     dbRequest.onsuccess = function(event) {
//       var database = event.target.result;
//       var transaction = database.transaction([storeName], 'readwrite');
//       var objectStore = transaction.objectStore(storeName);
//       var objectRequest = objectStore.put(object, key); // Will overwrite existing data
//
//       objectRequest.onerror = function(event) {
//         console.error("Error saving data: ", event.target.error);
//         reject(new Error('Error saving data'));
//       };
//
//       objectRequest.onsuccess = function(event) {
//         resolve('Data saved OK');
//       };
//     };
//   });
// }


  // function saveToIndexedDB(storeName, object, key, databaseName){
  //   return new Promise(
  //     function(resolve, reject) {
  //       if (object.id === undefined) reject(Error('object has no id.'));
  //       var dbRequest = indexedDB.open(databaseName);
  //
  //       dbRequest.onerror = function(event) {
  //         reject(Error("IndexedDB database error"));
  //       };
  //
  //       dbRequest.onupgradeneeded = function(event) {
  //         var database    = event.target.result;
  //
  //       };
  //
  //       dbRequest.onsuccess = function(event) {
  //         var database      = event.target.result;
  //         var transaction   = database.transaction([storeName], 'readwrite');
  //         var objectStore   = transaction.objectStore(storeName);
  //         var objectRequest = objectStore.put(object, key); // Overwrite if exists
  //
  //         objectRequest.onerror = function(event) {
  //           reject(Error('Error text'));
  //         };
  //
  //         objectRequest.onsuccess = function(event) {
  //           resolve('Data saved OK');
  //
  //         };
  //         objectRequest.oncomplete = function(event) {
  //           var data = event.target.result;
  //           data.close();
  //         }
  //       };
  //     }
  //   );
  // };

  async function updateDelDB(storeName, databaseName, version){
        var dbRequest = indexedDB.open(databaseName, version);

        dbRequest.onupgradeneeded = (event) => {
        var database    = event.target.result;

       database.createObjectStore(storeName, {autoincrement: true});



        };

        dbRequest.onsuccess = function(event) {

          var data = event.target.result;
          data.close();
        }

        dbRequest.onerror = function(event) {

          };

        };


        function openDB(storeName, databaseName){
          var dbRequest = indexedDB.open(databaseName);

          dbRequest.onupgradeneeded = function(event) {
            var database    = event.target.result;
            var objectStore = database.createObjectStore(storeName, {autoincrement: true});

          };

          dbRequest.onsuccess = function(event) {
          }

          dbRequest.onerror = function(event) {
              reject(Error('Error text'));
            };

          };
          function deleteDB(databaseName) {
          var db = indexedDB.deleteDatabase(databaseName);
          db.onsuccess = function (event) {

              window.location.replace('/questionnaire.php?reset=yes');

          }
          db.oncomplete = function (event) {
            var database = event.target.result;
            database.close();
          }

          db.onerror = function (event) {

          }
        }

        function createStoreDB(storeName, databaseName){
          var dbRequest = indexedDB.open(databaseName);

          dbRequest.onupgradeneeded = function(event) {

          };

          dbRequest.onsuccess = function(event) {
            var database    = event.target.result;
            var objectStore = database.createObjectStore(storeName, {autoincrement: true});

          }

          dbRequest.onerror = function(event) {
              reject(Error('Error text'));
            };

          };

export {loadFromIndexedDB, updateDelDB, saveToIndexedDB, openDB, runTwo, runOne, deleteDB, createStoreDB};
