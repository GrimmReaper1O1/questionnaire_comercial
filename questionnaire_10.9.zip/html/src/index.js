import panzoom from 'panzoom';
import flicking from '@egjs/flicking';
import {
    get,
    set,
    getMany,
    setMany,
    update,
    del,
    clear,
    keys,
    values,
    entries,
    createStore,
} from 'idb-keyval';


console.log(panzoom);
console.log(flicking);
