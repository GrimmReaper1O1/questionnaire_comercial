<?php
$currentPath = rtrim(__DIR__, DIRECTORY_SEPARATOR); include "../includes/header3.php";
$subject = "; use questionnaire;
select * from users;";
$subject = $subject * 1;