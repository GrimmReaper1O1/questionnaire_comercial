<?php
include "../../includes/header5.php";
if ($_SESSION['administrator']['root'] == 1) {
$resultsPerPage = 1;

$letter = $_GET['letter'] ?? 1;
$f = 0;
$sF = 0;
$error = '';
$sA = 0;
$sD = 0;
$sT = 0;
$limit = 20;
$yN = $_POST['yN'] ?? 'no';


if (isset($_GET['unset'])) {
unset($_SESSION['title']);
unset($_SESSION['authors']);
unset($_SESSION['description']);
unset($_SESSION['letter']);
unset($_SESSION['alphabet']);
unset($_SESSION['page']);
unset($_SESSION['class2']);
unset($_SESSION['class_id']);

}

if (isset($_GET['reset'])) {
unset($_SESSION['title']);
unset($_SESSION['authors']);
unset($_SESSION['description']);
unset($_SESSION['letter']);
unset($_SESSION['alphabet']);
unset($_SESSION['page']);
unset($_SESSION['class2']);
unset($_SESSION['class_id']);
unset($_SESSION['class']);
$_SESSION['alphabet'] = 1;

}



$_SESSION['page'] = isset($_GET['page']) ? $_GET['page'] : 1;

if (isset($_GET['class'])) {
		$_SESSION['class_id'] = $_GET['class'];
	
	}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	

if (isset($_POST['class']) && !isset($_GET['delete'])) {
		$nC = 1;
		
	} 
}
	
	if (isset($_GET['letter']) && !isset($_GET['delete'])) {

		$_SESSION['letter'] = $_GET['letter'];
	}
	
	if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_GET['delete'])) {
	if ($_POST['title'] != '') {
		
		$_SESSION['title'] = $_POST['title'];
	
	}
	if ($_POST['author'] != "") {
		
		$_SESSION['authors'] = $_POST['author'];
	
	}
	if ($_POST['description'] != '') {
		
		$_SESSION['description'] = $_POST['description'];
	
	}
	if ($_POST['class'] != '') {
		
		$_SESSION['class2'] = $_POST['class'];
	
	}
	}
	if (isset($_SESSION['alphabet']) && $_SESSION['alphabet'] != 1) {
		$array = $cms->getLibrary()->searchAlphabeticallyPaginationNC($limit);	
		$totalResults = $array[0]['count'];
		$totalPages = ceil($totalResults / $limit);
		echo "one";
	}

    if (isset($_SESSION['letter'])) {
		$array = $cms->getLibrary()->searchViaLetterPaginationNC($limit);
		$totalResults = $array[0]['count'];
		$totalPages = ceil($totalResults / $limit);
echo "two";
	}



	if (isset($_SESSION['title'])) {
		if ($nC = 1) {
		$array = $cms->getLibrary()->selectTitleFromLibraryNC($limit);
		} else {
		$array = $cms->getLibrary()->selectTitleFromLibrary($limit);
		}
		$totalResults = $array[0]['count'];
		$totalPages = ceil($totalResults / $limit);
   echo "three";
		

	}

	if (isset($_SESSION['authors'])) {
		if ($nC = 1) {	
		$array = $cms->getLibrary()->selectAuthorFromLibraryNC($limit);
		} else {
		$array = $cms->getLibrary()->selectAuthorFromLibrary($limit);
		}
		$totalResults = $array[0]['count'];
		$totalPages = ceil($totalResults / $limit);
		echo "four";
	}

	if (isset($_SESSION['description'])) {
		if ($nC = 1) {
		$array = $cms->getLibrary()->selectDescriptionFromLibraryNC($limit);
		} else {
		$array = $cms->getLibrary()->selectDescriptionFromLibrary($limit);
		}
		$totalResults = $array[0]['count'];
		$totalPages = ceil($totalResults / $limit);
   echo "five";
	}

	
	
	if (isset($_SESSION['class_id']) || isset($_SESSION['class'])) {
	unset($_SESSION['class2']);
	if (isset($_SESSION['class_id'])) {
		$_SESSION['class'] = $_SESSION['class_id'];
	
		unset($_SESSION['class_id']);
		
	}
	$array = $cms->getLibrary()->searchAlphabeticallyPagination($limit);
	
		$totalResults = $array[0]['count'];
		$totalPages = ceil($totalResults / $limit);
   echo "six";

	}

if (isset($_SESSION['class2'])) {

		echo "here";
		$array2 = $cms->getLibrary()->selectClassFromLibraryPagination($limit);
	
		$totalResults = $array2[0]['count'];
		$totalPages = ceil($totalResults / $limit);
   
		echo "seven";

	}












if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_GET['delete'])) {



if ($_POST['title'] != '' && $_POST['author'] != '' && $_POST['description'] == '') {
$f = 1;	
}
if ($_POST['title'] != '' && $_POST['author'] == '' && $_POST['description'] != '') {
$f = 1;
}
if ($_POST['title'] == '' && $_POST['author'] != '' && $_POST['description'] != '') {
$f = 1;
}
if ($_POST['title'] != '' && $_POST['author'] != '' && $_POST['description'] != '') {
$f = 1;
}



}







if (isset($array)) {
	if ($array == false) {
		$sF = 1;
	}
}

if (isset($array2)) {
	if ($array2 == false) {
		$sF = 1;
	}
}


$letterString = 'A B C D E F G H I J K L M N O P Q R S T U V W X Y Z';

$letterArray = preg_split('/[\s]+/', $letterString);




if ($f === 1) {
	$error .= "You can't search for more than one option. <br>";
	unset($array);
}

if ($sF === 1) {
	$error .= "There was a problem. The search failed to find anything. <br>";
	unset($array);
}


echo $error;
?>
<div>
 
<?php
if(isset($_GET['unset']) || isset($_GET['reset']) || isset($_SESSION['class']) || isset($_SESSION['class2'])) {

foreach($letterArray as $letters) { ?>
<?= "-" ?><a href="delete_document.php?unset=yes&letter=<?= $letters ?>"><?= $letters ?></a><?= "-" ?>
<?php
} ?>
 <br><br>
<div id='main'>
<form action="delete_document.php?reset=yes" method="POST">

  <label for="class">Class name:</label><br>
  <input type="text" name="class" size="100"><br>
  <label for="title">Title:</label><br>
  <input type="text" name="title" size="100" value="<?= $_SESSION['title'] ?? '' ?>"><br>
  <label for="author">Author or authors:</label><br>
  <input type="text" name="author" size="100" value="<?= $_SESSION['authors'] ?? '' ?>"><br>
  <label for="description">Description:</label><br>
  <input type="text" name="description" size="100" value="<?= $_SESSION['description'] ?? '' ?>"><br>
<input type="submit" value="SUBMIT!">
</form>


<?php

if (isset($array)) {
	
	if ($array[1] != false) {
	
	
foreach($array[1] as $documents) { ?>
ID:<?= $documents['id'] ?><br>

<a href="<?= '../' . $documents['file_location']?>">VIEW DOCUMENT</a><br><br>
Title: <?= $documents['title'] ?><br><br>
Authors: <?= $documents['authors'] ?><br><br>
<a href="delete_document.php?id=<?= $documents['id'] ?>">DELETE DOCUMENT!</a><br><br>
Description: <?php
$description = paragraph($documents['description']);
echo '<p>' . $description . '</p>'; ?><br><br>



<?php }
echo "-";
for ($i = 1; $i <= $totalPages; $i++) {
    echo '<a href="delete_document.php?page=' . $i . '">' . $i . '</a> - ';
}
	}
} 

if (isset($array2)) {

	if ($array2[1] != false) {
foreach($array2[1] as $documents) { ?>

Class Name:<a href="delete_document.php?class=<?= $documents['class_id'] ?>"><?= $documents['class_name'] ?></a><br>


<?php }
echo "-";
for ($i = 1; $i <= $totalPages; $i++) {
    echo '<a href="delete_document.php?page=' . $i . '">' . $i . '</a> - ';
}
	}
} 

}

if ($yN == 'yes' || $yN == 'YES') {
if (isset($_SESSION['deleteLibId'])) {
try {
unlink("../" . $_SESSION['file_location']);
} catch (Exception $e) {
	echo "THERE WAS NO FILE ON THE SERVER TO DELETE!";
}
if ($cms->getLibrary()->deleteFromLibraryViaId($_SESSION['deleteLibId']) > 0) { 
echo "The document was successfully deleted! <br>";	
unset($array);
unset($_SESSION['file_location']);
unset($_SESSION['deleteLibid']);
} else { 
echo "THERE WAS A PROBLEM. PLEASE TRY AGAIN OR CONTACT YOUR ADMINISTRATOR."; 
}	
}
}

if (isset($_GET['id'])) {

$_SESSION['deleteLibId'] = $_GET['id'];
$document = $cms->getLibrary()->selectFromLibraryViaId($_SESSION['deleteLibId']);
$_SESSION['file_location'] = $document['file_location'];

if (isset($document)) {
?>
<h4>Are you sure the document by the title of <?= $document['title'] ?><br>
is the document you want to delete from the system?</h4>
<form action="delete_document.php?delete=yes" method="POST">
	<label for="yN">YES OR NO:</label>
	<input type="text" name="yN"><br>
	<input type="submit" value="SUBMIT!"><br>

<a href="<?= "../" . $document['file_location'] ?>">VIEW DOCUMENT!</a><br><br><br><br>
Title: <?= $document['title'] ?><br><br>
Authors: <?= $document['authors'] ?><br><br>
Description: <?php
$description = paragraph($document['description']);
echo '<p>' . $description . '</p>'; ?><br><br><br><br><br>

<?php }
}


?></div>
</div>
<?php
} else {
    header("Location: how_dare_you.php");
    exit();
}










