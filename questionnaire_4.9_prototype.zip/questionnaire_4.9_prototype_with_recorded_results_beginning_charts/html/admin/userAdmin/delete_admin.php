<?php
include "../../includes/header5.php";
if ($_SESSION['administrator']['admin'] == 1) {

$yN = $_POST['yN'] ?? 'maybe';









if ($yN == 'yes' || $yN == 'YES') {
if (isset($_SESSION['deleteAdminId'])) {

if ($cms->getMember()->deleteAdminViaId($_SESSION['deleteAdminId']) > 0) { 
echo "THE ADMINISTRATOR WAS SUCCESSFULLY DELETED! <br>";
echo "<a href='show_all_administrators.php'>BACK TO LIST OF ADMINISTRATORS!</a>";	
unset($_SESSION['deleteLibid']);
} else { 
echo "THERE WAS A PROBLEM. PLEASE TRY AGAIN OR CONTACT YOUR ADMINISTRATOR.<br>"; 
echo "<a href='show_all_administrators.php'>BACK TO LIST OF ADMINISTRATORS!</a>";	
}	
}
} elseif ($yN === 'no') {
	header("Location: show_all_administrators.php");
	exit;
}

if (isset($_GET['id'])) {

$_SESSION['deleteAdminId'] = $_GET['id'];
$row = $cms->getMember()->getAdministratorViaId($_SESSION['deleteAdminId']);


if (isset($row)) {
?>
<h4>ARE YOU SURE YOU WANT TO DELETE THIS ADMINISTRATOR FROM THE SYSTEM?</h4>
<form action="delete_admin.php?delete=yes" method="POST">
	<label for="yN">YES OR NO:</label>
	<input type="text" name="yN"><br>
	<input type="submit" value="SUBMIT!"><br>

	<h4>
		FULL NAME: <?= $row['concat_full_name'] ?><br>
		EMAIL: <?= $row['email'] ?><br>
		PHONE NUMBER: <?= $row['phone_number'] ?><br>	
		CREATED BY ADMINISTRATOR: <?= $row['creator_name'] ?><br>
		ADMINISTRATOR CREATED ON: <?php echo date('d-m-y h:i a', $row['timestamp']); ?><br>
		SUPER USER PRIVILEGES:<?php if($row['all_access_administrator'] == 1) { echo "YES!"; } else { echo "NO!"; }

		
		?>
		</h4>
<?php }
}
} else {
    header("Location: how_dare_you.php");
    exit();
}