<?php
?>
<DOCTYPE! HTML>
	<html>
		<head>
</head>
<body>
<canvas id="myCanvas"></canvas>
<div for="myCanvas"></div>
<script src="src/chart.js">
	
	

</script>

<script>
	const data = {
  labels: [
    'Right',
	'Not correct',
],
  datasets: [{
    label: 'My First Dataset',
    data: [3, 5],
    backgroundColor: [
      'rgb(255, 0, 0)',
      'rgb(0, 255, 0)',
      
    ],
    hoverOffset: 4
  }]
};
       const config = {
  type: 'doughnut',
  data: data,
};

const myChart = new Chart("myCanvas", {config, data});

</script>

</body>
</html>
