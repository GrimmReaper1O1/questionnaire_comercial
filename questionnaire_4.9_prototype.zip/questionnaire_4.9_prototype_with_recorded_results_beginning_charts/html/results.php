<?php

include 'includes/header3.php';
$patterns[0] = '/"/';

$replacements[0] = '';


// print_r($_POST['data']);
$data = $_POST['data'];
// $data = preg_replace($patterns, $replacements, $object);
print_r($data);
$data2 = json_decode($data);

$pageCounter = 0;
foreach($data2 as $page) {
    $pageResults = 0;
    $pageCounter++;
    
   
if (isset($page->length)) {  
    echo "<br>";
    echo "PAGE: " . $pageCounter . "<br>";
    print_r($page);
    echo "<br>";
    for ($i = 0; $i < $page->length; $i++) {
        $pageResults++;
        echo "QUESTION NUMBER: " . $pageResults . "<br>";
    }

}


}

?>
</body>
</html>