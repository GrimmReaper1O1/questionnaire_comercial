<?php
include "includes/header3.php";
if (isset($_GET['id'])) {
$id = $_GET['id'] ?? '';
$_SESSION['subject'] = $id;
}
$_SESSION['gate'] = 'enter';

if (isset($_GET['id'])) {
	$row = $cms->getQuestions()->selectSubjectViaTableIdAndClassId();
	print_r($row['number_of_questions']);
$_SESSION['version'] = $row['version'];
$_SESSION['numberOfQuestionsOnPage'] = $row['number_of_questions'];
$_SESSION['numeralOfRem'] = $row['number_of_removal'];

print_r($row);
	$introduction = $row['introduction'] ?? '';
}
	?>
<h1><b>SUBJECT:</B> <a href="questionnaireBuf.php"><?= ' ' . $row['subject_information'] ?? '' ?></a></h1><br>
<?php echo '<p>' . paragraph($introduction) . '</p>'; ?>
<?php
for ($i = 1; $i <= 10; $i++) {
if ($row['link' . $i] != 'empty') {
	?>
		<a href="http:\\<?= $row['link' . $i] ?>"><?= $row['link_description' . $i] ?></a><br>
	<?php
}
}