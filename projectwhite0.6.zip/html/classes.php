<?php 
include 'includes/headerstart.php';

$page = $_GET['page'] ?? 1;
$limit = 1;
$letter = $_GET['letter'] ?? 1;
$letterString = 'A B C D E F G H I J K L M N O P Q R S T U V W X Y Z';
$letterArray = preg_split('/[\s]+/', $letterString);
if (isset($_GET['unset'])) {
	unset($_SESSION['letter']);
	unset($_SESSION['search']);
	unset($_SESSION['new']);
}
if (isset($_GET['reset'])) {
	unset($_SESSION['subject']);
	unset($_SESSION['letter']);
	unset($_SESSION['search']);
	$_SESSION['new'] = 1;
	
}



if (isset($_GET['letter'])) {
	$_SESSION['letter'] = $_GET['letter'];
	
}

foreach($letterArray as $letters) { ?>
<?= "-" ?><a href="classes.php?unset=yes&letter=<?= $letters ?>"><?= $letters ?></a><?= "-" ?>
<?php
} ?>

<h1>Welcome to the inner sanctum of questionair!</h1><br>
<h3><a href="classes.php?reset=yes">Please select the class you want to enroll in via alphabetical order.</a><br> 
<a href="search_for_class.php">Or, search for a class.</a></h3><br><br>

<?php
if (isset($_SESSION['letter'])) {
	$classesArray = $cms->getQuestions()->selectAllClassesViaLetter($page, $limit, $_SESSION['letter']);
	echo '<a href="classes.php?reset=yes">Return to alphabetical order</a><br>';
	if ($classesArray[0] != false) {
	$totalResults = $classesArray[0]['count'];
$totalPages = ceil($totalResults / $limit);
	
	foreach($classesArray[1] as $class) {
	?>
	<h4>Class:<br>
	<a href="selectSubject.php?class=<?= $class['class_id'] ?>"><?= $class['class_name'] ?></a></h4><br><br>
	<h5>Description:</h5><br>
	<p><?php echo paragraph($class['description_of_class']); ?><br><br>
	
	
<?php 
	}
	
echo "-";
for ($i = 1; $i <= $totalPages; $i++) {
    echo '<a href="classes.php?page=' . $i . '">' . $i . '</a> - ';
}

	}	
}



if (isset($_SESSION['new'])) {
$classesArray = $cms->getQuestions()->selectAllClasses($page, $limit);

if ($classesArray[0] != false) {
$totalResults = $classesArray[0]['count'];
$totalPages = ceil($totalResults / $limit);

foreach($classesArray[1] as $class) {
	?>
	<h4>Class:<br>
	<a href="selectSubject.php?class=<?= $class['class_id'] ?>"><?= $class['class_name'] ?></a></h4><br><br>
	<h5>Description:</h5><br>
	<p><?php echo paragraph($class['description_of_class']); ?><br><br>
	
	
<?php 
}


echo "-";
for ($i = 1; $i <= $totalPages; $i++) {
    echo '<a href="classes.php?page=' . $i . '">' . $i . '</a> - ';
}

} 
}	
 ?>