<?php
include '../../src/bootstrap.php';
for($i = 0; $i > 4; $i++) {
	echo $i . "<br>";
}
$question = 'empty'
$pa1 = $_POST['pa1'] ?? 'empty';
$pa2 = $_POST['pa2'] ?? 'empty';
$pa3 = $_POST['pa3'] ?? 'empty';
$pa4 = $_POST['pa4'] ?? 'empty';
$pa5 = $_POST['pa5'] ?? 'empty';
$pa6 = $_POST['pa6'] ?? 'empty';
$pa7 = $_POST['pa7'] ?? 'empty';
$pa8 = $_POST['pa8'] ?? 'empty';
$answ1 = $_POST['answ1'] ?? 'empty';
$answ2 = $_POST['answ2'] ?? 'empty';
$answ3 = $_POST['answ3'] ?? 'empty';
$answ4 = $_POST['answ4'] ?? 'empty';
$answ5 = $_POST['answ5'] ?? 'empty';
$answ6 = $_POST['answ6'] ?? 'empty';
$answ7 = $_POST['answ7'] ?? 'empty';
$answ8 = $_POST['answ8'] ?? 'empty';
$hint1 = $_POST['hint1'] ?? 'empty';
$hint2 = $_POST['hint2'] ?? 'empty';
$hint3 = $_POST['hint3'] ?? 'empty';
$hint4 = $_POST['hint4'] ?? 'empty';
$hint5 = $_POST['hint5'] ?? 'empty';
$hint6 = $_POST['hint6'] ?? 'empty';
$hint7 = $_POST['hint7'] ?? 'empty';
$hint8 = $_POST['hint8'] ?? 'empty';
$correct = 'answ' . $correct;
$_session['qid'] = 2;

$count = $cms->getQuestions()->updateQuestion($_SESSION['qid'], $question, $pa1, $pa2, $pa3, $pa4, $pa5, $pa6, $pa7, $pa8,
	$answ1, $answ2, $answ3, $answ4, $answ5, $answ6, $answ7, $answ8, $correct, $_SESSION['qid'],
	$hint1, $hint2, $hint3, $hint4, $hint5, $hint6, $hint7, $hint8);

