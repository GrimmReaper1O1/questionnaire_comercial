<?php 
include "../includes/header_others.php";
if ($administrator['admin'] == 1) {
$resultsPerPage = 10;
$currentPage = isset($_GET['page']) ? $_GET['page'] : 1;
$letter = $_GET['letter'] ?? 1;
$f = 0;
$sF = 0;
$error = '';
$sA = 0;
$sT = 0;
$yN = $_POST['yN'] ?? 'no';
$offset = ($currentPage - 1) * $resultsPerPage;
// please disregard this part. Although functional it is for a lack of sleep.

if (isset($_GET['unset'])) {
unset($_SESSION['title']);
unset($_SESSION['authors']);
unset($_SESSION['deleteLibId']);
unset($_SESSION['file_location']);

}




  if (isset($_SESSION['title'])) {


  $keywords = preg_split('/[\s]+/', $_SESSION['title']);
  $totalKeywords = count($keywords);



  // creation of count statement for pagination
  $str2 = "SELECT count(*) AS count from library where";
  $str2 .= " (title LIKE :search10) ";
  if ($totalKeywords > 1) {
  for ($i = 1 ; $i < $totalKeywords; $i++) {

      $search_bit2 = ":search1" . $i;
      $str2 .= " AND (description like " . $search_bit2 . ") ";

  }}

  $stmt = $cms->db->prepare($str2);
  // binding of values and execution to fetch count result
  if (!empty($stmt)) {

      for ($x = 0; $x<$totalKeywords; $x++) {
          $keywords[$x] = "%" . $keywords[$x] . "%";

          $stmt->bindValue(':search1' . $x, $keywords[$x]);
          }

  }


  $stmt->execute();
  $row = $stmt->fetch();
  $totalResults = $row['count'];
  $totalPages = ceil($totalResults / $resultsPerPage);



  // creation of statment to gather information via fetchall
  $sql_str = "SELECT * from library where";
  $sql_str .= " (title LIKE :search10) ";
  if ($totalKeywords > 1) {
  for ($i = 1 ; $i < $totalKeywords; $i++) {

  $search_bit2 = ":search1" . $i;
  $sql_str .= " AND (description like " . $search_bit2 . ") ";

  }}




  $sql_str .= "ORDER BY title, authors ASC OFFSET $offset ROWS FETCH NEXT $resultsPerPage ROWS ONLY";

  $stmt = $cms->db->prepare($sql_str);


  // binding of values


  if (!empty($stmt)) {

  for ($x = 0; $x<$totalKeywords; $x++) {
  $keywords[$x] = "%" . $keywords[$x] . "%";

  $stmt->bindValue(':search1' . $x, $keywords[$x]);
  }

  }
  $stmt->execute();
  $array = $stmt->fetchAll();
  }














  if (isset($_SESSION['authors'])) {

  $keywords = preg_split('/[\s]+/', $_SESSION['authors']);
  $totalKeywords = count($keywords);



  // creation of count statement for pagination
  $str2 = "SELECT count(*) AS count from library where";
  $str2 .= " (authors LIKE :search10) ";
  if ($totalKeywords > 1) {
  for ($i = 1 ; $i < $totalKeywords; $i++) {

      $search_bit2 = ":search1" . $i;
      $str2 .= " AND (authors like " . $search_bit2 . ") ";

  }}

  $stmt = $cms->db->prepare($str2);
  // binding of values and execution to fetch count result
  if (!empty($stmt)) {

      for ($x = 0; $x<$totalKeywords; $x++) {
          $keywords[$x] = "%" . $keywords[$x] . "%";

          $stmt->bindValue(':search1' . $x, $keywords[$x]);
          }

  }


  $stmt->execute();
  $row = $stmt->fetch();
  $totalResults = $row['count'];
  $totalPages = ceil($totalResults / $resultsPerPage);



  // creation of statment to gather information via fetchall
  $sql_str = "SELECT * from library where";
  $sql_str .= " (authors LIKE :search10) ";
  if ($totalKeywords > 1) {
  for ($i = 1 ; $i < $totalKeywords; $i++) {

  $search_bit2 = ":search1" . $i;
  $sql_str .= " AND (authors like " . $search_bit2 . ") ";

  }}




  $sql_str .= "ORDER BY authors, title ASC OFFSET $offset ROWS FETCH NEXT $resultsPerPage ROWS ONLY";

  $stmt = $cms->db->prepare($sql_str);


  // binding of values


  if (!empty($stmt)) {

  for ($x = 0; $x<$totalKeywords; $x++) {
  $keywords[$x] = "%" . $keywords[$x] . "%";

  $stmt->bindValue(':search1' . $x, $keywords[$x]);
  }

  }
  $stmt->execute();
  $array = $stmt->fetchAll();
  }











if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	
	
	
	
	
	if ($_POST['title'] != '') {
	$sT = 1;
}

if ($_POST['authors'] != '') {
	$sA = 1;
	
}

if ($_POST['title'] != '' && $_POST['authors'] != '') {
$f = 1;	
$sT = 0;
$sA = 0;
}


	
	
	
	
	
	
if ($sT === 1) {





$_SESSION['title'] = $_POST['title'];
$keywords = preg_split('/[\s]+/', $_SESSION['title']);
$totalKeywords = count($keywords);



// creation of count statement for pagination
    $str2 = "SELECT count(*) AS count from library where";
    $str2 .= " (title LIKE :search10) ";
    if ($totalKeywords > 1) {
    for ($i = 1 ; $i < $totalKeywords; $i++) {

        $search_bit2 = ":search1" . $i;
        $str2 .= " AND (title like " . $search_bit2 . ") ";

    }}

    $stmt = $cms->db->prepare($str2);
// binding of values and execution to fetch count result
    if (!empty($stmt)) {

        for ($x = 0; $x<$totalKeywords; $x++) {
            $keywords[$x] = "%" . $keywords[$x] . "%";

            $stmt->bindValue(':search1' . $x, $keywords[$x]);
            }

    }


$stmt->execute();
$row = $stmt->fetch();
$totalResults = $row['count'];
$totalPages = ceil($totalResults / $resultsPerPage);



// creation of statment to gather information via fetchall
$sql_str = "SELECT * from library where";
$sql_str .= " (title LIKE :search10) ";
if ($totalKeywords > 1) {
for ($i = 1 ; $i < $totalKeywords; $i++) {

$search_bit2 = ":search1" . $i;
$sql_str .= " AND (title like " . $search_bit2 . ") ";

}}




$sql_str .= "ORDER BY title, authors ASC OFFSET $offset ROWS FETCH NEXT $resultsPerPage ROWS ONLY";

$stmt = $cms->db->prepare($sql_str);


// binding of values


if (!empty($stmt)) {

for ($x = 0; $x<$totalKeywords; $x++) {
    $keywords[$x] = "%" . $keywords[$x] . "%";

    $stmt->bindValue(':search1' . $x, $keywords[$x]);
    }

}
$stmt->execute();
$array = $stmt->fetchAll();
}











if ($sA === 1) {





$_SESSION['authors'] = $_POST['authors'];
$keywords = preg_split('/[\s]+/', $_SESSION['authors']);
$totalKeywords = count($keywords);



// creation of count statement for pagination
    $str2 = "SELECT count(*) AS count from library where";
    $str2 .= " (authors LIKE :search10) ";
    if ($totalKeywords > 1) {
    for ($i = 1 ; $i < $totalKeywords; $i++) {

        $search_bit2 = ":search1" . $i;
        $str2 .= " AND (authors like " . $search_bit2 . ") ";

    }}

    $stmt = $cms->db->prepare($str2);
// binding of values and execution to fetch count result
    if (!empty($stmt)) {

        for ($x = 0; $x<$totalKeywords; $x++) {
            $keywords[$x] = "%" . $keywords[$x] . "%";

            $stmt->bindValue(':search1' . $x, $keywords[$x]);
            }

    }


$stmt->execute();
$row = $stmt->fetch();
$totalResults = $row['count'];
$totalPages = ceil($totalResults / $resultsPerPage);



// creation of statment to gather information via fetchall
$sql_str = "SELECT * from library where";
$sql_str .= " (authors LIKE :search10) ";
if ($totalKeywords > 1) {
for ($i = 1 ; $i < $totalKeywords; $i++) {

$search_bit2 = ":search1" . $i;
$sql_str .= " AND (authors like " . $search_bit2 . ") ";

}}




$sql_str .= "ORDER BY authors, title ASC OFFSET $offset ROWS FETCH NEXT $resultsPerPage ROWS ONLY";

$stmt = $cms->db->prepare($sql_str);


// binding of values


if (!empty($stmt)) {

for ($x = 0; $x<$totalKeywords; $x++) {
    $keywords[$x] = "%" . $keywords[$x] . "%";

    $stmt->bindValue(':search1' . $x, $keywords[$x]);
    }

}
$stmt->execute();
$array = $stmt->fetchAll();
}

	
}


if (isset($array)) {
	if ($array == false && !isset($_GET['id'])) {
		$sF = 1;
	}
}


if ($f === 1) {
	$error .= "You can't search for more than one option. <br>";
	unset($array);
}

if ($sF === 1) {
	$error .= "There was a problem. The search failed to find anything. <br>";
	unset($array);
}



echo $error;




if ($yN == 'yes' || $yN == 'YES') {
if (isset($_SESSION['deleteLibId'])) {
	
unlink($_SESSION['file_location']);
if ($cms->getMember()->deleteFromLibraryViaId($_SESSION['deleteLibId']) >= 0) { 
echo "The document was successfully deleted! <br>";	
echo '<a href="delete_document.php?unset=yes">Delete another document!</a>';
unset($array);
unset($_SESSION['file_location']);
unset($_SESSION['deleteLibid']);
}	
}
}

 




if (isset($_GET['id'])) {

$_SESSION['deleteLibId'] = $_GET['id'];
$document = $cms->getMember()->selectFromLibraryViaId($_SESSION['deleteLibId']);
$_SESSION['file_location'] = $document['file_location'];

if (isset($document)) {
?>
<h4>Are you sure the document by the title of <?= $document['title'] ?><br>
is the document you want to delete from the system?</h4>
<form action="delete_document.php?delete=yes" method="POST">
	<label for="yN">YES OR NO:</label>
	<input type="text" name="yN"><br>
	<input type="submit" value="SUBMIT!"><br>

<a href="<?= $document['file_location'] ?>">VIEW DOCUMENT!</a><br><br><br><br>
Title: <?= $document['title'] ?><br><br>
Authors: <?= $document['authors'] ?><br><br>
Description: <?php
$description = paragraph($document['description']);
echo '<p>' . $description . '</p>'; ?><br><br><br><br><br>

<?php }
}


if ($yN == 'no' || $yN == 'NO') {
?>

<form action="delete_document.php?unset=yes" method="POST">
	<label for="title">Title:</label>
	<input type="text" name="title" size="100" value="<?= $_SESSION['title'] ?? '' ?>"><br>
	<label for="authors">Authors:</label>
	<input type="text" name="authors" size="100" value="<?= $_SESSION['authors'] ?? '' ?>"><br>
	<input type="submit" value="SUBMIT!"><br><br>
	</form>
	
	
	
	<?php
	
}


if (isset($array)) {
foreach($array as $documents) { ?>

<a href="<?= $documents['file_location'] ?>">VIEW DOCUMENT!</a><br><br><br><br>
<a href="delete_document.php?id=<?= $documents['id'] ?>">DELETE DOCUMENT!</a><br><br><br>
Title: <?= $documents['title'] ?><br><br>
Authors: <?= $documents['authors'] ?><br><br>
Description: <?php
$description = paragraph($documents['description']);
echo '<p>' . $description . '</p>'; ?><br><br><br><br><br>


<?php
 }
echo "-";
for ($i = 1; $i <= $totalPages; $i++) {
    echo '<a href="delete_document.php?page=' . $i . '">' . $i . '</a> - ';
}

} ?></div>
</div>
<?php
} else {
    header("Location: how_dare_you.php");
    exit();
}
