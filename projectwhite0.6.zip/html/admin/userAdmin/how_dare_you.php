<?php 
include "../../src/bootstrap.php";
try { if (isset($_SESSION['email'])) {
$success = $cms->getMember()->insertHacker($_SERVER['REMOTE_ADDR'], $_SESSION['email']);
}}
catch(Exception $e) {
    
}

include "includes/header2.php";
?>

We're sorry. There has likely been an error. Please contact your administrator.