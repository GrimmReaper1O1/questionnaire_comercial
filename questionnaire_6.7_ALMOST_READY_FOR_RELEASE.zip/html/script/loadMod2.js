
async function loadFromIndexedDB(storeName, key, database){
    return new Promise(
      function(resolve, reject) {
        var dbRequest = indexedDB.open(database);

        dbRequest.onerror = function(event) {
          var database    = event.target.result;
          var objectStore = database.createObjectStore(storeName, {autoincrement: true});

        }

        dbRequest.onupgradeneeded = function(event) {
          // Objectstore does not exist. Nothing to load
          event.target.transaction.abort();
          reject(Error('Not found'));
        }

        dbRequest.onsuccess = function(event) {
          var database      = event.target.result;
          var transaction   = database.transaction([storeName], 'readwrite');


          transaction.onerror = function(event) {

          }

          var objectStore   = transaction.objectStore(storeName);
          var objectRequest = objectStore.get(key);

          objectRequest.onerror = function(event) {
            var database    = event.target.result;


          }

          objectRequest.onsuccess = function(event) {
            if (objectRequest.result) resolve(objectRequest.result);
            else reject();

          }

        }

      }
    )

  }


  function h4 (text) {
    var elemented = "<h4>" + text + "</h4>";
    return elemented;
  }
  function paragraph(text) {
    var para = "<p>"+text+"</p>";
    para.textContent = text;
    return para;
  }
  function paragraphs(text) {
  var paragraphs = text.split(/\r\r|\r\n/);

  var htmlParagraphs = [];

  paragraphs.forEach(function(paragraphText) {
    paragraphText = paragraphText.trim();

    var htmlParagraph = "<p>" + paragraphText + "</p>";

    htmlParagraphs.push(htmlParagraph);
  });

  var htmlOutput = htmlParagraphs.join("");


    return htmlOutput;
  }


  function countValues(obj) {
    let count = 0;

    for (let key in obj) {

        count++;
      }

    return count;
  }




function runTwo (arry, posted, color, width, colorOfText, borderColour) {

console.log(arry);
    var qr = arry['qr'];

var replyDiv = document.getElementById('reply');
var qn = {}
for (var i = 0 ; i < arry.qLength; i++ ) {

    for (var c = 1 ; c < 9 ; c++ ) {
       if (posted[i+'a'+c] === 'on') {
           qn = i;
    }
}
for (var c = 1 ; c < 9 ; c++ ) {


        if (posted[i+'a'+c] == 'on') {
var text1 = arry['a' + i][0][arry['numeral'][i]]['question'];
var text2 = arry['a' + i][0][arry['numeral'][i]]['answ' + c];
var text3 = arry['a' + i][0][arry['numeral'][i]]['hint' + c];
var text4 = arry['a' + i][0][arry['numeral'][i]]['pa' + c];
var breakLine = '<br><br>';

replyDiv.innerHTML += breakLine;

var finalText = '<div class="qanswer2" >' +
'Question: <br>' + paragraphs(text1) + "Answer given:<br>" + paragraphs(text4) + "Reply: <br>" + paragraphs(text2);



if (arry['a' + i][0][arry['numeral'][i]]['hint' + c] != 'empty') {

    finalText += "Hint given: <br>" + paragraphs(text3) + '</div>';

            } else {
                finalText += '</div>';

            }

    replyDiv.innerHTML += finalText;

    if (arry['a' + qn][0][arry['numeral'][i]]['correct'] === 'answ'+ c && posted[i+'a'+c] === 'on' ) {
      qr['a' + qn]++;
      console.log('hereo');

      arry['qAnsw']['qNumeral']['a'+i]['right']++;
    } else {
      arry['qAnsw']['qNumeral']['a'+i]['wrong']++;
      }
    }
  }
}



arry['qAnsw'];
arry['qr'] = qr;
return arry;
}

  function saveToIndexedDB(storeName, object, key, databaseName){
    return new Promise(
      function(resolve, reject) {
        if (object.id === undefined) reject(Error('object has no id.'));
        var dbRequest = indexedDB.open(databaseName);

        dbRequest.onerror = function(event) {
          reject(Error("IndexedDB database error"));
        };

        dbRequest.onupgradeneeded = function(event) {
          var database    = event.target.result;

        };

        dbRequest.onsuccess = function(event) {
          var database      = event.target.result;
          var transaction   = database.transaction([storeName], 'readwrite');
          var objectStore   = transaction.objectStore(storeName);
          var objectRequest = objectStore.put(object, key); // Overwrite if exists

          objectRequest.onerror = function(event) {
            reject(Error('Error text'));
          };

          objectRequest.onsuccess = function(event) {
            resolve('Data saved OK');

          };
          objectRequest.oncomplete = function(event) {
            var data = event.target.result;
            data.close();
          }
        };
      }
    );
  };

  async function updateDelDB(storeName, databaseName, version){
        var dbRequest = indexedDB.open(databaseName, version);

        dbRequest.onupgradeneeded = (event) => {
        var database    = event.target.result;

       database.createObjectStore(storeName, {autoincrement: true});



        };

        dbRequest.onsuccess = function(event) {

          var data = event.target.result;
          data.close();
        }

        dbRequest.onerror = function(event) {

          };

        };


        function openDB(storeName, databaseName){
          var dbRequest = indexedDB.open(databaseName);

          dbRequest.onupgradeneeded = function(event) {
            var database    = event.target.result;
            var objectStore = database.createObjectStore(storeName, {autoincrement: true});

          };

          dbRequest.onsuccess = function(event) {
          }

          dbRequest.onerror = function(event) {
              reject(Error('Error text'));
            };

          };
          function deleteDB(databaseName) {
          var db = indexedDB.deleteDatabase(databaseName);
          db.onsuccess = function (event) {

              window.location.replace('/questionnaire.php?reset=yes');

          }
          db.oncomplete = function (event) {
            var database = event.target.result;
            database.close();
          }

          db.onerror = function (event) {

          }
        }

        function createStoreDB(storeName, databaseName){
          var dbRequest = indexedDB.open(databaseName);

          dbRequest.onupgradeneeded = function(event) {

          };

          dbRequest.onsuccess = function(event) {
            var database    = event.target.result;
            var objectStore = database.createObjectStore(storeName, {autoincrement: true});

          }

          dbRequest.onerror = function(event) {
              reject(Error('Error text'));
            };

          };

(function(){
let runOrNot = 0;
let rem = localStorage.getItem('rem');
let place = localStorage.getItem('arry');
let pg = localStorage.getItem('pg')
let qAnsw = JSON.parse(localStorage.getItem(pg));
console.log(place);
  let arry = JSON.parse(place);


arry.qAnsw.qNumeral = qAnsw;
  console.log(arry);
  arry = runTwo(arry, posted, style);
  let qr = arry['qr'];
  console.log('arry')
console.log(arry);

  localStorage.setItem('qr', JSON.stringify(qr));
  localStorage.setItem('arry', JSON.stringify(arry));
  localStorage.setItem(pg, JSON.stringify(arry.qAnsw.qNumeral));
  console.log(arry);console.log('here');
  console.log(arry.qAnsw);
  // if (fast != 'undefined') {
  //   saveToIndexedDB(storeName, {id: arry}, key, databaseName);
  //   }



}());
