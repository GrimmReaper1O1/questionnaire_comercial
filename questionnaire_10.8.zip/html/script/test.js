(function(){
  console.log(test);
}());
