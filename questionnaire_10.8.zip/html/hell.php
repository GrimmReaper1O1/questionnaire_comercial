<?php
echo 'hello world';
