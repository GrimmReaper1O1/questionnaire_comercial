
<?php
$currentPath = rtrim(__DIR__, DIRECTORY_SEPARATOR); include "includes/header3.php";
if (isset($_GET['reset'])) {
	unset($_SESSION['page']);
	
	
}
if  (isset($_GET['unset'])) {
unset($_SESSION['rowAndCounter']['counter']);
unset($_SESSION['questionInformation']['point']);
unset($_SESSION['chosenNumbers']);
unset($_SESSION['count']);
unset($_SESSION['test']);
unset($_SESSION['test2']);	
unset($_SESSION['offset']);
unset($_SESSION['questionInformation']);
unset($_SESSION['questionDesc']);
unset($_SESSION['number']);
	}

$_SESSION['page'] = $_GET['page'] ?? 1;
if (isset($_GET['id'])) {
	$_SESSION['subject'] = $_GET['id'];
}
if (!isset($_SESSSION['rowAndCounter'])) {
	

$counter = $cms->getQuestions()->countQuestionIdsViaSubjectAndClass();

$_SESSION['rowAndCounter']['counter'] = $counter;

}
if ($_SESSION['rowAndCounter']['row'] != false) {
	if ($_SESSION['rowAndCounter']['row']['number_of_questions'] == 2) {
		$_SESSION['number_of_questions'] = $_SESSION['rowAndCounter']['row']['number_of_questions'];
	}

}

if ($_SESSION['rowAndCounter']['row'] != false) {
	if(isset($_SESSION['rowAndCounter']['row']['number_of_questions'])) {
		$limit = $_SESSION['rowAndCounter']['row']['number_of_questions'];	
	} else {
		$limit = 3;
	}
	if(isset($_SESSION['rowAndCounter']['row']['number_of_removal'])) {
		$numberOfRemoval = $_SESSION['rowAndCounter']['row']['number_of_removal'];
	} else {
		$numberOfRemoval = 4;
	}

}




//if (isset($x)) {

if (isset($_SESSION['page_question_count']) && isset($_POST['submit2'])) {
	for($i = 0; $i < $_SESSION['page_question_count']; $i++) {
		
		for($c = 0; $c < $_SESSION['number_of_questions'] + 1; $c++) {
			if (isset($_POST[$i . 'a' . $c])) {
				echo "<b>Message:</b><br>";
				echo "<p>" . paragraph($_SESSION[$i .'answ' . $c]) . "</p><br>";
				echo "<b>Quesiton:</b><br>";
				echo "<p>" . paragraph($_SESSION[$i .'question']) . "</p><br>";
				echo "<b>Answer chosen:</b><br>";
				echo "<p>" . paragraph($_SESSION[$i .'pa' . $c]) . "</p><br>";
				echo "<b>Hint given:</b><br>";
				if($_SESSION[$i .'hint' . $c] !== "empty") {
				echo "<p>" . paragraph($_SESSION[$i .'hint' . $c]) . "</p><br><br>";
				}
			if ($_SESSION[$i . 'correct'] == 'answ' . $c && isset($_POST[$i . 'a' . $c])) {	
				$_SESSION['question' . $i]++;
			}
			
	
			}
		}
	} ?>

<form action-"questionair.php" method='POST'>
<input type="submit" name='submit' value="AGAIN!">
</form>


<?php
}







if ((isset($_POST['submit']) || isset($_GET['unset']))) {
	
	
	$_SESSION['number_of_questions'] = $_SESSION['rowAndCounter']['row']['number_of_questions'];
	
	if (isset($_GET['unset'])) {
		 
	$questionDesc = $cms->getQuestions()->selectAllQuestionsFromSubjectPagination($_SESSION['page'], $limit);
	$_SESSION['questionDesc'] = $questionDesc;
	
	}
	

	

	if  (isset($_GET['unset'])) {
		$_SESSION['page_question_count'] = count($_SESSION['questionDesc'][1]);
		echo count($_SESSION['questionDesc'][1]);
		for($c = 0; $c < $limit; $c++) {
			unset($_SESSION['lastNum' . $c]); 
		}
		if (isset($_GET['unset'])) {
					for($i = 0; $i < $limit; $i++) {
					unset($_SESSION['question' . $i]);
					
					}
		for($c = 0; $c < $limit; $c++) {
			$_SESSION['lastNum' . $c] = 0;
			$_SESSION['question' . $c] = 0;
		}
	
		}
	
}


	if ($_SESSION['questionDesc'][1] != false) {

?>

<form action="questionair.php" method="POST">

<?php

		for($c = 0; $c < $limit; $c++) {

			
			if (isset($_SESSION['questionDesc'][1][$c])) {
				if (isset($_GET['unset'])) {
					unset($_SESSION['count'][$c]);
				}
				
			if (!isset($_SESSION['count']['$c'])) {
				
			$_SESSION['count'][$c] = $cms->getQuestions()->countNumberOfQuestions($_SESSION['questionDesc'][1][$c]['question_id']);
			}
			$count1 = $_SESSION['count'][$c]['count'];
			$totalPages = ceil(($_SESSION['rowAndCounter']['counter']['count'] / $limit));
			$offset = selectRandomNumberNotInArray($_SESSION['questionDesc'][1][$c]['question_id'], $count1);
			if(!isset($_SESSION['offset']["a" . $_SESSION['questionDesc'][1][$c]['question_id']]['offs']['offset'])) {
				$_SESSION['offset']["a" . $_SESSION['questionDesc'][1][$c]['question_id']]['offs']['offset'] = rand(0, $count1);
			}
			$info = $cms->getQuestions()->selectQuestion($_SESSION['questionDesc'][1][$c]['question_id'], $count1, $_SESSION['offset']["a" . $_SESSION['questionDesc'][1][$c]['question_id']]['offs']['offset'], $offset);
			if(isset($_SESSION['questionInformation'])) {
			echo $_SESSION['test'];
			echo $_SESSION['count3'];
			echo $_SESSION['count1'];
			echo $_SESSION['offset']["a" . $_SESSION['questionDesc'][1][$c]['question_id']]['offs']['offset'];
			//print_r($_SESSION['questionInformation']);
			}
			print_r($info);
			if (isset($info)) {
				echo "what the";
			}
			if (!isset($information)) {
			
			
			$_SESSION['lastNum' . $c] = $_SESSION['chosenNumbers']['point']["a" . $_SESSION['questionDesc'][1][$c]['question_id']]['offs']['offset'];
			$_SESSION['description' . $c] = $_SESSION['questionDesc'][1][$c]['description'];
		
			if ($info != false) {  
			if (isset($info['question'])) { ?>	
<?php 
			
				if ($_SESSION['question' . $c] < $numberOfRemoval) {
	
						echo "<p>" . $info['question'] . "</p>" ?><br>
					
<?php			
						$_SESSION[$c . 'question'] = $info['question'];
						$_SESSION[$c . 'correct'] = $info['correct'];
				
					for($i = 1; $i <= 8; $i++) {

						if ($info['pa' . $i] != 'empty') {
?>

<input type="radio" name="<?= $c . "a" . $i ?>"> <p>
<?php 
							echo paragraph($info['pa' . $i]); ?></p>

<?php 
						}	
	
						if ($info['hint' . $i] != 'empty') { echo paragraph($info['hint' . $i]); } ?></p>	
<?php 
							$_SESSION[$c .'answ' . $i] = $info['answ' . $i];
							$_SESSION[$c . 'pa' . $i] = $info['pa' . $i];
							$_SESSION[$c . 'hint' . $i] = $info['hint' . $i];
							
						}
					}
				?> 
				
<br><br>
			<?php				
			} else { 
 echo $_SESSION['number']; echo $_SESSION['count2'];
						echo "There is no question information assigned to question ID:" . $_SESSION['questionDesc'][1][$c]['question_id'];

					}
					} 
		
		
		
		
		}
		
		
		
		
		
		
			}
		}
	 

?> 

<input type="submit" name="submit2" value="SUBMIT!">
</form>
<form action="questionair.php?unset=yes&page=<?= $_SESSION['page'] ?>" method="POST">
				<input type="submit" value="RESET PAGE!">
				</form>
		<?php		
	// if ($infFalse > 0) {		echo "There is no quesiton information assigned.";}
for($i = 1; $i <= $totalPages; $i++){
?>
<a href="questionair.php?unset=yes&page=<?= $i ?>"><?= $i ?>-</a>
<?php
}
}
}

//}