<?php 
namespace MySite\CMS;                                   // Declare namespace

class Library
{
protected $db;
	public function __construct(Database $db)
	{
		$this->db = $db;
	}

	public function searchViaLetterPagination($limit) {
		$arguments['letter'] = $_SESSION['letter'];
		$arguments['classId'] = $_SESSION['class'];
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$limit = strval($limit);
		$offset = ($_SESSION['page'] - 1) * $limit;	
		$limit = preg_replace($patterns, $replacements, $limit);		
		$sql = "SELECT count(*) AS count from library where ";
		$sql .= " left(title, 1) like :letter and class_id like :classId";
		$result[0] = $this->db->runSql($sql, $arguments)->fetch();
		
		$sql = "SELECT * from library where";
		$sql .= " left(title, 1) like :letter and class_id like :classId";
		$sql .= " order by title offset " . $offset . " rows fetch next ";
		$sql .= $limit . " rows only";
		$result[1] = $this->db->runSql($sql, $arguments)->fetchAll();
		
		return $result;
	}
	public function searchAlphabeticallyPagination($limit) {
		$arguments['classId'] = $_SESSION['class'];
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$limit = strval($limit);
		$offset = ($_SESSION['page'] - 1) * $limit;	
		$limit = preg_replace($patterns, $replacements, $limit);		
		$sql = "SELECT count(*) AS count from library where ";
		$sql .= " class_id like :classId";
		$result[0] = $this->db->runSql($sql, $arguments)->fetch();
		
		$sql = "SELECT * from library where";
		$sql .= " class_id like :classId";
		$sql .= " order by title, authors offset " . $offset . " rows fetch next ";
		$sql .= $limit . " rows only";
		$result[1] = $this->db->runSql($sql, $arguments)->fetchAll();
		
		return $result;
	}
	
	
	public function selectTitleFromLibrary($limit) {
	
		$patterns[2] = '/ for /';
		$patterns[3] = '/ and /';
		$patterns[4] = '/ nor /';
		$patterns[5] = '/ but /';
		$patterns[6] = '/ or /';
		$patterns[7] = '/ yet /';
		$patterns[8] = '/ so /';
		$patterns[9] = '/ a /';
		$patterns[10] = '/ the /';
		$patterns[11] = '/ an /';
		$replacements[0] = '';
		$replacements[1] = ' ';
		$replacements[2] = ' ';
		$replacements[3] = ' ';
		$replacements[4] = ' ';
		$replacements[5] = ' ';
		$replacements[6] = ' ';
		$replacements[7] = ' ';
		$replacements[8] = ' ';
		$replacements[9] = ' ';
		$replacements[10] = ' ';
		$replacements[11] = ' ';
		$offset = ($_SESSION['page'] - 1) * $limit;	
		
		$title = preg_replace($patterns, $replacements, $_SESSION['title']);
		$keywords = preg_split('/[\s]+/', $title);
		$totalKeywords = count($keywords);
		
		for ($i = 0; $i < $totalKeywords; $i++) {
			$arguments['search1' . $i] = "%" . $keywords[$i] . "%";
						
		}
		
		$arguments['classId'] = $_SESSION['class'];
		$patterns2[0] = '/;/';
		$patterns2[1] = '/go/';
		$replacements2[0] = '';
		$replacements2[1] = '';
		$limit = preg_replace($patterns2, $replacements2, $limit);
		$sql1 = "SELECT count(*) AS count from library where class_id like :classId and";
		$sql1 .= " title LIKE :search10 ";

		if ($totalKeywords > 1) {

			for ($i = 1 ; $i < $totalKeywords; $i++) {
				$sql1 .= " AND title like :search1" . $i;
			}

		}

		$result[0] = $this->db->runsql($sql1, $arguments)->fetch();

	  if (!empty($result[0])) {
		
			$sql2 = "SELECT * from library where class_id like :classId and";
			$sql2 .= " title LIKE :search10 ";
		
		if ($totalKeywords > 1) {
			for ($i = 1 ; $i < $totalKeywords; $i++) {

				$sql2 .= " AND title like :search1" . $i;

		}
	}

		$sql2 .= " ORDER BY title, authors ASC OFFSET $offset ROWS FETCH NEXT $limit ROWS ONLY";

		$result[1] = $this->db->runSql($sql2, $arguments)->fetchAll();
} 		$result[2] = $keywords;
		
		return $result;

		}
	
	public function insertIntoLibrary($author, $title, $destination, $description, $userId, $classId) {
       
		$arguments['author'] = $author ;
        $arguments['title'] = $title ;
        $arguments['description'] = $description ;
        $arguments['destination'] = $destination ;
        $arguments['userId'] = $userId ;
		$arguments['class'] = $classId;
        $sql = "INSERT INTO library (class_id, file_location, authors, description, user_id, title) values";
        $sql .= " (:class, :destination, :author, :description, :userId, :title)";
        return $this->db->runsql($sql, $arguments);
    }
}