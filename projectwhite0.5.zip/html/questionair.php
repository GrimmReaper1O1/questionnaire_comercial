<?php
include "includes/header3.php";
$page = $_GET['page'] ?? 1;
if (isset($_GET['id'])) {
	$_SESSION['subject'] = $_GET['id'];
}
$row = $cms->getQuestions()->selectSubjectViaTableId($_SESSION['subject']);

if ($row != false) {
	if ($row['number_of_questions'] == 2) {
		$limit = 6;
	}
	if ($row['number_of_questions'] > 2 && $row['number_of_questions'] <= 4) {
		$limit = 4;
	}
	if ($row['number_of_questions'] > 4 && $row['number_of_questions'] < 7) {
		$limit = 3;
	}
	if ($row['number_of_questions'] >= 7 && $row['number_of_questions'] == 8) {
		$limit = 2;
	}

}
$info = $cms->getQuestions()->selectQuestionsInfo($_SESSION['subject'], $page, $limit);

if (!isset($_SESSION['removeQuestionAfter'])) {
$removeQuestionAfter = 4;
}






if (isset($_SESSION['page_question_count']) && isset($_POST['submit2'])) {
	for($i = 0; $i < $_SESSION['page_question_count']; $i++) {
		
		for($c = 1; $c < $_SESSION['number_of_questions'] + 1; $c++) {
			if (isset($_POST[$i . 'a' . $c])) {
				echo "<b>Message:</b><br>";
				echo "<p>" . paragraph($_SESSION[$i .'answ' . $c]) . "</p><br>";
				echo "<b>Quesiton:</b><br>";
				echo "<p>" . paragraph($_SESSION[$i .'question']) . "</p><br>";
				echo "<b>Answer chosen:</b><br>";
				echo "<p>" . paragraph($_SESSION[$i .'pa' . $c]) . "</p><br>";
				echo "<b>Hint given:</b><br>";
				echo "<p>" . paragraph($_SESSION[$i .'hint' . $c]) . "</p><br><br>";
				
			if ($_SESSION[$i . 'correct'] == 'answ' . $c) {	
				$_SESSION['question' . $i]++;
			}
			
	
			}
		}
	} ?>

<form action-"questionair.php" method='POST'>
<input type="submit" name='submit' value="AGAIN!">
</form>


<?php
}







if (isset($_POST['submit']) || isset($_GET['unset'])) {
	

	$_SESSION['number_of_questions'] = $row['number_of_questions'];
	$questionDesc = $cms->getQuestions()->selectAllQuestionsFromSubjectPagination($page, $limit);
	print_r($questionDesc);

	if  (isset($_GET['unset'])) {
		$_SESSION['page_question_count'] = count($questionDesc[1]);
	echo $_SESSION['page_question_count'];
		for($c = 0; $c < $limit; $c++) {
			unset($_SESSION['lastNum' . $c]); 
		}

		for($c = 0; $c < $limit; $c++) {
			$_SESSION['lastNum' . $c] = $c;
		}
	if (isset($_GET['unset'])) {
			for($i = 0; $i < $_SESSION['page_question_count']; $i++) {
			unset($_SESSION['question' . $i]);
			
			}
		}
	if (isset($_GET['unset'])) {
		
		for($c = 0; $c < $limit; $c++) {
			$_SESSION['question' . $c] = 0;
		}
	}
}


	if ($questionDesc[1] != false) {

?>

<form action="questionair.php" method="POST">

<?php
			echo $_SESSION['page_question_count'];
		for($c = 0; $c <= $_SESSION['page_question_count']; $c++) {

			
			if (isset($questionDesc[1][$c])) {
			$count = $cms->getQuestions()->countNumberOfQuestions($questionDesc[1][$c]['question_id']);
			
			$_SESSION['lastNum' . $c] = $info[1];
			$_SESSION['description' . $c] = $questionDesc[1][$c]['description'];
			print_r($info[1]);
			if ($info[1] != false) {  
			if (isset($info[1][1][$c]['question'])) {?>	
<?php 
				
				if ($_SESSION['question' . $c] <= 4) {
						
						$_SESSION[$c . 'question'] = $info[3][$c]['question'];
						$_SESSION[$c . 'correct'] = $info[3][$c]['correct'];
				echo "<p>" . $info[1]['question'] . "</p>" ?><br>
					for($i = 1; $i < ($row['number_of_questions'] + 1); $i++) {
						
				
						if ($info[3]['pa' . $i] != 'empty') {
?>

<input type="radio" name="<?= $c . "a" . $i ?>"> <p>
<?php 
							echo paragraph($info[1][1][$c]['pa' . $i]); ?></p>

<?php 
						}	
	
						if ($info[3]['hint' . $i] != 'empty') { echo paragraph($info[3]['hint' . $i]); } ?></p>	
<?php 
							$_SESSION[$c .'answ' . $i] = $info[3][$c]['answ' . $i];
							$_SESSION[$c . 'pa' . $i] = $info[3][$c]['pa' . $i];
							$_SESSION[$c . 'hint' . $i] = $info[3][$c]['hint' . $i];
							
						}
					}
?>
<br><br>
			<?php				}
					
		}
		} else { 
 
						echo "There is no question information assigned to question ID:" . $questionDesc[1][$c]['question_id'];

					}
		}
	 

?> 

<input type="submit" name="submit2" value="SUBMIT!">
</form><?php

	// if ($infFalse > 0) {		echo "There is no quesiton information assigned.";}

