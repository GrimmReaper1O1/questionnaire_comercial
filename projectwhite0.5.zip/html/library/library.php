<?php
include "../includes/header4.php";
if ($administrator['admin'] == 1) {
$limit = 1;
$_SESSION['page'] = isset($_GET['page']) ? $_GET['page'] : 1;
$limit = 15;
$f = 0;
$sF = 0;
$error = '';
$sA = 0;
$sD = 0;
$sT = 0;



	if (isset($_GET['unset'])) {

		unset($_SESSION['title']);
		unset($_SESSION['letter']);
		unset($_SESSION['alphabet']);

		}
	if (isset($_GET['reset'])) {
		
		unset($_SESSION['title']);
		unset($_SESSION['letter']);
		$_SESSION['alphabet'] = 1;

	}


	if (isset($_GET['letter'])) {

		$_SESSION['letter'] = $_GET['letter'];
	}
	if (isset($_POST['title'])) {
		
		$_SESSION['title'] = $_POST['title'];
	
	}
	if (isset($_SESSION['alphabet'])) {
		
		$array = $cms->getLibrary()->searchAlphabeticallyPagination($limit);
		$totalResults = $array[0]['count'];
		$totalPages = ceil($totalResults / $limit);
		
	}

    if (isset($_SESSION['letter'])) {

		$array = $cms->getLibrary()->searchViaLetterPagination($limit);
		$totalResults = $array[0]['count'];
		$totalPages = ceil($totalResults / $limit);

	}



	if (isset($_SESSION['title'])) {
		$array = $cms->getLibrary()->selectTitleFromLibrary($limit);
		$totalResults = $array[0]['count'];
		$totalPages = ceil($totalResults / $limit);
   
		

	}






if (isset($array[1])) {
	if ($array[1] == false) {
		$sF = 1;
	}
}


$letterString = 'A B C D E F G H I J K L M N O P Q R S T U V W X Y Z';

$letterArray = preg_split('/[\s]+/', $letterString);





if ($sF === 1) {
	$error .= "There was a problem. The search failed to find anything. <br>";
	
}



echo $error;
?>
<div>
 
<?php
foreach($letterArray as $letters) { ?>

<?= "-" ?><a href="library.php?unset=yes&letter=<?= $letters ?>"><?= $letters ?></a><?= "-" ?>
<?php
} 
?><br><br>
<a href="library.php?reset=yes">List all books</a>
 <br><br>
<div id='main'>
<form action="library.php?unset=yes" method="POST">
  <label for="title">Title:</label><br>
  <input type="text" name="title" size="100" value="<?= $_SESSION['title'] ?? '' ?>"><br>

<input type="submit" value="SUBMIT!">
</form>


<?php


if (isset($array[1])) {
	
	if($array[1] != false) {
		
		foreach($array[1] as $documents) { 
?>


ID:<?= $documents['id'] ?><br>
<a href="<?= $documents['file_location'] ?>">VIEW DOCUMENT</a><br><br>
Title: <?= $documents['title'] ?><br><br>
Authors: <?= $documents['authors'] ?><br><br>
Description: <?php
$description = paragraph($documents['description']);
echo '<p>' . $description . '</p>'; ?><br><br>



<?php }
echo "-";
for ($i = 1; $i <= $totalPages; $i++) {
    echo '<a href="library.php?page=' . $i . '">' . $i . '</a> - ';
		}
	}
} 
?>
</div>
</div>
<?php
} else {
    header("Location: how_dare_you.php");
    exit();
}