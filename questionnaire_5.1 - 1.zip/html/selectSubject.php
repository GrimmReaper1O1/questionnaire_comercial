<?php
include 'includes/header3.php';
$class = $_GET['class'] ?? '';

$page = $_GET['page'] ?? 1;
$limit = 10;
$error = '';



if (isset($_GET['class'])) {
	$_SESSION['class'] = $class;


$subjectsArray = $cms->getQuestions()->selectAllFromSubjectsLive($_SESSION['class']);

if (isset($subjectsArray)) {
	
foreach($subjectsArray as $subjects) {
	
	 if ($subjects['subject_information'] != 'empty') 
	{ echo '<h3>SUBJECT:<br> <a href="introductionToSubject.php?unset=yes&id=' . $subjects['table_id'] . '">' . $subjects['subject_information'] . '</a>'; } 
	if ($subjects['subject_information'] != 'empty') { ?></h3><p>
	The subject requires you answer the multiple choice questions <?php if ($subjects['number_of_removal'] > 1) 
	{ echo $subjects['number_of_removal'] . " times"; } else { echo $subjects['number_of_removal'] . " time "; } ?>
	per question set to progress through the page.</p>
	
<?php 

}
}
}
}

