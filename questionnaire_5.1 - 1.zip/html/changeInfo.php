<?php 
include "includes/header3.php";

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	
$result = $cms->getMember()->updateInfo($_POST['email'], $_POST['phone'], $_SESSION['id']);	
	if ($result > 0) {
		$error .= "The update was successfull!";
	} else {
		$error .= "The update failed.";
	}
}

$row = $cms->getMember()->getViaId($_SESSION['id']);

echo $error . "<br><br>";
?>

<form action="changeInfo.php" method="POST">
<label for="email">Email:</label><br>
<input type="text" name="email" size="80" value="<?= $row['email'] ?>"><br>
<label for="phone">Phone number:</label><br>
<input type="text" name="phone" size="80" value="<?= $row['phone_number'] ?>"><br>
<input type="submit" value="UPDATE!">
</form>