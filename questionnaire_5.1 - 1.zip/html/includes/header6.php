<?php
?>
<html>
    <head></head>
    <body>
    <h1><a href="signup.php">Sign Up!</a> | <a href="login.php">Log In!</a></h1>