<?php
?>
<html>
    <head></head>
    <body>
    <h1><a href="login.php">Log In!</a> | <a href="index.php">Back To Main Page!</a></h1>