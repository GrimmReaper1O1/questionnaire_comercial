<?php
include "../includes/header4.php";
if ($_SESSION['administrator']['admin'] == 1) {
$error = '';
$enter = 0;
$page = $_GET['page'] ?? 1;
$limit = 15;
$error = '';
if (isset($_GET['unset'])) {
	unset($_SESSION['subject']);
	unset($_SESSION['class']);
	unset($_SESSION['subject_information']);
}
if (isset($_GET['class'])) {
if ($_GET['class'] > 0 && $_GET['class'] != '') {
$_SESSION['class'] = $_GET['class'];

}
}
if (isset($_GET['updateSubject'])) {
$_SESSION['subject'] = $_GET['updateSubject'];

}
$start = microtime(true);
$subjectInfo = $cms->getQuestions()->selectSubjectViaTableIdAndClassId();



$subjectInfo['number_of_questions'] = isset($_POST['number']) ? $_POST['number'] : $subjectInfo['number_of_questions'];
$subjectInfo['subject_information'] = isset($_POST['number']) ? $_POST['name'] : $subjectInfo['subject_information'];

if (isset($subjectInfo)) {
	
	if ($subjectInfo['live'] == 0 || $_SESSION['administrator']['root'] == 1) {
	
	$enter = 1;
	
	}
	}

if ($enter == 1 || $_SESSION['administrator']['root'] == 1) {
	if (isset($_POST['name'])) {
	if ($_POST['name'] != '' && $_POST['number'] != '') {
	$result = $cms->getQuestions()->updateSubjectNameAndNumberOfQuestions($_SESSION['subject'], $_POST['name'], $_POST['number']);
	if ($result == 1) {
		$error .= "THE UPDATE OF NAME WAS SUCCESSFULL!<br>";
	}
	else
	{
		$error .= "THE UPDATE OF NAME WAS NOT SUCCESSFULL.<br>";
	}
	
	}
}
	


}
	}



if ($enter == 1) {

echo $error . "<br><br>";
	?>
	<a href="subjects.php?class=<?= $_SESSION['class'] ?>">BACK TO SUBJECTS!</a><br><br>

	PLEASE ENTER THE NEW NAME AND NUMBER OF QUESTIONS TO SHOW ON PAGE.<br>
	YOU MAY ENTER EITHER OR BOTH.<br>
	<form action="updateSubject.php" method="POST">
		<label for="name">ENTER NEW NAME:</label><br>
		<input type="text" name="name" size="100" value="<?= $subjectInfo['subject_information'] ?>"><br>
		<label for="number">ENTER NEW NUMBER OF QUESITONS ON PAGE:</label><br>
		<input type="text" name="number" size="100" value="<?= $subjectInfo['number_of_questions'] ?>"><br>
		<input type="submit" value="SUBMIT!">
		</form>
	<?php
	}
	
