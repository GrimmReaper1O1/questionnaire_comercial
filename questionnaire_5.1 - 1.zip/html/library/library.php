<?php
include "../includes/header7.php";

$limit = 1;
$_SESSION['page'] = isset($_GET['page']) ? $_GET['page'] : 1;

$f = 0;
$sF = 0;
$error = '';
$sA = 0;
$sD = 0;
$sT = 0;



	if (isset($_GET['unset'])) {

		unset($_SESSION['title']);
		unset($_SESSION['letter']);
		unset($_SESSION['alphabet']);
		unset($_SESSION['authors']);
		unset($_SESSION['description']);
		unset($_SESSION['title']);
		}
		
	if (isset($_GET['reset'])) {
		unset($_SESSION['authors']);
		unset($_SESSION['description']);
		unset($_SESSION['title']);
		unset($_SESSION['letter']);
		$_SESSION['alphabet'] = 1;

	}


	if (isset($_GET['letter'])) {

		$_SESSION['letter'] = $_GET['letter'];
	}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	if (isset($_POST['title'])) {
		
		$_SESSION['title'] = $_POST['title'];
	
	}
	if (ISSET($_POST['author'])) {
	if ($_POST['author'] != "") {
		
		$_SESSION['authors'] = $_POST['author'];
	
	}
	if ($_POST['description'] != '') {
		
		$_SESSION['description'] = $_POST['description'];
	
	}
	}
}

	if (isset($_SESSION['alphabet'])) {
		if  (!isset($_SESSION['class'])) {
			$array = $cms->getLibrary()->searchAlphabeticallyPaginationNC($limit);	
		} else {
		$array = $cms->getLibrary()->searchAlphabeticallyPagination($limit);
		}
		$totalResults = $array[0]['count'];
		$totalPages = ceil($totalResults / $limit);
		
	}

    if (isset($_SESSION['letter'])) {
		if  (!isset($_SESSION['class'])) {
		$array = $cms->getLibrary()->searchViaLetterPaginationNC($limit);
		} else {
		$array = $cms->getLibrary()->searchViaLetterPagination($limit);
		}
		$totalResults = $array[0]['count'];
		$totalPages = ceil($totalResults / $limit);

	}



	if (isset($_SESSION['title'])) {
		if  (!isset($_SESSION['class'])) {
		$array = $cms->getLibrary()->selectTitleFromLibraryNC($limit);
		} else {
		$array = $cms->getLibrary()->selectTitleFromLibrary($limit);
		}
		
		$totalResults = $array[0]['count'];
		$totalPages = ceil($totalResults / $limit);
   
		

	}


	if (isset($_SESSION['authors'])) {
		if  (!isset($_SESSION['class'])) {
		$array = $cms->getLibrary()->selectAuthorFromLibraryNC($limit);
		} else {
		$array = $cms->getLibrary()->selectAuthorFromLibrary($limit);
		}
		$totalResults = $array[0]['count'];
		$totalPages = ceil($totalResults / $limit);
	}

	if (isset($_SESSION['description'])) {
		if  (!isset($_SESSION['class'])) {
		$array = $cms->getLibrary()->selectDescriptionFromLibraryNC($limit);
		} else {
		$array = $cms->getLibrary()->selectDescriptionFromLibrary($limit);
		}
		$totalResults = $array[0]['count'];
		$totalPages = ceil($totalResults / $limit);
   
	}





if (isset($array[1])) {
	if ($array[1] == false) {
		$sF = 1;
	}
}


$letterString = 'A B C D E F G H I J K L M N O P Q R S T U V W X Y Z';

$letterArray = preg_split('/[\s]+/', $letterString);





if ($sF === 1) {
	$error .= "There was a problem. The search failed to find anything. <br>";
	
}



echo $error;
?>
<div>
 
<?php
foreach($letterArray as $letters) { ?>

<?= "-" ?><a href="library.php?unset=yes&letter=<?= $letters ?>"><?= $letters ?></a><?= "-" ?>
<?php
} 
if (isset($_SESSION['class'])) {
	echo "<br><br>You are searching in a class. To search entire site return to class selection page.<br><br>";
} else {
	echo "<br><br>You are searching the entire site. To search an individual class enter a class and return to the library.<br><br>";
}
?><br><br>
<a href="library.php?reset=yes">List all books</a>
 <br><br>
<div id='main'>
<form action="library.php?unset=yes" method="POST">
  <label for="title">Title:</label><br>
  <input type="text" name="title" size="100" value="<?= $_SESSION['title'] ?? '' ?>"><br>
  <?php
  if (!isset($_SESSION['class'])) {
	  ?>
	    <label for="author">Author or authors:</label><br>
  <input type="text" name="author" size="100" value="<?= $_SESSION['authors'] ?? '' ?>"><br>
  <label for="description">Description:</label><br>
  <input type="text" name="description" size="100" value="<?= $_SESSION['description'] ?? '' ?>"><br>
	  
	  
	  
	  <?php
  }  
?>
<input type="submit" value="SUBMIT!">
</form>


<?php


if (isset($array[1])) {
	
	if($array[1] != false) {
		
		foreach($array[1] as $documents) { 
?>


ID:<?= $documents['id'] ?><br>
<a href="<?= $documents['file_location'] ?>">VIEW DOCUMENT</a><br><br>
Title: <?= $documents['title'] ?><br><br>
Authors: <?= $documents['authors'] ?><br><br>
Description: <?php
$description = paragraph($documents['description']);
echo '<p>' . $description . '</p>'; ?><br><br>



<?php }
echo "-";
for ($i = 1; $i <= $totalPages; $i++) {
    echo '<a href="library.php?page=' . $i . '">' . $i . '</a> - ';
		}
	}
} 
?>
</div>
</div>
<?php
