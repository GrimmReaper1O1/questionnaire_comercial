<?php
	include "../src/bootstrap.php";
	$start = microtime(true);
		$cms->getQuestions()->insertQuestionDescription("test", 1);
		$_SESSION['class'] = 8;


	$question = "What is the meaining of life in a metaphysical sense? What is it that we should know about the
	metaphysical aspects of life and that which we sould all aspire to,
	that of which we should all try to achieve and that which we should never miss. What is that which we should
	experience within ourselves and that which we should experience
	exteranlly. What is it that we should show to others and that which we should admire in others as well as
	foster in ourselves? What is the truth of our existance and thus the
	meaning of life? What is it that life means and what should we do?";

	$_SESSION['subject'] = 1;
	$_SESSION['class'] = 2;
	for($z = 1 ; $z <=  8 ; $z++ ) {

	$pa[$z] = "The meaning of life is simply to experience a good life but what is a good life.
	Is it to have every possession imaginable or that which we yern for? is it to be materialistic in
	the way a billionaire could be? Having every want accounted for and thus purchased or given to us?
	Is it to be humble and save thus turning away from all material possessions? Or is it to be somewhere
	in between? In this regard the placation of desire in regards to material possessions is to have that
	 of wich we need and that which contribute to the overall happiness and needs of our loved ones and family while
	 preparing for teh times ahead, thus storing our nuts for the winter. But what about the metaphysical aspects. One
	 must work to experience a serenity, thus a lack of conflict in their lives which fosters their overall happiness
	through the social aspects of interpersonal relationships. The truth is one must learn to understand others and their
	 actions to let go of that which fosters anger and hatred in favour of love and friendship. One should admire
	those whom have reached this level of nivarna without their happiness being dependent on their material possessions.
	The truth of our existence is that we should aspire to live the best life we can live in regards to our emotions,
	not the experience of hightened levels but the lack of hatred, angish, and sorrow in favour of our overall happiness
	and serenity. Whatever stage of life we are in we are ever changing and must also guide our change in the persuit
	of our overall happiness, thus we must guide our change. Education is one of the many means we can utilize to accomplish
	this and the purpose of life is to learn from everything.";
	}
	for($z = 1 ; $z <=  8 ; $z++ ) {
	$answ[$z] = "The meaning of life is simply to experience a good life but what is a good life. Is it to have every possession imaginable or that which we yern for? is it to be materialistic in
	the way a billionaire could be? Having every want accounted for and thus purchased or given to us? Is it to be humble and save thus turning away from all material possessions? Or is it to be somewhere
	in between? In this regard the placation of desire in regards to material possessions is to have that of wich we need and that which contribute to the overall happiness and needs of our loved ones and family while
	preparing for teh times ahead, thus storing our nuts for the winter. But what about the metaphysical aspects. One must work to experience a serenity, thus a lack of conflict in their lives which fosters their overall happiness
	through the social aspects of interpersonal relationships. The truth is one must learn to understand others and their actions to let go of that which fosters anger and hatred in favour of love and friendship. One should admire
	those whom have reached this level of nivarna without their happiness being dependent on their material possessions. The truth of our existence is that we should aspire to live the best life we can live in regards to our emotions,
	not the experience of hightened levels but the lack of hatred, angish, and sorrow in favour of our overall happiness and serenity. Whatever stage of life we are in we are ever changing and must also guide our change in the persuit
	of our overall happiness, thus we must guide our change. Education is one of the many means we can utilize to accomplish this and the purpose of life is to learn from everything.";;
	}
	for($z = 1 ; $z <=  8 ; $z++ ) {
		$hint[$z] = "Guess what you meaning of life is.";;
	}

	$description = "This is a question about life";
for ( $i = 1 ; $i <= 80 ; $i++ ) {
	$questionPositionNumber = $i;
	$cms->getQuestions()->insertQuestionDescription("test".$i, $questionPositionNumber);
	$that = $cms->getQuestions()->lastQuestionId();
		$noRan = rand(2, 3);
		$correctAnsw = 'answ1';
		for ( $c = 0 ; $c <= $noRan ; $c++ ) {
	$cms->getQuestions()->insertQuestion($question . $i . ' ' . $c, $pa[1] . $i . ' ' . $c, $pa[2] . $i . ' ' . $c, $pa[3] . $i . ' ' . $c,
	$pa[4] . $i . ' ' . $c, $pa[5] . $i . ' ' . $c, $pa[6] . $i . ' ' . $c, $pa[7] . $i . ' ' . $c, $pa[8] . $i . ' ' . $c,
	$answ[1] . $i . ' ' . $c, $answ[2], $answ[3], $answ[4], $answ[5], $answ[6], $answ[7], $answ[8], $correctAnsw, intval($that['id']),
	$hint[1] . $i . ' ' . $c, $hint[2] . $i . ' ' . $c, $hint[3] . $i . ' ' . $c, $hint[4] . $i . ' ' . $c, $hint[5] . $i . ' ' . $c,
	$hint[6] . $i . ' ' . $c, $hint[7] . $i . ' ' . $c, $hint[8] . $i . ' ' . $c);
	}
	echo '<br>filled question_id ' . $_SESSION['class'] . "!"; }




	//print_r($_SESSION['counts']['count1']);
