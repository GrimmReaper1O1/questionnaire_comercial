<?php
session_start();
?>
<DOCTYPE! html>
<html>
<body>

<?= $_SESSION['page'] ?? 'undefined' ?>
</body>
</html>
