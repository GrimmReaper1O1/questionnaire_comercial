<?php
require '../src/bootstrap.php';
$start = microtime(true);
if (isset($_SESSION['id'])) {
	if (isset($_GET['cId'])) {
		$_SESSION['site']['cId'] = $_GET['cId'];

	}

	if (isset($_GET['id'])) {

		$_SESSION['layoutOfSite'] = $cms->getMember()->selectStyle($_GET['id']);

	}

	if (isset($_GET['update'])) {
		$_SESSION['layoutOfSite']['id'] = $_GET['id'];
		$cms->getMember()->updateUserStyle();
		unset($_SESSION['layoutOfSite']['id']);

	}

	$start = microtime(true);


	$siteH = $_SESSION['layoutOfSite']['siteH'] ?? 'Questionnaire!';
	$length = strlen($siteH);

	if (!isset($_SESSION['hobbip'])) {
		$_SESSION['layoutOfSite']['hobbip'] = $_SESSION['layoutOfSite']['hobbip'] ?? 60;
		$_SESSION['layoutOfSite']['porsw'] = $_SESSION['layoutOfSite']['porsw'] ?? 7;
		$_SESSION['layoutOfSite']['polsw'] = $_SESSION['layoutOfSite']['polsw'] ?? 7;
		$_SESSION['layoutOfSite']['pombw'] = $_SESSION['layoutOfSite']['pombw'] ?? 86;
	}
	if ($_SESSION['layoutOfSite']['hobbip'] > 60) {

		if ($length < 20 && $length >= 10 ) {
			$height2 = ceil((floatval($_SESSION['layoutOfSite']['hobbip']) -4) / 2);
		} elseif ($length < 50 && $length >= 20 ) {
			$height2 = ceil((floatval($_SESSION['layoutOfSite']['hobbip']) -4) / 3);
		} elseif ($length < 60 && $length >= 50) {
			$height2 = ceil((floatval($_SESSION['layoutOfSite']['hobbip']) -4) / 3.5);

		} elseif ($length < 80 && $length >= 60) {
			$height2 = ceil((floatval($_SESSION['layoutOfSite']['hobbip']) -4) / 4.5);

		} elseif ($length < 100 && $length >= 80) {
			$height2 = ceil((floatval($_SESSION['layoutOfSite']['hobbip']) -4) / 5.5);

		} elseif ($length < 120 && $length >= 100) {
			$height2 = ceil((floatval($_SESSION['layoutOfSite']['hobbip']) -4) / 6.5);

		} else {
			$height2 = ceil((floatval($_SESSION['layoutOfSite']['hobbip']) -4) / 1.5);
		}
	} elseif ($_SESSION['layoutOfSite']['hobbip'] <= 60 && $length < 15 && ($_SESSION['layoutOfSite']['porsw'] + $_SESSION['layoutOfSite']['polsw']) >= 40) {
		$height2 = (intval($_SESSION['layoutOfSite']['hobbip']) -4);
	} elseif ($_SESSION['layoutOfSite']['hobbip'] <= 60 && $length >= 30  && ($_SESSION['layoutOfSite']['porsw'] + $_SESSION['layoutOfSite']['polsw']) >= 20) {
		$height2 = (intval($_SESSION['layoutOfSite']['hobbip']) -4) / 2;
	} elseif ($_SESSION['layoutOfSite']['hobbip'] <= 60 && $length >= 45  && ($_SESSION['layoutOfSite']['porsw'] + $_SESSION['layoutOfSite']['polsw']) >= 0) {
		$height2 = (intval($_SESSION['layoutOfSite']['hobbip']) -4) / 4;
	} else {
		$height2 = (intval($_SESSION['layoutOfSite']['hobbip']) -4);
	}
	if (!isset($_SESSION['layoutOfSite']['tWritting'])) {
		$titleWritting = 'white';
	} else {
		$titleWritting = $_SESSION['layoutOfSite']['tWritting'];
	}
	$_SESSION['layoutOfSite']['siteH2'] = '<span style="font-size: ' . $height2 . 'px; font-weith: bold; colour: ' . $titleWritting . ';">' . $siteH . '</span>';


	?>
	<!DOCTYPE html>
	<html>
	<title>questionnaire</title>

	<head>
		<script>
		let layout = <?php echo JSON_encode($_SESSION['layoutOfSite']); ?>;
		localStorage.setItem('layout', JSON.stringify(layout));

		</script>
		<meta http-equiv=”expires” content=”-1” />
		<meta http-equiv="Content-Type"
		content="text/html; charset=utf-8" />
		<meta http-equiv="Content-Type"
		content="application/javascript; charset=utf-8" />
		<link rel="stylesheet" type="text/css" href="CSS/styleSheet.css"   />

		<style>




		</style>
	</head>
	<body>





		<div id="mainTitleBar" class="mainTitleBar">
			<div id="leftInnerTitleBar" class="leftInnerTitleBar">
			</div>


			<div id="middleTitleBar" class="middleTitleBar"><?= $_SESSION['layoutOfSite']['siteH2'] ?? 'Questionniare!'  ?>
			</div>
			<div id="rightTitleBar" class="rightTitleBar">
			</div>



		</div>







		<div id="topBar">
			<div id="topRight">
				<div id="mainButtonDiv">
					<div id="signout">
						<a href="logout.php">Sign Out!</a>
					</div>				<div id="#innerButtonDiv">
						<button id="mainMenuButton"><img src="images/menu.png" width="38px" height="38px" id="mainMenuImage" ></button>
					</div>

				</div>
				<div id="mainMenuDiv">
					<span id="classes">Classes</span><br>
					<span id="results">Results</span><br>
					<span id="studentsLibrary">Library</span><br>
					<span id="mathematics">Mathematics</span><br>

					<span id="admin">Admin</span><br>
					<div id="adminMenuDiv">
						<span id="adminClasses">Administer Classes</span><br>
						<div id="adminClassesDiv">
							<span id="administerClasses">Administer Classes</span><br>
							<span id="adminLibrary">Admin Library</span><br>
							<span id="createClass">Create Class</span><br>
							<span id="deleteDocument">Delete Document</span><br>
							<span id="searchForStudents">Search For Students</span><br>
							<span id="uploadToLibrary">Upload To Library</span><br>
						</div>
						<span id="adminPage">Administer Page</span><br>
						<div id="adminPageDiv">
							<span id="alterStyle">Alter Style</span><br>
							<span id="createStyle">Create Style</span><br>
						</div>
						<span id="adminAdmins">Administer Admins</span><br>
						<div id="administerAdminsDiv">
							<span id="createAdminAccount">Create Admin Account</span><br>
							<span id="showAdministrators">Show Administrators</span><br>

						</div>

					</div>
					<span id="settings">Settings</span><br>
					<span id="contactUs">Contact Us</span><br>


				</div>

			</div>
		</div>
		<script src="../script/jquery-3.7.1.min.js"></script>
		<script src="../script/dropDownMenuPrototype2.js"></script>












		<?php

		if (isset($_SESSION['layoutOfSite']['disableMovingBars'])) {
			if ($_SESSION['layoutOfSite']['disableMovingBars'] == 1) {
				?>
				<div class="full-height">

					<?php
					if ($_SESSION['layoutOfSite']['dls'] == 0) { ?>
						<div id="leftLowerSidebar" class="leftLowerSidebar">

						</div>
					<?php }
					if ($_SESSION['layoutOfSite']['drs'] == 0) {
						?>

						<div id="rightLowerSidebar" class="rightLowerSidebar">

						</div>
						<?php
					}
				} else {
					?>
					<div class="full-height">
						<div id="leftLowerSidebar" class="leftLowerSidebar">

						</div>
						<?php
					}
				} else { ?>

					<div id="leftLowerSidebar" class="leftLowerSidebar">

					</div>
					<div id="rightLowerSidebar" class="rightLowerSidebar">

					</div><?php
				} ?>

				<?php

			} else {
				header('login.php');
				exit();
			}
