(function(){

let $body = $('body');
let $div = $('<div>');
let $images = $('.apendix');
let $imageDiv = $('#imageDiv');
let $imgInnerDiv = $('#placement');
let height = $(document).height();
let width = $(document).width();
let $left = $('#left');
let $right = $('#right');
let id;
$imageDiv.css({'height': '100%', 'width': '80%',});


let leftPos = ((width - 700) / 2)
$imageDiv.css({'left': '10%',})

$images.each(function(i){
  $(this).click(function(){
    let $image = $(this).clone()
    $image.css({'height': '100%' })
    $imgInnerDiv.html($image);
    $imageDiv.toggle();
    id = this.id;
console.log(id);
  });
});
$imgInnerDiv.click(function(e){
    $imgInnerDiv.first().html();
    $imageDiv.toggle();

  });
$left.click(function(e){
let image;
if (id >= 0) {

  let numeral = id * 1;
  id = (numeral - 1);

  image = $images.eq(numeral).clone();
  image.css({'height': '100%',});
  console.log(image);
  $imgInnerDiv.html(image);

} else {
  let end = (($images.length * 1) - 1);
  image = $images.eq(end);
  image.css({'height': '100%', });
  console.log(image);
  $imgInnerDiv.html(image);
  id = end - 1;
}
});
$right.click(function(e){
  let top = (($images.length * 1) - 1);
  if (id == top) {
    image = $images.eq(0).clone();
    image.css({'height': '100%',});
    console.log(image);
    $imgInnerDiv.html(image);
    id = 0;
  } else {
    let numeral = id * 1;
    id = (numeral + 1) * 1;
    console.log(id);
    image = $images.eq(id).clone();
    image.css({'height': '100%',});
    console.log(image);
    $imgInnerDiv.html(image);
  }

});


}());
