<?php
echo strtotime('now'); ?>
