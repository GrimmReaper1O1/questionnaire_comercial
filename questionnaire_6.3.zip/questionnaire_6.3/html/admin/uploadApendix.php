<?php
include '../includes/header4.php';
if ($_SESSION['administrator']['admin'] == 1) {



if ($_SERVER['REQUEST_METHOD'] === 'POST') {

$moved = false;


		try {
    $upload_path = '../uploads/';
    $max_size = 250137552;
    $allowed_types = ['video/webm'];
    $allowed_exts = ['webm'];

      $error2 = ($_FILES['file']['size'] <= $max_size) ? '' : 'Your file is too large. It must be under 2MB';
      $type = mime_content_type($_FILES['file']['tmp_name']);
      $error2 .= in_array($type, $allowed_types) ? '' : 'Your file is of the wrong type. It must be a pdf, doc, docx, odt, txt, or rtf.';
      $ext = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
       $error2 .= in_array($ext, $allowed_exts) ? '' : 'It must have the right file extension.';

       if ($error2 === '') {
        $filename = create_filename($_FILES['file']['name'], $upload_path);
        $destination = $upload_path . $filename;
        $moved = move_uploaded_file($_FILES['file']['tmp_name'], $destination);
		$destination = "../uploads/" . $filename;

       }

} catch (Error $e) {
    $error .= "You didn't select a file.";
}
       if ($moved === true) {


  try {

$floatNum = floatval($_POST['floatNum'])

	    $cms->getQuestions()->insertApendix($destination, $_POST['alt'], $_SESSION['id'], $floatNum);
		$message .= "Your document updated successfully! ";




  	} catch(Exception $e) {
        $error2 .= "We're sorry! There was a problem. Please try again.";
   }

   }

}
?>

<div class="heightHeader"></div>
<div id="main" class="main mainbody">
<br>
<br>
<br>
<form id='apendix'>
  <label>Description of apendix:</label><input type="text" name="alt" /><br>
  <label>Position floating point number:</label><input type="text" name="floatNum" /><br>
  <label>Apendix file choice:</label><input type="file" name="file" /><br>

<button for="apendix">Submit!</button>
</form>
</div>
</div>
<div class="addHeight">
</div>
</body>
</html>





<?php
} else {
  header('Location: ../classes.php');
}
