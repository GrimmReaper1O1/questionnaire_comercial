<?php
require '../../src/bootstrap.php';
if (isset($_SESSION['id'])) {
	if (isset($_GET['cId'])) {
		$_SESSION['site']['cId'] = $_GET['cId'];

	}
	$start = microtime(true);


	?>
	<!DOCTYPE html>
	<html>
	<title>questionnaire</title>

	<head>
		<meta http-equiv=”expires” content=”-1” />
		<meta http-equiv="Content-Type"
		content="text/html; charset=utf-8" />
		<meta http-equiv="Content-Type"
		content="application/javascript; charset=utf-8" />
		<link rel="stylesheet" type="text/css" href="../../CSS/styleSheet.css"   />

		<style>




		</style>
	</head>
	<body>





		<div id="mainTitleBar" class="mainTitleBar">
			<div id="leftInnerTitleBar" class="leftInnerTitleBar">
			</div>


			<div id="middleTitleBar" class="middleTitleBar"><?= $_SESSION['layoutOfSite']['siteH2'] ?? 'Questionniare!'  ?>
			</div>
			<div id="rightTitleBar" class="rightTitleBar">
			</div>



		</div>







		<div id="topBar">
			<div id="topRight">
				<div id="mainButtonDiv">
					<div id="signout">
						<a href="../logout.php">Sign Out!</a>
					</div>
					<div id="#innerButtonDiv">
						<button id="mainMenuButton"><img src="../images/menu.png" width="40px" height="40px" id="mainMenuImage" ></button>
					</div>
				</div>
				<div id="mainMenuDiv">
					<span id="classes">Classes</span><br>
					<span id="results">Results</span><br>
					<span id="studentsLibrary">Library</span><br>
					<span id="mathematics">Mathematics</span><br>

					<span id="admin">Admin</span><br>
					<div id="adminMenuDiv">
						<span id="adminClasses">Administer Classes</span><br>
						<div id="adminClassesDiv">
							<span id="administerClasses">Administer Classes</span><br>
							<span id="adminLibrary">Admin Library</span><br>
							<span id="createClass">Create Class</span><br>
							<span id="deleteDocument">Delete Document</span><br>
							<span id="searchForStudents">Search For Students</span><br>
							<span id="uploadToLibrary">Upload To Library</span><br>
						</div>
						<span id="adminPage">Administer Page</span><br>
						<div id="adminPageDiv">
							<span id="alterStyle">Alter Style</span><br>
							<span id="createStyle">Create Style</span><br>
						</div>
						<span id="adminAdmins">Administer Admins</span><br>
						<div id="administerAdminsDiv">
							<span id="createAdminAccount">Create Admin Account</span><br>
							<span id="showAdministrators">Show Administrators</span><br>

						</div>

					</div>
					<span id="settings">Settings</span><br>
					<span id="contactUs">Contact Us</span><br>


				</div>
			</div>
		</div>
		<script src="../script/jquery-3.7.1.min.js"></script>
		<script src="../script/dropDownMenuPrototype2.js"></script>











		<?php

		if (isset($_SESSION['layoutOfSite']['disableMovingBars'])) {
			if ($_SESSION['layoutOfSite']['disableMovingBars'] == 1) {
				?>
				<div class="full-height">
					<?php
					if ($_SESSION['layoutOfSite']['dls'] == 0) { ?>
						<div id="leftLowerSidebar" class="leftLowerSidebar">

						</div>
					<?php }
					if ($_SESSION['layoutOfSite']['drs'] == 0) {
						?>

						<div id="rightLowerSidebar" class="rightLowerSidebar">

						</div>
						<?php
					}
				} else {
					?>
					<div class="full-height">
						<div id="leftLowerSidebar" class="leftLowerSidebar">

						</div>
						<?php
					}
				} else { ?>

					<div id="leftLowerSidebar" class="leftLowerSidebar">

					</div>
					<div id="rightLowerSidebar" class="rightLowerSidebar">

					</div><?php
				} ?>

				<?php

			} else {
				header('login.php');
				exit();
			}
