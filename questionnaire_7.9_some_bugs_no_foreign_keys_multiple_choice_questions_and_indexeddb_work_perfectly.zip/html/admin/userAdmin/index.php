<?php
header("Location: ../../classes.php");
exit;