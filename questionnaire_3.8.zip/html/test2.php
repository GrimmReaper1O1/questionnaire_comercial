<?php
	include "../src/bootstrap.php";
	$start = microtime(true);
		$cms->getQuestions()->insertQuestionDescription("test", 1);
		$_SESSION['class'] = 8;
		
	$that = $cms->getQuestions()->lastQuestionIdInsert();
	
	
	$question = "What is the correct way to use a comma in the following sentence? here is some extra characters to make it longer and I ate some cheese earlier, just saying.";
	$_SESSION['subject'] = 1;
	
	$_SESSION['class'] = 2;
	

	
	for($z = 1 ; $z <=  8 ; $z++ ) {
	$pa[$z] = "Today, I ate some cheese, blue cheese and some cabana. I also ate a magnum ice cream and drank a coffee or two, then I slept as I was buggered. Yesterday, I almost finished off a page.";	
	}
	for($z = 1 ; $z <=  8 ; $z++ ) {
	$answ[$z] = "Today, I ate some cheese, blue cheese and some cabana. I also ate a magnum ice cream and drank a coffee or two, then I slept as I was buggered. Yesterday, I almost finished off a page.";	
	}
	for($z = 1 ; $z <=  8 ; $z++ ) {
		$hint[$z] = "Today, I ate some cheese, blue cheese and some cabana. I also ate a magnum ice cream and drank a coffee or two, then I slept as I was buggered. Yesterday, I almost finished off a page.";
	}
	
	$description = "This is a question about how to use commas";
for ( $i = 1 ; $i <= 30 ; $i++ ) { 
	unset($that);
	$questionPositionNumber = $i;
	$that = $cms->getQuestions()->lastQuestionIdInsert();
	$cms->getQuestions()->insertQuestionDescription("test", $questionPositionNumber);
		$nOQ = rand(2, 4);
		$correctAnsw = 'answ1';
		for ( $c = 0 ; $c <= $nOQ ; $c++ ) {
	$cms->getQuestions()->insertQuestion($question . $i . ' ' . $c, $pa[1] . $i . ' ' . $c, $pa[2] . $i . ' ' . $c, $pa[3] . $i . ' ' . $c, 
	$pa[4] . $i . ' ' . $c, $pa[5] . $i . ' ' . $c, $pa[6] . $i . ' ' . $c, $pa[7] . $i . ' ' . $c, $pa[8] . $i . ' ' . $c,
	$answ[1] . $i . ' ' . $c, $answ[2], $answ[3], $answ[4], $answ[5], $answ[6], $answ[7], $answ[8], $correctAnsw, $that['qid'],
	$hint[1] . $i . ' ' . $c, $hint[2] . $i . ' ' . $c, $hint[3] . $i . ' ' . $c, $hint[4] . $i . ' ' . $c, $hint[5] . $i . ' ' . $c, 
	$hint[6] . $i . ' ' . $c, $hint[7] . $i . ' ' . $c, $hint[8] . $i . ' ' . $c);
	} 
	echo '<br>filled question_id ' . $_SESSION['class'] . "!"; }
	
	
		
	
	//print_r($_SESSION['counts']['count1']);