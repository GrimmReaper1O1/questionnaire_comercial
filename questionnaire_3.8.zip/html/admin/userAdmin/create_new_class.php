<?php
include "../../includes/header5.php";
if ($_SESSION['administrator']['admin'] == 1) {
$descript = $_POST['classDescription'] ?? '';
$name = $_POST['className'] ?? '';
$verrified = $_POST['verrified'] ?? '';
$terms = $_POST['terms'] ?? '';
$error = "";

$row = false;

if ($_SERVER['REQUEST_METHOD'] === "POST") {
if ($descript === '') {
 $error .= "The description is empty. <br>";
}

if ($name === '') {
 $error .= "You must fill in both class number fields. <br>";
}

if ($verrified === '') {
$error .= "You must ensure the information entered is correct and the verrified checkbox is checked. <br>";
}



if ($descript != "" && $name != '' && $verrified != '') {
    $row = $cms->getMember()->getClassRowViaName($name);
}
print_r($row);
if ($descript != '' && strlen($descript) > 6 && $name != '' && strlen($name) > 1 && $verrified != '' &&
 $terms != '' && strlen($terms) > 6 && $row == false) {
 try {
    $result = $cms->getMember()->insertIntoClass($descript, $name, $_SESSION['id'],  $terms);
    $error .= "The action was completed successfully! ";
 }  catch(Exception $e) {
	try {
		$row = $cms->getMember()->selectClassRowViaName($name);
		$count1 = $cms->getMember()->deleteClassFromTable($row['class_id']);
		$count2 = $cms->getMember()->deleteClassFromClasses($row['class_id']);
		if ($count1 < 1 || $count2 < 1) {
         $error .= "There is likely a problem with the server or there is already another entry with that name. <br>";
		} } catch(Exception $e) {
		 
				$error .= "There is likely a problem with the server. <br>";
				$error .= "It may require you delete the class in the administrative pages.";
				$error .= "Please try again or try another name. <br> ";
		}
 }
} else {

    $error .= "The information wasn't entered in correctly or the class already exists. Are you missing a field or checkbox? ";

}

}


echo "<p>" . $error . "</p>";
?>

<form action="create_new_class.php" method="POST">
    <label for="className">Class name:</label><input type="text" name="className" value="<?= $name ?? "" ?>"><br>
    <label for="classDescription">Class description:</label><br>	
	<textarea rows='40' cols='80' name='classDescription'><?= $descript ?? "" ?></textarea><br>
    Contractual agreement:<br>
    <textarea rows='40' cols='80' name='terms'><?= $terms ?></textarea><br>
    <label for="verrified">I have verrified the information is correct:</label><br>
    <input type="checkbox" name="verrified">
    <input type="submit" value="SUBMIT!">
</form>

<?php 
include '../../includes/footer.php';
} else {
    header("Location: how_dare_you.php");
    exit();
}