<?php 
include '../includes/header4.php';
if ($_SESSION['administrator']['admin'] == 1) {
$id = $_GET['delete'] ?? 'no';

if ($id != 'no') {
	$result = $cms->getQuestions()->deleteAllEntriesFromAQuesitonInformation($_SESSION['subject'], $id);
	$result2 = $cms->getQuestions()->deleteExactQuestionIds($id);

	if ($result2 > 0) {
		echo "<h4>ALL QUESTION DESCRIPTIONS WERE DELETED!</h4><br>";
	} else {
		echo "<h4>THERE WAS A PROBLEM DELETING THE QUESTION DESCRIPTIONS.<br>PLEASE TRY AGAIN.</h4>";
	}

}
?>
<br><a href="adminSubjectsAndQuestionClassifications.php">CLICK HERE TO GO BACK TO THE ADMINISTRATIVE SUBJECTS PAGE!</a>
<?php 
} else {
    header("Location: how_dare_you.php");
    exit();
}