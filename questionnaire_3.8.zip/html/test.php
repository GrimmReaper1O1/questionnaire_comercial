<?php
for ($i = 0 ; $i < $sourcedQuestions ; $i++) { ?> 
	 a<?= $i ?>: {
		<?php if ($countedNumberOfQuestionsPerQuestion['a'.$i] > $i) { 
				for ($b = 0 ; $b < 10 ; $b++ ) { ?>
						<?php if ($runs >= $b) { ?>	<?= $b ?>: {},
<?php }}} echo "}"; } echo "}";?> }   
	


