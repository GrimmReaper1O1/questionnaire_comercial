<?php
namespace MySite\CMS;                                   // Declare namespace

class Questions
{
protected $db;
public function __construct(Database $db)
{
    $this->db = $db;
}
	public function selectAllClasses($page, $limit) {
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$limit = strval($limit);
		
			
		$sql = "select count(*) as count from (select * from classes";
		$sql .= ") t";
		$results[0] = $this->db->runSql($sql)->fetch();
		$offset = ($page - 1) * $limit;
		
		
		
		$limit = preg_replace($patterns, $replacements, $limit);
		$sql = "select c.class_name, c.description_of_class, c.user_id, c.class_id, ";
		$sql .= "concat(u.first_name, ', ', u.last_name) as author from Classes c left outer join ";
		$sql .= "users u on c.user_id = u.user_id order by c.class_name offset " . $offset;
		$sql .= " rows fetch next " . $limit . " rows only";
		$results[1] = $this->db->runSql($sql)->fetchAll();
		return $results;
	}
	
	public function selectAllClassesViaOwner($page, $limit, $administrator) {
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$limit = strval($limit);
		$arguments['owner'] = $administrator;
		
		
		$sql = "select count(*) as count from (select * from classes where user_id like :owner";
		$sql .= ") t";
		$results[0] = $this->db->runSql($sql, $arguments)->fetch();
		$offset = ($page - 1) * $limit;
		
		
		
		$limit = preg_replace($patterns, $replacements, $limit);
		$sql = "select * from (select c.class_name, c.description_of_class, c.user_id, c.class_id, ";
		$sql .= "concat(u.first_name, ', ', u.last_name) as author from classes c inner join ";
		$sql .= "users u on c.user_id = u.user_id where c.user_id like :owner) t order by class_name offset " . $offset;
		$sql .= " rows fetch next " . $limit . " rows only";
		$results[1] = $this->db->runSql($sql, $arguments)->fetchAll();
		return $results;
	}
		public function selectAllClassesViaLetter($page, $limit, $letter) {
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$limit = strval($limit);
		$letter = preg_replace($patterns, $replacements, $letter);
			
		$sql = "select count(*) as count from (select * from classes where left(class_name, 1) like '" . $letter . "' ";
		$sql .=  ") t";
		$results[0] = $this->db->runSql($sql)->fetch();
		$offset = ($page - 1) * $limit;
		
		
		
		$limit = preg_replace($patterns, $replacements, $limit);
		$sql = "select c.class_name, c.description_of_class, c.user_id, c.class_id, ";
		$sql .= "concat(u.first_name, ', ', u.last_name) as author from Classes c left outer join ";
		$sql .= "users u on c.user_id = u.user_id where left(c.class_name, 1) like '" . $letter . "' ";
		$sql .= "order by c.class_name offset " . $offset;
		$sql .= " rows fetch next " . $limit . " rows only";
		$results[1] = $this->db->runSql($sql)->fetchAll();
		return $results;
	}
	public function selectAllClassesViaLetterAndOwner($page, $limit, $letter, $administrator) {
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$limit = strval($limit);
		$letter = preg_replace($patterns, $replacements, $letter);	
		$arguments['owner'] = $administrator;
	
		
		$sql = "select count(*) as count from (select * from classes where left(class_name, 1) like '" . $letter . "' ";
		$sql .=  "and user_id like :owner) t";
		$results[0] = $this->db->runSql($sql, $arguments)->fetch();
		$offset = ($page - 1) * $limit;
		
		
		
		$limit = preg_replace($patterns, $replacements, $limit);
		$sql = "select c.class_name, c.description_of_class, c.user_id, c.class_id, ";
		$sql .= "concat(u.first_name, ', ', u.last_name) as author from Classes c left outer join ";
		$sql .= "users u on c.user_id = u.user_id where left(c.class_name, 1) like '" . $letter . "' ";
		$sql .= "and c.user_id like :owner order by c.class_name offset " . $offset;
		$sql .= " rows fetch next " . $limit . " rows only";
		$results[1] = $this->db->runSql($sql, $arguments)->fetchAll();
		return $results;
	}
	public function deleteQuestion($id) {
		$arguments['id'] = $id;
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		
		$subjectId = preg_replace($patterns, $replacements, $_SESSION['subject']);
		$sql = "delete from question_information" . $subjectId . " where id like :id";
		return $this->db->runSql($sql, $arguments)->rowCount();			
	}
	
	public function updateClassDescription($classId, $description) {
		$arguments['classId'] = $classId;
		$arguments['description'] = $description;
		$sql = "update classes set description_of_class = :description where class_id like :classId";
		return $this->db->runSql($sql, $arguments)->rowCount();
		
	}
	
	
	
	public function deleteFromSubjectsTableViaClassId($classId) {

		$arguments['classId'] = $classId;
		$sql = "delete from tables where class_id like :classId";
		return $this->db->runSql($sql, $arguments)->rowCount();
	
	}
	public function deleteFromQuestionDescriptionViaClassId($classId) {
		$arguments['classId'] = $classId;
		
		$sql = "delete from question_ids where class_id like :classId";
		$result = $this->db->runSql($sql, $arguments)->rowCount();
	}
	public function deleteFromQuestionInformationViaClassIdAndSubject($subject, $classId) {
			$arguments['classId'] = $classId;
			$patterns[0] = '/;/';
			$patterns[1] = '/go/';
			$replacements[0] = '';
			$replacements[1] = '';
			$subject = preg_replace($patterns, $replacements, $subject);
		
			$sql = "delete from question_information" . $subject . " where class_id like :classId";
			return $this->db->runSql($sql, $arguments)->rowCount();
		}
	public function deleteFromUsersOfClassesViaClassId($classId) {
			$arguments['classId'] = $classId;
			$sql = "delete from attached_users_to_classes where class_id like :classId";
			return $this->db->runSql($sql, $arguments)->rowCount();
	}
	public function selectAllFromLibraryViaClassId($classId) {
			$arguments['classId'] = $classId;
			$sql = "select * from library where class_id like :classId";
			return $this->db->runSql($sql, $arguments)->fetchAll();
			
		}
		public function deleteFromLibraryViaClassId($classId) {
			$arguments['classId'] = $classId;
			$sql = "delete from library where class_id like :classId";
			return $this->db->runSql($sql, $arguments)->rowCount();
			
		}
	public function deleteFromTermsViaClassId($classId) {
		$arguments['classId'] = $classId;
		$sql = "delete from terms where class_id like :classId";
		return $this->db->runSql($sql, $arguments)->rowCount();
	}
	public function deleteFromClassesViaClassId($classId) {
		$arguments['classId'] = $classId;		
		$sql = "delete from classes where class_id like :classId";
		return $this->db->runSql($sql, $arguments)->rowCount();
	
	}
	public function updateSubjectName($id, $name) {
		$arguments['id'] = $id;
		$arguments['name'] = $name;
		$sql = "update tables set subject_information = :name where id like :id";
		return $this->db->runSql($sql, $arguments)->rowCount();
	}
	public function updateSubjectsNumberOfQuestions($id, $number) {
		$arguments['id'] = $id;
		$arguments['number'] = $number;
		$sql = "update tables set number_of_questions = :number where id like :id";
		return $this->db->runSql($sql, $arguments)->rowCount();
	}
	public function selectAllFromSubjectsAdmin($classId) {
		$arguments['classId'] = $classId;
		$sql = "select * from (select t.id, t.table_id, t.subject_information, t.number_of_questions, t.class_id, c.class_name, c.description_of_class ";
		$sql .= " from tables t inner join classes c on t.class_id = c.class_id where t.class_id like :classId ) t ";
		$sql .= "";
		return $this->db->runSql($sql, $arguments)->fetchAll();
	}
	public function selectAllFromSubjects($classId) {
		$arguments['classId'] = $classId;
		$sql = "select * from (select t.id, t.table_id, t.subject_information, t.number_of_questions, t.class_id, c.class_name, c.description_of_class ";
		$sql .= " from tables t inner join classes c on t.class_id = c.class_id where t.class_id like :classId ) t ";
		$sql .= "order by subject_information";
		return $this->db->runSql($sql, $arguments)->fetchAll();
	}
	public function selectSubjectViaTableId($tableId) {
		$arguments['tableId'] = $tableId;
		$sql = "select * from tables where table_id like :tableId";
		return $this->db->runSql($sql, $arguments)->fetch();
	}
	
	public function selectSubjectViaTableIdAndClassId() {
		$arguments['tableId'] = $_SESSION['subject'];
		$arguments['class'] = $_SESSION['class'];
		$sql = "select * from tables where table_id like :tableId and class_id like :class";
		return $this->db->runSql($sql, $arguments)->fetch();
	}
	public function selectSubjectViaSubjectName($name) {
		$arguments['name'] = $name;
		$sql = "select * from tables where subject_information like :name";
		return $this->db->runSql($sql, $arguments)->fetch();	
	}
	public function updateSubjects($subject, $id) {
		$arguments['entry'] = $subject;
		$arguments['id'] = $_SESSION['subject'];
		$arguments['class'] = $_SESSION['class'];
		$sql = "update tables set subject_information = :entry where table_id like :id and class_id like :class";
		return $this->db->runSql($sql, $arguments)->rowCount();
	}
	public function updateSubjectsInitial($subject, $numberOfQuestions) {
		$arguments['entry'] = $subject;
		$arguments['id'] = $_SESSION['subject'];
		$arguments['number'] = $numberOfQuestions;
		$arguments['class'] = $_SESSION['class'];
		$sql = "update tables set subject_information = :entry, number_of_questions = :number ";
		$sql .= "where table_id like :id and class_id like :class";
		return $this->db->runSql($sql, $arguments)->rowCount();
	}
	public function selectQuestionViaDescription($description) {
		$arguments['description'] = $description;
		$arguments['id'] = $_SESSION['subject'];
		$sql = "select * from question_ids where table_id like :id and description like :description";
		return $this->db->runSql($sql, $arguments)->fetch();
	}
	public function insertQuestionDescription($description, $questionPositionNumber){
		$arguments['id'] = $_SESSION['subject'];
		$arguments['description'] = $description;
		$arguments['position'] = $questionPositionNumber;
		$arguments['class'] = $_SESSION['class'];
		$sql = "insert into question_ids (table_id, description, question_number, class_id) ";
		$sql .= "values (:id, :description, :position, :class)";
		return $this->db->runSql($sql, $arguments);
	}
	public function selectQuestions($id, $page, $limit) {
		$arguments['id'] = $id;
		$arguments['class'] = $_SESSION['class'];
		$sql = "select count(*) as count from (select question_id, table_id, description from question_ids ";
		$sql .= "where table_id like :id and class_id like :class) t";
		$results[0] = $this->db->runSql($sql, $arguments)->fetch();
		$offset = ($page - 1) * $limit;
		$limit = strval($limit);
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$limit = preg_replace($patterns, $replacements, $limit);
		$sql = "select * from (select question_number, question_id, description from question_ids ";
		$sql .= "where table_id like :id and class_id like :class) c  order by question_number ";
		$sql .= "offset " . $offset . " rows fetch next " . $limit . " rows only";
		$results[1] = $this->db->runSql($sql, $arguments)->fetchAll();
		return $results;
	}
	
	public function insertQuestion($tableNumber, $question, $pa1, $pa2, $pa3, $pa4, $pa5, $pa6, $pa7, $pa8,
	$answ1, $answ2, $answ3, $answ4, $answ5, $answ6, $answ7, $answ8, $correctAnsw, $questionId,
	$hint1, $hint2, $hint3, $hint4, $hint5, $hint6, $hint7, $hint8) {
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$tableNumber = preg_replace($patterns, $replacements, $tableNumber);
		$arguments['question'] = $question;
		$arguments['pa1'] = $pa1;
		$arguments['pa2'] = $pa2;
		$arguments['pa3'] = $pa3;
		$arguments['pa4'] = $pa4;
		$arguments['pa5'] = $pa5;
		$arguments['pa6'] = $pa6;
		$arguments['pa7'] = $pa7;
		$arguments['pa8'] = $pa8;
		$arguments['answ1'] = $answ1;
		$arguments['answ2'] = $answ2;
		$arguments['answ3'] = $answ3;
		$arguments['answ4'] = $answ4;
		$arguments['answ5'] = $answ5;
		$arguments['answ6'] = $answ6;
		$arguments['answ7'] = $answ7;
		$arguments['answ8'] = $answ8;
		$arguments['correct'] = $correctAnsw;
		$arguments['questionId'] = $questionId;
		$arguments['hint1'] = $hint1;
		$arguments['hint2'] = $hint2;
		$arguments['hint3'] = $hint3;
		$arguments['hint4'] = $hint4;
		$arguments['hint5'] = $hint5;
		$arguments['hint6'] = $hint6;
		$arguments['hint7'] = $hint7;
		$arguments['hint8'] = $hint8;
		$arguments['class'] = $_SESSION['class'];
		$sql = "insert into question_information" . $tableNumber . " (class_id, question, pa1, pa2, pa3, pa4, pa5, pa6, pa7, pa8, ";
		$sql .= "answ1, answ2, answ3, answ4, answ5, answ6, answ7, answ8, correct, question_id, hint1, hint2, hint3, ";
		$sql .= " hint4, hint5, hint6, hint7, hint8) values ";
		$sql .= "(:class, :question, :pa1, :pa2, :pa3, :pa4, :pa5, :pa6, :pa7, :pa8, :answ1, :answ2, :answ3, :answ4, :answ5, ";
		$sql .= ":answ6, :answ7, :answ8, :correct, :questionId, :hint1, :hint2, :hint3, :hint4, :hint5, :hint6, :hint7, :hint8)";
		return $this->db->runSql($sql, $arguments);
	}
	public function updateQuestion($id, $tableNumber, $question, $pa1, $pa2, $pa3, $pa4, $pa5, $pa6, $pa7, $pa8,
	$answ1, $answ2, $answ3, $answ4, $answ5, $answ6, $answ7, $answ8, $correctAnsw, $questionId,
	$hint1, $hint2, $hint3, $hint4, $hint5, $hint6, $hint7, $hint8) {
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$tableNumber = preg_replace($patterns, $replacements, $tableNumber);
		$arguments['question'] = $question;
		$arguments['id'] = $id;
		$arguments['pa1'] = $pa1;
		$arguments['pa2'] = $pa2;
		$arguments['pa3'] = $pa3;
		$arguments['pa4'] = $pa4;
		$arguments['pa5'] = $pa5;
		$arguments['pa6'] = $pa6;
		$arguments['pa7'] = $pa7;
		$arguments['pa8'] = $pa8;
		$arguments['answ1'] = $answ1;
		$arguments['answ2'] = $answ2;
		$arguments['answ3'] = $answ3;
		$arguments['answ4'] = $answ4;
		$arguments['answ5'] = $answ5;
		$arguments['answ6'] = $answ6;
		$arguments['answ7'] = $answ7;
		$arguments['answ8'] = $answ8;
		$arguments['correct'] = $correctAnsw;
		$arguments['questionId'] = $questionId;
		$arguments['hint1'] = $hint1;
		$arguments['hint2'] = $hint2;
		$arguments['hint3'] = $hint3;
		$arguments['hint4'] = $hint4;
		$arguments['hint5'] = $hint5;
		$arguments['hint6'] = $hint6;
		$arguments['hint7'] = $hint7;
		$arguments['hint8'] = $hint8;
		$sql = "update question_information" . $tableNumber . " set question = :question, pa1 = :pa1, pa2 = :pa2, pa3 = :pa3, ";
		$sql .= "pa4 = :pa4, pa5 = :pa5, pa6 = :pa6, pa7 = :pa7, pa8 = :pa8, answ1 = :answ1, answ2 = :answ2, answ3 = :answ3, ";
		$sql .= "answ4 = :answ4, answ5 = :answ5, answ6 = :answ6, answ7 = :answ7, answ8 = :answ8, correct = :correct, ";
		$sql .= "question_id = :questionId, hint1 = :hint1, hint2 = :hint2, hint3 = :hint3, hint4 = :hint4, hint5 = :hint5, ";
		$sql .= "hint6 = :hint6, hint7 = :hint7, hint8 = :hint8 where id like :id";
		return $this->db->runSql($sql, $arguments)->rowCount();
	}
	public function selectQuestion($questionNumber) {
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$_SESSION['subject'] = preg_replace($patterns, $replacements, $_SESSION['subject']);
		$arguments['questionId'] = $questionNumber;
		$sql = "select count(*) as count from question_information" . $_SESSION['subject'];
		$sql .= " where question_id like :questionId";
		$count = $this->db->runSql($sql, $arguments)->fetch();
		if ($count['count'] != 0) {
		$offset = rand(0, $count['count'] - 1);
		} else {
			$offset = 0;
		}

		$sql = "select * from question_information" . $_SESSION['subject'];
		$sql .= " where question_id like :questionId order by id offset $offset rows fetch next 1 rows only";
		return $this->db->runSql($sql, $arguments)->fetch();
	}
	public function selectAllQuestionsFromSubjectPagination($page, $limit) {
		$arguments['classId'] = $_SESSION['class'];
		$arguments['tableId'] = $_SESSION['subject'];
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$limit = intval($limit);
		$limit = preg_replace($patterns, $replacements, $limit);
		$sql = "select count(*) as count from question_ids where class_Id like :classId ";
		$sql .= "and table_id like :tableId";
		$result[0] = $this->db->runSql($sql, $arguments)->fetch();
		
		$offset = ($page - 1) * $limit;
		
		$sql = "select * from question_ids where class_id like :classId and ";
		$sql .= "table_id like :tableId order by question_number offset ";
		$sql .= $offset . " rows fetch next " . $limit . " rows only";
		$result[1] = $this->db->runSql($sql, $arguments)->fetchAll();
		return $result;
		
	}
		
		
		
		
	public function selectQuestionViaQuestion($question, $questionId) {
		$arguments['question'] = $question;
		$arguments['questionId'] = $questionId;
		$arguments['class'] = $_SESSION['class'];
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$subjectId = $_SESSION['subject'];
		$subjectId = preg_replace($patterns, $replacements, $subjectId);
		$sql = "select * from question_information" . $subjectId . " where question ";
		$sql .= "like :question and question_id like :questionId and class_id like :class";
		return $this->db->runSql($sql, $arguments)->fetch();
}
		public function selectQuestioninformation($questionId, $page, $limit, $subjectId) {
		$arguments['questionId'] = $questionId;
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$limit = strval($limit);
		$limit = preg_replace($patterns, $replacements, $limit);
		
		$sql = "select count(*) as count from (select * from question_information" . $subjectId;
		$sql .= " where question_id like :questionId) t";
		$results[0] = $this->db->runSql($sql, $arguments)->fetch();
		$offset = ($page - 1) * $limit;
		
		
		$limit = preg_replace($patterns, $replacements, $limit);
		$sql = "select * from (select s.id, s.question, s.question_id, s.correct, q.question_number, s.pa1, s.pa2, s.pa3, s.pa4, s.pa5, s.pa6, s.pa7, s.pa8, ";
		$sql .= "s.answ1, s.answ2, s.answ3, s.answ4, s.answ5, s.answ6, s.answ7, s.answ8, ";
		$sql .= "s.hint1, s.hint2, s.hint3, s.hint4, s.hint5, s.hint6, s.hint7, s.hint8, q.description from question_information" . $subjectId;
		$sql .= " s left outer join question_ids q on s.question_id = q.question_id ";
		$sql .= "where q.question_id like :questionId) t order by question_number ";
		$sql .= "offset " . $offset . " rows fetch next " . $limit . " rows only";
		$results[1] = $this->db->runSql($sql, $arguments)->fetchAll();
		return $results;
	}
	public function updateSubjectsTable($id) {
		$arguments['id'] = $id;
		$sql = "update tables set subject_information = 'empty', number_of_questions = null where table_id like :id";
		return $this->db->runSql($sql, $arguments)->rowCount();
	}
	public function deleteQuestionIds($id) {
		$arguments['id'] = $id;
		$sql = "delete from question_ids where table_id like :id";
		return $this->db->runSql($sql, $arguments)->rowCount();
	}
	public function selectToCheckQuestionNumberViaSubjectClassAndPossition($possition, $description) {
		$arguments['possition'] = $possition;
		$arguments['subject'] = $_SESSION['subject'];
		$arguments['class'] = $_SESSION['class'];
		$arguments['description'] = $description;
		$sql = "select * from question_ids where class_id like :class and table_id like :subject and ";
		$sql .= "question_number like :possition and description like :description";
		return $this->db->runSql($sql, $arguments)->rowCount();
	}
	public function deleteAllEntriesFromQuesitonInformation($subjectId) {
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$subjectId = preg_replace($patterns, $replacements, $subjectId);
		$sql = "delete from question_information" . $subjectId;
		return $this->db->runSql($sql)->rowCount();
}
	public function selectQuestionViaQuestionId($id) {
		$arguments['id'] = $id;
		$arguments['class'] = $_SESSION['class'];
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		
		$subjectId = preg_replace($patterns, $replacements, $_SESSION['subject']);
		$sql = "select * from question_information" . $subjectId . " where id like :id and class_id like :class";
		return $this->db->runSql($sql, $arguments)->fetch();
	}
	public function selectQuestionDescriptionViaQuestionId($id) {
		$arguments['questionId'] = $id;
		$arguments['class'] = $_SESSION['class'];
		
	
		$sql = "select question_number, class_id, description, table_id, question_id from question_ids";
		$sql .= " where question_id like :questionId and class_id like :class";
		return $this->db->runSql($sql, $arguments)->fetch();
	}
	public function updateQuestionDescriptionPossition($questionId, $possition) {
		$arguments['questionId'] = $questionId;
		$arguments['possition'] = $possition;
		$sql = "update question_ids set question_number = :possition where question_id like :questionId";
		return $this->db->runSql($sql, $arguments)->rowCount();
	}
}