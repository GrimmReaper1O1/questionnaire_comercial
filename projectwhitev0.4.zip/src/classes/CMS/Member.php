<?php
namespace MySite\CMS;                                   // Declare namespace

class Member {
protected $db;
public function __construct(Database $db)
{
    $this->db = $db;
}
    public function insertForm($user_pass, $user_email, $timestamp, $firstName, $middleName, $lastName, $phoneNumber) 
{
    $arguments = [];
    $arguments['user_pass'] =  $user_pass;
    $arguments['user_email'] =  $user_email;
    $arguments['timestamp'] = $timestamp;
    $arguments['firstName'] =  $firstName;
    $arguments['middleName'] =  $middleName;
    $arguments['lastName'] = $lastName;
    $arguments['phoneNumber'] = $phoneNumber;
  


    $sql = "INSERT INTO  users (pass, email, timestamp,  first_name, middle_names, last_name, phone_number) VALUES ( "; 
    $sql .= ":user_pass, :user_email, :timestamp, :firstName, :middleName, :lastName, :phoneNumber)";
    return $this->db->runSql($sql, $arguments);

}
public function enterTerms($terms, $class, $mainSite) {
	$arguments['terms'] = $terms;
	$arguments['class'] = $class;
	$arguments['mainSite'] = $mainSite;
	$sql = "insert into terms (terms, class_id, main_site) values (:terms, :class, :mainSite)";
	return $this->db->runSql($sql, $arguments);
}
public function updateAcceptTerms($id) {
	$arguments['id'] = $id;
	$sql = "update users set accepted_terms = 1 where user_id like :id";
	return $this->db->runSql($sql, $arguments)->rowCount();
}
   public function getTermsMain()
    {
    $sql = "SELECT * from terms WHERE  main_site LIKE 1";
    return $this->db->runsql($sql)->fetch();
}
public function getTerms($id)
    {
        $arguments['id'] = $id;
    $sql = "SELECT * from terms WHERE  class_id LIKE :id";
    return $this->db->runsql($sql, $arguments)->fetch();
}
    public function insertIntoClass($classDescription, $name, $administratorId, $terms) {
        $arguments['name'] = $name;
        $arguments['id'] = $administratorId;
        $arguments['descriptionOfClass'] = $classDescription;
        $arguments['terms'] = $terms;
        $sql = "INSERT INTO  classes (description_of_class, class_name, user_id, terms) ";
        $sql .= " VALUES (:descriptionOfClass, :name, :id, :terms)";
		$this->db->runsql($sql, $arguments);
		$args1['name'] = $name;
		$sql = "select * from classes where class_name like :name";
		$row = $this->db->runSql($sql, $args1)->fetch();
		$args2['classId'] = $row['class_id'];
		for($i = 1; $i < 31; $i++) {
			$sql = "insert into  tables (table_id, subject_information, class_id) values ($i, 'empty', :classId)";
			$this->db->runSql($sql, $args2);
		}
		return $args2['classId'];
	}
	public function deleteClassFromTable($classId) {
		$arguments['classId'] = $classId;
		$sql = "delete from tables where class_id like :classId";
		return $this->db->runSql($sql, $arguments)->rowCount();
	}
	public function deleteClassFromClasses($classId) {
		$arguments['classId'] = $classId;
		$sql = "delete from classes where class_id like :classId";
		return $this->db->runSql($sql, $arguments)->rowCount();
	}
		public function selectClassRowViaName($className) {
			$arguments['name'] = $className;
			$sql = "select * from classes where class_name like :name";
			return $this->db->runSql($sql, $arguments)->fetch();
		}
		public function getClassRow($caseNum)
    {
        $arguments['caseNum'] = $caseNum;
        $sql = "SELECT * from classes WHERE  class_id LIKE :caseNum";
        return $this->db->runsql($sql, $arguments)->fetch();
    }
	public function selectAdministratorViaUserId($userId) {
		$arguments['userId'] = $userId;
		$sql = "select * from administrator WHERE  user_id LIKE :userId";
		return $this->db->runsql($sql, $arguments)->fetch();
	}
 public function selectAdminViaUserId($userId) {
    $arguments['userId'] = $userId;
    $sql = "select * from administrator WHERE  user_id LIKE :userId";
    $row = $this->db->runsql($sql, $arguments)->fetch();
    
    $result = [ 'root' => 0,
                'can_add_and_delete' => 0,
                'can_delete_all' => 0,
                'can_remove_class' => 0,
                'admin' => 0,
            ];
    if ($row != false){
	$result['administrator_id'] = $row['administrator_id'];
    $result['admin'] = 1;
    if ($row['all_access_administrator'] == 1) {
        $result['root'] = 1;
     
    }
    if ($row['can_add_and_delete_questions_and_assign_names'] == 1) {
        $result['can_add_and_delete'] = 1;
    
    } 
    if ($row['can_delete_all_from_subject'] == 1 ) {
        $result['can_delete_all'] = 1;
    
    }
    if ($row['can_remove_class'] == 1 ) {
        $result['can_remove_class'] = 1;
     
        }
    }    
    if ($row = false) {
        
        $result = false;
    } 

    return $result;

    }
	 public function getViaId($id) {
        $arguments['id'] = $id;
        $sql = "SELECT * from users WHERE  user_id LIKE :id";
        return $this->db->runSql($sql, $arguments)->fetch();
    }   
	 public function updateUsers($timestamp) {
        $arguments['timestamp'] = $timestamp;
        $sql = "UPDATE users SET timestamp = :timestamp";
        return $this->db->runsql($sql, $arguments)->rowCount();
    }











public function selectAdminViaEmail($email) {
    $arguments['email'] = $email;
    $sql = "select *, a.root from administrator a left outer join users u on a.user_id = u.user_id ";
    $sql .= "where u.email like :email";
    return $this->db->runsql($sql, $arguments)->fetch();
}


public function getRowViaFullName($fullName) 
{
    $arguments['fullName'] = $first_name;

    $sql = "SELECT id, email from users WHERE  full_name LIKE :fullName ";
    return $this->db->runSql($sql, $arguments)->fetch();
}
public function selectViaEmail($email) 
{
    $arguments['email'] = $email;
    $sql = "SELECT *, concat(first_name, ', ', last_name) as concat_full_name from users WHERE  email LIKE :email";
    return $this->db->runSql($sql, $arguments)->fetch();
}
public function getRowViaEmail($email) 
{
    $arguments['email'] = $email;
    $sql = "SELECT * from users WHERE  email LIKE :email";
    return $this->db->runSql($sql, $arguments)->fetch();
}
public function selectViaEmailOL($email, $offset, $limit) 
{
    $arguments['email'] = $email;
    $sql = "SELECTid, full_name from users WHERE  email LIKE :email LIMIT $limit OFFSET $offset";
    return $this->db->runSql($sql, $arguments)->fetch();
}
public function selectRowAdminViaEmail($email) {
    $arguments['ema'] = $email;
    $sql = "SELECT * from administrator WHERE  email LIKE :ema";
    return $this->db->runSql($sql, $arguments)->fetch();
}   
public function getViaEmail($email) {
    $arguments['ema'] = $email;
    $sql = "SELECT * from users WHERE  email LIKE :ema";
    return $this->db->runSql($sql, $arguments)->fetch();
}   
   
    public function getMemberViaId($id) {
        $arguments['id'] = $id;
        $sql = "SELECT * from users u LEFT OUTER JOIN  cases_users c ON u.user_id = c.user_id WHERE u.user_id LIKE :id";
        return $this->db->runSql($sql, $arguments)->fetch();
    }
    public function insertIp($ip, $id, $timestamp) 
    {   $arguments['id'] = $id;
        $arguments['timestamp'] = $timestamp;
        $arguments['ip'] = $ip;
        $sql = "INSERT INTO  ip (ip, user_id, timestamp) VALUES (:ip, :id, :timestamp)";
        return $this->db->runSql($sql, $arguments);
    }
 

public function setPublicViewing($yes)
    {
        $arguments["option"] = $yes;
        $sql = "INSERT INTO  settings (show_all_evidence) VALUES (:option) ";
        return $this->db->runsql($sql, $arguments);
    }

    public function getAllIpInformationViaEmail($email) {
        $arguments['ema'] = $email;
        $sql = "SELECT * from ip i left outer join users u on i.user_id = u.user_id ";
        $sql .= "WHERE u.email LIKE :ema ORDER BY timestamp desc";
        return $this->db->runsql($sql, $arguments)->fetchAll();
    }

    public function createAdmin($user_id, $creatorId, $timestamp) {

$arguments['user_id'] = $user_id;
$arguments['creator'] = $creatorId;
$arguments['timestamp'] = $timestamp;
$sql = "INSERT INTO  administrator (user_id, creator, timestamp, all_access_administrator, can_add_and_delete_questions_and_assign_names, ";
$sql .= "can_delete_all_from_subject, can_remove_class) ";
$sql .= "VALUES (:user_id, :creator, :timestamp, 0, 0, 0, 0)";
return $this->db->runsql($sql, $arguments);
    }
    public function updateSetRootPrivilagesViaUserId($userId) {
        $arguments['userId'] = $userId;
        $sql = "UPDATE administrator SET root = 1, can_delete = 0, can_alter = 0, can_delete_all = 0 WHERE  user_id LIKE :userId";
        return $this->db->runsql($sql, $arguments)->rowCount();
    }
    public function updateAllowAlterEvidenceViaUserId($userId) {
        $arguments['userId'] = $userId;
        $sql = "UPDATE administrator SET can_alter = 1 WHERE  user_id LIKE :userId";
      return  $this->db->runsql($sql, $arguments)->rowCount();
}
public function updateAllowDeleteAllEvidenceViaUserId($userId) 
{
    $arguments['userId'] = $userId;
    $sql = "UPDATE administrator SET can_delete_all = 1 WHERE  user_id LIKE :userId";
    return $this->db->runsql($sql, $arguments)->rowCount();
}
public function updateAllowDeleteEvidenceViaUserId($userId) 
    {
        $arguments['userId'] = $userId;
        $sql = "UPDATE administrator SET can_delete = 1 WHERE  user_id LIKE :userId";
        return $this->db->runsql($sql, $arguments)->rowCount();
    }
    public function updateDenySetRootPrivilagesViaUserId($userId) {
        $arguments['userId'] = $userId;
        $sql = "UPDATE administrator SET root = 0 WHERE  user_id LIKE :userId";
        return $this->db->runsql($sql, $arguments)->rowCount();
    }
    public function updateDenyAlterEvidenceViaUserId($userId) {
        $arguments['userId'] = $userId;
    $sql = "UPDATE administrator SET can_alter = 0 WHERE  user_id LIKE :userId";
    return  $this->db->runsql($sql, $arguments)->rowCount();
}
public function updateDenyDeleteAllEvidenceViaUserId($userId) 
{
    $arguments['userId'] = $userId;
    $sql = "UPDATE administrator SET can_delete_all = 0 WHERE  user_id LIKE :userId";
    return $this->db->runsql($sql, $arguments)->rowCount();
}
public function updateDenyDeleteEvidenceViaUserId($userId) 
    {
        $arguments['userId'] = $userId;
        $sql = "UPDATE administrator SET can_delete = 0 WHERE  user_id LIKE :userId";
        return $this->db->runsql($sql, $arguments)->rowCount();
    }
    public function deleteAdminAccount($alterAccount) {
        $arguments['account'] = $alterAccount;
        $sql = "DELETE from administrator WHERE  email LIKE :account";
        return $this->db->runsql($sql, $arguments)->rowCount();
    }
   

    public function deleteAccount($alterAccount) {
        $arguments['account'] = $alterAccount;
        $sql = "DELETE from users WHERE  email LIKE :account";
        return $this->db->runsql($sql, $arguments)->rowCount();
    }

    public function getAllAdministrators() {
        $sql = "SELECT *, a.user_id, u.email, u.phone_number, concat(first_name, last_name) as concat_full_name, ";
        $sql .= "concat(address, ', ', city, ', ', country, ', ', post_code) as concat_address, ";
        $sql .= "case when a.root = 1 then 'YES!' ELSE 'NO!' END AS root_user2, ";
        $sql .= "case when a.can_alter = 1 then 'YES!' ELSE 'NO!' END AS can_alter_user2, ";
        $sql .= "case when a.can_delete = 1 then 'YES!' ELSE 'NO!' END AS can_delete_user2, ";
        $sql .= "case when a.can_delete_all = 1 then 'YES!' ELSE 'NO!' END AS can_delete_all_user2, ";
        $sql .= "a.creator_ip, a.administrator_id, a.creator, a.timestamp from administrator a LEFT OUTER JOIN users u ON ";
        $sql .= "a.user_id = u.user_id ORDER BY u.last_name, u.first_name";
        return $this->db->runsql($sql)->fetchAll();
    }
   
    public function insertHacker($ip, string $email) {
        $arguments['ip'] = $ip;
        $arguments['ema'] = $email;
        $sql = "INSERT INTO  hackers (ip, email) VALUES (:ip, :ema)";
       return $this->db->runsql($sql, $arguments);
    }
	

    public function insertUserIntoCase($caseId, $userId, $administratorId) {
        $arguments['caseId'] = $caseId;
        $arguments['userId'] = $userId;
        $arguments['administratorId'] = $administratorId;
        $sql = "INSERT INTO  cases_users (case_id, user_id, administrator_id) VALUES "; 
        $sql .= "(:caseId, :userId, :administratorId)";
        return $this->db->runsql($sql, $arguments);
    }

    public function getCases() {
        $sql = "SELECT * from cases_description";
        return $this->db->runsql($sql)->fetchAll();
    }
    public function getCasesRowCount() {
        $sql = "SELECT count(*) as count from cases_description";
        return $this->db->runsql($sql)->fetch();
    }





    public function getCaseNum(string $caseNum) {
        $arguments['caseNum'] = $caseNum;
        $sql = "SELECT * from cases_description WHERE  case_number LIKE :caseNum";
       return $this->db->runsql($sql, $arguments)->fetch();
    }
 
    public function getRowCountUsersNotAccepted() 
    {   
        
        $sql = "SELECT count(*) as count FROM users WHERE  accepted LIKE 0";
        return $this->db->runSql($sql)->fetch();
    }

   
    public function updateAcceptUser($id, $caseNumber) {
        $arguments['id'] = $id;
        $arguments['caseNumber'] = $caseNumber;
        $sql = "UPDATE users SET accepted = 1, case_id = :caseNumber WHERE  user_id LIKE :id";
       return $this->db->runsql($sql, $arguments)->rowCount();
    }
    
   
    public function selectCaseViaCaseId($caseId) {
        $arguments['caseId'] = $caseId;
        $sql = "select * from cases_description where case_id like :caseId";
        $this->db->runsql($sql, $arguments)->fetch();
    }
    
  
    public function selectUserFromCase($ema, $case) {
        $arguments['ema'] = $ema;
        $arguments['cases'] = $case;
        $sql = "SELECT * from cases WHERE  user_ident LIKE :ema and case_id LIKE :cases";
        return $this->db->runsql($sql, $arguments)->fetch();

    }
    public function selectUserFromCaseViaEmail($ema) {
       
        $arguments['ema'] = $ema;
        $sql = "SELECT * from cases c left outer join users u on u.user_id = c.user_id WHERE  email LIKE :ema";
        return $this->db->runsql($sql, $arguments)->fetch();

    }
    public function selectUserFromCaseViaId($id) {
       
        $arguments['id'] = $id;
        $sql = "SELECT * from cases c left outer join users u on u.user_id = c.user_id WHERE  user_id LIKE :id";
        return $this->db->runsql($sql, $arguments)->fetch();

    }
    public function selectCaseFromCaseDescriptionviaCaseId($caseId) {
        $arguments['caseId'] = $caseId;
		$sql = "select * from cases_users WHERE  case_id LIKE :caseId";
        $this->db->runsql($sql, $arguments);
    }

    public function selectUsersFromCase($case) {
      
        $arguments['cases'] = $case;
        $sql = "SELECT * from cases WHERE  case_id LIKE :cases";
        return $this->db->runsql($sql, $arguments)->fetchAll();

    }
    public function updateMemberToNewCase($userId, $caseNum) {
        $arguments['id'] = $userId;
        $arguments['id2'] = $userId;
        $arguments['id3'] = $userId;
        $arguments['caseNum2'] = $caseNum;
        $arguments['caseNum'] = $caseNum;
        $sql = "BEGIN TRANSACTION; ";
        $sql .= "DELETE from cases_users WHERE  user_id LIKE :id; ";
        $sql .= "INSERT INTO  cases_users (case_id, user_id) values (:caseNum, :id2); ";
        $sql .= "UPDATE users SET case_id = :caseNum2 WHERE  user_id LIKE :id3; ";
        $sql .= "COMMIT TRANSACTION;";
        return $this->db->runsql($sql, $arguments)->rowCount();
    }
    
    public function getRowCountUsers2($caseNumber) 
    {   
        $arguments['caseNum'] = $caseNumber;
        $sql = "SELECT count(*) as count FROM users WHERE  case_id LIKE :caseNum";
        return $this->db->runSql($sql, $arguments)->fetch();
    }
    public function deleteAccountViaCase($case) {
        $arguments['caseNum'] = $case;
        $sql = "DELETE from users WHERE  case_number LIKE :caseNum";
        return $this->db->runsql($sql, $arguments)->rowCount();
    }
    public function deleteFromCaseList($case) {
        $arguments['caseNum'] = $case;
        $sql = "DELETE from cases WHERE  case_id LIKE :caseNum";
        return $this->db->runsql($sql, $arguments)->rowCount();
    }
    public function deleteUserFromCaseAndDeleteUserViaUserId($user_id) {
            $arguments['user_id2'] = $user_id;
            $arguments['user_id3'] = $user_id;
            $sql = "BEGIN TRANSACTION; ";
            $sql .= "DELETE from cases_users WHERE  user_id LIKE :user_id2; ";
            $sql .= "DELETE from users WHERE  user_id LIKE :user_id3; ";
            $sql .= "COMMIT TRANSACTION; ";
            return $this->db->runsql($sql, $arguments)->rowCount();
            
        }
        public function deleteUsersFromCaseViaCase($case_id) {
            
            $arguments['case2'] = $case_id;
           
            $sql = "DELETE from cases_users WHERE  case_id LIKE :case2; ";
            return $this->db->runsql($sql, $arguments)->rowCount();
        }

       
        public function deleteCaseViaCase($case_id) {
            $arguments['case7'] = $case_id;
            $sql = "DELETE from cases_description WHERE  case_id LIKE :case7; ";
            return $this->db->runsql($sql, $arguments)->rowCount();
            
        }
        public function deleteCaseNum(string $caseNum) {
                $arguments['caseNum'] = $caseNum;
                $sql = "DELETE from cases WHERE  case_number LIKE :caseNum";
            return $this->db->runsql($sql, $arguments)->rowCount();
            }
            public function deleteCaseDescription(string $caseNum) {
                $arguments['caseNum'] = $caseNum;
                $sql = "DELETE from cases_description WHERE  case_number LIKE :caseNum";
                return $this->db->runsql($sql, $arguments);
            }

    public function deleteUsersViaCase($case) {
        $arguments['case'] = $case;
        $sql = "DELETE from users WHERE  case_number LIKE :case";
        return $this->db->runsql($sql, $arguments)->rowCount();
    
    
    }   
   
    public function insertTimeSpent($caseNu, $user_id, $time, $notes, $timestamp) {
        $arguments['case'] = $caseNu;
        $arguments['time'] = $time;
        $arguments['notes'] = $notes;
        $arguments['user_id'] = $user_id;
        $arguments['timestamp'] = $timestamp;
        $sql = "INSERT INTO  time (case_id, time_spent, notes, user_id, timestamp) ";
        $sql .= "VALUES (:case, :time, :notes, :user_id, :timestamp)";
        return $this->db->runsql($sql, $arguments);
    }
    public function countTimeSpentViaCaseNu($caseNu) {
        $arguments['case'] = $caseNu;
        $sql = "SELECT count(*) as count from time WHERE  case_id LIKE :case";
        return $this->db->runsql($sql, $arguments)->fetch();

    }
    public function countTimeSpentViaCaseNuAndEmail($caseNu, $email) {
        $arguments['case'] = $caseNu;
        $arguments['email'] = $email;
        $sql = "SELECT count(*) as count from time t LEFT OUTER JOIN  users u ON t.user_id = u.user_id";
        $sql .= " WHERE  t.case_id LIKE :case and u.email LIKE :email";
        return $this->db->runsql($sql, $arguments)->fetch();


    }


    public function countTimeSpentViaFirstNameLastName($firstName, $lastName) {
        $arguments['firstName'] = $firstName;
        $arguments['lastName'] = $lastName;
        $sql = "SELECT count(*) as count from time t LEFT OUTER JOIN  users u"; 
        $sql .= " ON t.user_id = u.user_id WHERE  u.first_name LIKE :firstName and last_name LIKE :lastName";
        return $this->db->runsql($sql, $arguments)->fetch();


    }
   
    public function countTimeSpentViaCaseIdLastName($caseId, $lastName) {
        $arguments['caseId'] = $caseId;
        $arguments['lastName'] = $lastName;
        $sql = "SELECT count(*) as count from time t LEFT OUTER JOIN  users u ON t.user_id = u.user_id ";
        $sql .= "WHERE  t.case_id LIKE :caseId and u.last_name LIKE :last_name";
        return $this->db->runsql($sql, $arguments)->fetch();


    }

    public function countTimeSpentViaFirstNameLastNameCaseId($caseId, $email) {
        $arguments['caseId'] = $caseId;
        $arguments['email'] = $email;
        $sql = "SELECT count(*) as count from time t LEFT OUTER JOIN  users u ON t.user_id = u.user_id ";
        $sql .= " WHERE  t.case_id LIKE :caseId and u.email LIKE :email";
        return $this->db->runsql($sql, $arguments)->fetch();


    }


    public function countTimeSpentViaEmail($email) {
        $arguments['email'] = $email;
        $sql = "SELECT count(*) as count from time t LEFT OUTER JOIN  users u ON t.user_id = u.user_id ";
        $sql .= "WHERE  u.email LIKE :email";
        return $this->db->runsql($sql, $arguments)->fetch();
    }
    public function countTimeSpentViaFirstLastName($lastName, $firstName) {
        $arguments['lastName'] = $lastName;
        $arguments['firstName'] = $firstName;
        $sql = "SELECT count(*) as count from time t LEFT OUTER JOIN  users u ON t.user_id = u.user_id ";
        $sql .= "WHERE  u.first_name LIKE :firstName and u.last_name LIKE :lastName";
        return $this->db->runsql($sql, $arguments)->fetch();
    }    
    public function countTimeSpentViafirstLastNameCaseId($firstName, $lastName, $case_id) {
        $arguments['lastName'] = $lastName;
        $arguments['caseId'] = $case_id;
        $arguments['firstName'] = $firstName;
        $sql = "SELECT count(*) as count from time t LEFT OUTER JOIN  users u ON t.user_id = u.user_id ";
        $sql .= "WHERE  u.last_name LIKE :lastName and t.case_id LIKE :caseId and u.firstName LIKE :firstName";
        return $this->db->runsql($sql, $arguments)->fetch();
    }    

    public function countTimeSpentViaLastName($lastName) {
        $arguments['lastName'] = $lastName;
        $sql = "SELECT count(*) as count from time t LEFT OUTER JOIN  users u ON t.user_id = u.user_id ";
        $sql .= "WHERE  u.last_name LIKE :lastName";
        return $this->db->runsql($sql, $arguments)->fetch();
    }

















    public function calculateTimeSpentViaCaseId($case) {
        $arguments['case'] = $case;
        $sql = "select case_id, sum(t.time_spent) as total_time, first_name, last_name from time t LEFT OUTER JOIN ";
        $sql .= "users u ON t.user_id = u.user_id WHERE  u.case_id LIKE :case GROUP BY t.last_name ";
        $sql .= "order by last_name asc";
        return $this->db->runsql($sql, $arguments)->fetchAll();
    }
    public function calculateTimeSpentViaEmail($email) {
        $arguments['email'] = $email;
        $sql = "select case_id, sum(t.time_spent) as total_time, first_name, last_name from time t LEFT OUTER JOIN ";
        $sql .= "users u ON t.user_id = u.user_id WHERE  u.email LIKE :email GROUP BY t.case_id ";
        $sql .= "order by t.case_id, timestamp desc";
        return $this->db->runsql($sql, $arguments)->fetchAll();
    }
    public function calculateTimeSpentViaCaseIdEmail($email, $caseId) {
        $arguments['email'] = $email;
        $arguments['case_id'] = $caseId;
        $sql = "select case_id, sum(t.time_spent) as total_time, first_name, last_name from time t LEFT OUTER JOIN ";
        $sql .= "users u ON t.user_id = u.user_id WHERE  u.email LIKE :email and t.case_id ";
        $sql .= "like :caseId GROUP BY t.timestamp ";
        $sql .= "order by timestamp desc";
        return $this->db->runsql($sql, $arguments)->fetchAll();
    }
    public function calculateTimeSpentViaLastName($lastName) {
        $arguments['lastName'] = $lastName;
        $sql = "select case_id, sum(t.time_spent) as total_time, first_name, last_name from time t LEFT OUTER JOIN ";
        $sql .= "users u ON t.user_id = u.user_id WHERE  u.last_name LIKE :lastName GROUP BY t.case_id ";
        $sql .= "order by t.case_id, timestamp asc";
        return $this->db->runsql($sql, $arguments)->fetchAll();
    }
    public function calculateTimeSpentViaCaseIdLastName($lastName, $caseId) {
        $arguments['lastName'] = $lastName;
        $arguments['caseId'] = $caseId;
        $sql = "select case_id, sum(t.time_spent) as total_time, first_name, last_name from time t LEFT OUTER JOIN ";
        $sql .= "users u ON t.user_id = u.user_id WHERE  u.last_name LIKE :lastName and t.case_id LIKE :caseId ";
        $sql .= "group by t.case_id ORDER BY last_name timestamp asc";
        return $this->db->runsql($sql, $arguments)->fetchAll();
    }
    public function calculateTimeSpentViaCaseIdFirstNameLastName($firstName, $lastName, $caseId) {
        $arguments['firstName'] = $firstName;
        $arguments['lastName'] = $lastName;
        $arguments['caseId'] = $caseId;
        $sql = "select case_id, sum(t.time_spent) as total_time, first_name, last_name from time t LEFT OUTER JOIN ";
        $sql .= "users u ON t.user_id = u.user_id WHERE  u.last_name LIKE :lastName and t.case_id LIKE :caseId ";
        $sql .= "and u.first_name LIKE :firstName GROUP BY t.case_id ORDER BY t.timestamp asc";
        return $this->db->runsql($sql, $arguments)->fetch();
    }
    public function calculateTimeSpentViaFirstNameLastName($lastName, $firstName) {
        $arguments['lastName'] = $lastName;
        $arguments['firstName'] = $firstName;
        $sql = "select case_id, sum(t.time_spent)as total_time, first_name, last_name from time t LEFT OUTER JOIN ";
        $sql .= "users u ON t.user_id = u.user_id WHERE  u.last_name LIKE :lastName and t.case_id LIKE :lastName ";
        $sql .= "group by t.case_id ORDER BY t.case_id, t.timestamp asc";
        return $this->db->runsql($sql, $arguments)->fetchAll();
    }
    


// library



    public function insertIntoLibrary($author, $title, $destination, $description, $userId) {
        $arguments['author'] = $author ;
        $arguments['title'] = $title ;
        $arguments['description'] = $description ;
        $arguments['destination'] = $destination ;
        $arguments['userId'] = $userId ;
        $sql = "INSERT INTO library (file_location, authors, description, user_id, title) values";
        $sql .= "(:destination, :author, :description, :userId, :title)";
        return $this->db->runsql($sql, $arguments);
    }
	public function selectFromLibraryViaId($id) {
		$sql = "select * from library where id like $id";
		return $this->db->runsql($sql)->fetch();

	}
	public function deleteFromLibraryViaId($id) {
		$sql = "delete from library where id like $id";
		return $this->db->runsql($sql)->rowCount();
	}
	
}