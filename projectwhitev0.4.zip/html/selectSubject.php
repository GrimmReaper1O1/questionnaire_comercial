<?php
include 'includes/header3.php';
$class = $_GET['class'] ?? '';

$page = $_GET['page'] ?? 1;
$limit = 10;
$error = '';



if (isset($_GET['class'])) {
	$_SESSION['class'] = $class;


$subjectsArray = $cms->getQuestions()->selectAllFromSubjects($_SESSION['class']);

if (isset($subjectsArray)) {
	
foreach($subjectsArray as $subjects) {
	 if ($subjects['subject_information'] != 'empty') 
	{ echo '<h3>SUBJECT:<br> <a href="questionair.php?id=' . $subjects['table_id'] . '">' . $subjects['subject_information'] . '</a>'; } 
	if ($subjects['subject_information'] != 'empty') {?></h3><p>
	The subject has <?= $subjects['number_of_questions'] ?> possible answers per question.</p>
	
<?php 
}
}
}
}

