
<?php
include "../../includes/header5.php";

if ($administrator['admin'] == 1) {
?>

    <?php if ($administrator['admin'] == 1) { ?>
    <a href="allow_entry_to_users.php">Allow entry to users</a><br>
    <?php }?>
    <?php if ($administrator['admin'] == 1) { ?>
    <a href="assign_user_to_new_class.php">Assign user to a new class</a><br>
    <?php }   ?>
    <?php if ($administrator['root'] == 1 || $administrator['can_delete_all'] == 1) { ?>
    <a href="createAdministrativeAccount.php">Create administrative account or delete any user account</a><br>
    <?php }?>
    <?php if ($administrator['admin'] == 1) { ?>
    <a href="create_new_class.php">Create new class</a><br>

    <a href="create_user_and_assign_class.php">Create user and assign class</a><br>
    <?php }   ?>
    <?php if ($administrator['can_remove_class'] == 1 || $administrator['root'] == 1) { ?>
    <a href="delete_class.php">Delete class</a><br>
	<a href="../../library/delete_document.php?unset=yes">Delete document</a><br>
	<a href="delete_subject_from_class.php">Delete subject from class</a><br>
    <?php }   ?>
    <?php if ($administrator['root'] == 1) { ?>
    <a href="delete_user_from_class.php">Delete user from class and delete user</a><br>
    <?php }   ?>
    <?php if ($administrator['admin'] == 1) { ?>
    <a href="../library/library.php?unset=yes">Library</a><br>
   
    <?php }	?>
    <?php if ($administrator['admin'] == 1) { ?>

  
	 <a href="search_for_user.php">Search for user in classes</a><br>
 

    <?php }
    if ($administrator['root'] == 1) { ?>
    <a href="show_all_administrators.php">Show all administrators</a><br>
    <?php }   ?>

    <?php if ($administrator['root'] == 1) { ?>

    <?php }   ?>
    <?php if ($administrator['root'] == 1) { ?>

    <?php }   ?>
 
  
    <?php if ($administrator['admin'] == 1) { ?>

    <?php }   ?>
    <?php if ($administrator['admin'] == 1) { ?>
    <a href="search_via_name.php">Search via name</a><br>
    <a href="../library/upload_pdf.php">Upload a pdf to the library</a><br>
    <a href="view_active_cases.php">View acitve cases</a><br>
    <?php  }?>



<?php
include "../../includes/footer.php";
} else {
    header("Location: how_dare_you.php");
    exit();
}
