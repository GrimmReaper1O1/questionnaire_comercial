<?php 
include 'includes/header_others.php';
if ($administrator['admin'] == 1) {
if ($_SERVER["REQUEST_METHOD"] === "POST") {
$id = $_POST['ident'] ? $_POST['ident'] : NULL;
$email = $_POST['email'] ? $_POST['email'] : NULL;
if ($email !== NULL) {
$result = $cms->getEvidence()->getEvidenceViaEmail($email);    
if ($result === false) {
    echo "There was a problem. The problem is likely that there is no entry with the provided information, otherwise please contact your administrator.";
}
?>
<form action="search_via_id_or_email.php" method="POST">
<label name="email">Email:<label>
<input type="text" name="email">
<br>
<label name="ident">ID:<label>
<input type="number" name="ident"><br>
<input type="submit" value="SUBMIT!"><br>
<?php

if ($result !== false) {
foreach($result as $row) { ?>
    ID: <?= $row['id'] ?><br>
    Anonymous:  <?= $row['anon2'] ?><br>
    Name: <?= $row['concat_full_name'] ?><br>
    Phone Number: <?= $row['phone_number'] ?><br>
    Email: <?= $row['email'] ?> <br>
    Contact Info: <?= $row['concat_full_address'] ?> <br>
    Description: <?= $row['description'] ?><br>
    Evidence: <?= $row['statement'] ?><br>
	Hidden: <?= $row['hid2'] ?><br>
<?php } } 



}
if ($id !== NULL) {
    $row = $cms->getEvidence()->getEvidenceViaId($id);
  
if ($row == false) {
    echo "There was a problem. The problem is likely that there is no entry with the provided information, otherwise please contact your administrator.";
}
?>

<form action="search_via_id_or_email.php" method="POST">
<label for="email">Email:<label>
<input type="text" name="email">
<br>
<label for="ident">ID:<label>
<input type="number" name="ident"><br>
<input type="submit" value="SUBMIT!"><br>
<?php if ($row != false) { ?>
ID: <?= $row['id'] ?><br>
    Anonymous: <?= $row['anon2'] ?> <br>
    Name: <?= $row['concat_full_name'] ?><br>
    Phone Number: <?= $row['phone_number'] ?><br>
    Email: <?= $row['email'] ?> <br>
    Contact Info: <?= $row['concat_full_address'] ?> <br>
    Description: <?= $row['description'] ?><br>
    Evidence: <?= $row['statement'] ?><br>
	Hidden: <?= $row['hid2'] ?><br>

<?php } 
 }  }
 else { 
    ?>
    
    <form action="search_via_id_or_email.php" method="POST">
<label name="email">Email:<label>
<input type="text" name="email">
<br>
<label name="ident">ID:<label>
<input type="number" name="ident"><br>
<input type="submit" value="SUBMIT!"><br>
<?php }
include "includes/footer.php";
} else {
    header("Location: how_dare_you.php");
    exit();
}