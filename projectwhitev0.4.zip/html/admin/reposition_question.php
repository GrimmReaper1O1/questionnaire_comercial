<?php 
include '../includes/header4.php';
$page = $_GET['page'] ?? 1;
$limit = 10;
$error = '';
if (isset($_GET['ids'])) {
	$_SESSION['ids'] = $_GET['ids'];
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	
	$count = $cms->getQuestions()->updateQuestionDescriptionPossition($_SESSION['ids'], $_POST['possition']);
	
	if ($count < 0) {
		$error .= "THE UPDATE WAS A SUCCESS!";
	} else {
		$error .= "THE UPDATE FAILED.";
	}
	
	
	
	
	
}
$row = $cms->getQuestions()->selectQuestionDescriptionViaQuestionId($_SESSION['ids']);
echo "QUESTION POSSITION:" . $row['question_number'] . "<br>";
echo "QUESTION:" . $row['description'] . "<br>";
?>
<?= $error ?><br>
<form action="reposition_question.php" method="POST">
	<label for="possiton">NUMBER TO REPOSSITON TO:</label><br>
	<input type="text" name="possition" size="20" value="<?= $_POST['possition'] ?? '' ?>">
	<input type="submit" value="SUBMIT!">
	</form>
	<?php 
	if (isset($_GET['id']) || isset($_SESSION['subject'])) {



$questions = $cms->getQuestions()->selectQuestions($_SESSION['subject'], $page, $limit);
$totalQuestions = $questions[0]['count'];
$totalPages = ceil($totalQuestions / $limit);
echo '<a href="adminSubjectsAndQuestionClassifications.php?unset=yes">BACK TO MAIN ADMINISTRATIVE PAGE!</a><br>';
echo "<h1>" . $questions[1][0]['subject_information'] . "</h1><br>";

foreach($questions[1] as $question) {

	?><h3>QUESTION POSSITION:</h3><br><?= $question['question_number'] ?><br>
	<a href="reposition_question.php?ids=<?= $question['question_id'] ?>">REPOSSITION QUESTION!</a><br>
	<h3>DESCRIPTION OF QUESTION:</h3><br>
	<h4><p><a href="questionsAndAnswers.php?id=<?= $question['question_id'] ?>"><?= $question['description'] ?></a></p></h4><br><br><br>

<?php
} echo "-";
for($i = 1; $i <= $totalPages; $i++){
?><a href="adminSubjectsAndQuestionClassifications.php?page=<?= $i ?>"><?= $i ?>-</a>
<?php
}
	}