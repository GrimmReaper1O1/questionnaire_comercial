<?php
include "../includes/header4.php";
$class = $_GET['class'] ?? '';
$page = $_GET['page'] ?? 1;
$limit = 1;
$error = '';
if (isset($_GET['unset'])) {
	unset($_SESSION['subject']);
}
if (isset($_GET['class'])) {
	$_SESSION['class'] = $class;
}



if (isset($_GET['updateSubject'])) {
		$number = $_GET['updateSubject'];
		$_SESSION['updateSubject'] = $number;
	?>
	PLEASE ENTER THE NEW NAME AND NUMBER OF QUESTIONS IF DESIRED.<br>
	YOU MAY ENTER EITHER OR BOTH; HOWEVER IF YOU CHANGE THE NUMBER<br>
	OF QUESTIONS YOU WILL NEED TO UPDATE THE ANSWERS AND POSSIBLE<br>
	ANSWERS OF EACH QUESTION AS WELL.<br>
	<form action="adminSubjectsAndQuestionClassifications.php" method="POST">
		<label for="name">ENTER NEW NAME:</label><br>
		<input type="text" name="name" size="100"><br>
		<label for="number">ENTER NEW NUMBER OF QUESITONS:</label><br>
		<input type="text" name="number" size="100"><br>
		<input type="submit" value="SUBMIT!">
		</form>
	<?php
	}

if (isset($_POST['name']) && isset($_POST['number'])) {

	
	if ($_POST['name'] != '') {
	$result = $cms->getQuestions()->updateSubjectName($_SESSION['updateSubject'], $_POST['name']);
	if ($result == 1) {
		$error .= "THE UPDATE OF NAME WAS SUCCESSFULL!<br>";
	}
	else
	{
		$error .= "FOR SOME REASON THE UPDATE OF NAME WAS NOT SUCCESSFULL.<br>";
	}
	
	}
	
if ($_POST['number'] != '') {
	

	$number = intval($_POST['number']);
	$result = $cms->getQuestions()->updateSubjectsNumberOfQuestions($_SESSION['updateSubject'], $number);
	if ($result == 1) {
		$error .= "THE UPDATE OF NUMBER WAS SUCCESSFULL!<br>";
	}
	else
	{
		$error .= "FOR SOME REASON THE UPDATE OF NUMBER WAS NOT SUCCESSFULL.<br>";
	}
	
	}
	
echo $error;
	?>
<a href="adminSubjectsAndQuestionClassifications.php?class=<?= $_SESSION['class'] ?>">BACK TO SUBJECTS!</a>

<?php
}


if (isset($_SESSION['class']) && !isset($_SESSION['subject']) && !isset($_GET['id']) && !isset($_GET['updateSubject'])
	&& !isset($_POST['name'])) {
$subjectsArray = $cms->getQuestions()->selectAllFromSubjectsAdmin($_SESSION['class']);

echo "<h1>SELECT THE SUBJECT TO ALTER</h1><br>";	
		

foreach($subjectsArray as $subjects) {
	?>
	
	<h3>SUBJECT: <?php if ($subjects['subject_information'] != 'empty') 
	{ ?>
<a href="adminSubjectsAndQuestionClassifications.php?id=<?= $subjects['table_id'] ?>&info=<?= $subjects['subject_information'] ?>"><?= $subjects['subject_information'] ?></a><br>
The subject has <?= $subjects['number_of_questions'] ?> possible answers per question.<br>
<br> <a href="fillQuestionair.php?id=<?= $subjects['table_id'] ?>">ADD QUESTIONS OR ALTER SUBJECT NAME.</a><br><br>
	<a href="deleteAllQuestionsFromSubject.php?id=<?= $subjects['table_id'] ?>">DELETE ALL INFORMATION FROM TABLE ABOVE!</a><br><br>
	<a href="adminSubjectsAndQuestionClassifications.php?updateSubject=<?= $subjects['id'] ?>">UPDATE SUBJECT NAME OR NUMBER OF QUESTIONS!</a><br><br><br>
	<?php }	else { echo '<br> <a href="fillQuestionair.php?id=' . $subjects['table_id'] . '">FILL SUBJECT!</a>'; } 
	if ($subjects['subject_information'] != 'empty') {?></h3>

	<?php
}
}


}

if (isset($_GET['id']) || isset($_SESSION['subject'])) {
if (isset($_GET['id'])) {
$_SESSION['subject'] = $_GET['id'];
}


$questions = $cms->getQuestions()->selectQuestions($_SESSION['subject'], $page, $limit);
$totalQuestions = $questions[0]['count'];
$totalPages = ceil($totalQuestions / $limit);
echo '<a href="adminSubjectsAndQuestionClassifications.php?unset=yes">BACK TO MAIN ADMINISTRATIVE PAGE!</a><br>';
echo "<h1>" . $_GET['info'] . "</h1><br>";

foreach($questions[1] as $question) {

	?><h3>QUESTION POSSITION:</h3><br><?= $question['question_number'] ?><br>
	<a href="reposition_question.php?ids=<?= $question['question_id'] ?>">REPOSSITION QUESTION!</a><br>
	<h3>DESCRIPTION OF QUESTION:</h3><br>
	<h4><p><a href="questionsAndAnswers.php?id=<?= $question['question_id'] ?>"><?= $question['description'] ?></a></p></h4><br><br><br>

<?php
} echo "-";
for($i = 1; $i <= $totalPages; $i++){
?>
<a href="adminSubjectsAndQuestionClassifications.php?page=<?= $i ?>&info=<?= $_GET['info'] ?>"><?= $i ?>-</a>
<?php
}
}