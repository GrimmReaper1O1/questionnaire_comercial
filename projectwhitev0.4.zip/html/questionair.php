<?php
include "includes/header3.php";
$page = $_GET['page'] ?? 1;
$limit = 4;
$infFalse = 0;
if (isset($_GET['id'])) {
	$_SESSION['subject'] = $_GET['id'];
}

$row = $cms->getQuestions()->selectSubjectViaTableId($_SESSION['subject']);
$questionDesc = $cms->getQuestions()->selectAllQuestionsFromSubjectPagination($page, $limit);
$count = count($questionDesc[1]);


if (isset($questionDesc)) {
?>
<form action="questionair.php" method="POST">
<?php
for($c = 0; $c < $count - 1; $c++) {

$info = $cms->getQuestions()->selectQuestion($questionDesc[1][$c]['question_id']);
if ($info != false) { $infFalse++; }
?>
<?= $info['question'] ?><br>

<?php

for($i = 1; $i < ($row['number_of_questions'] + 1); $i++) {

?>
<input type="radio" name="<?= $c . "a" . $i ?>"> <p><?php echo paragraph($info['pa' . $i]); ?></p>	
<?php
}

 
}} ?> 
<input type="submit" value="SUBMIT!">
</form><?php
if ($infFalse > 0) {
	echo "There is no quesiton information assigned.";

}
}