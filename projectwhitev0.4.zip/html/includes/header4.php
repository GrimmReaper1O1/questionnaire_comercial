<?php
require '../../src/bootstrap.php';

$administrator = $cms->getMember()->selectAdminViaUserId($_SESSION['id']);


?>
<html>
<style>
aside {
  display: inline-block,
  float: left,
  width: 10%,
}
#main {
  display: inline-block,
  float: right,
  width: 88%,
}
</style>

    <head></head>
    <body>
    <img src="banner">
    <nav><a href="../classes.php">Classes</a> | <a href="../aboutUs.php">About Us</a> | <a href="../contactUs.php">Contact Us</a><?PHP if ($administrator['admin'] == 1) {echo " | <a href='userAdmin/set_administrator_options.php'>Administer users and classes</a> | <a href='classes.php'>Administer classes</a>";}?> | <a href="../logout.php">Sign Out</a> </nav>
    <br>
    <br>
    <br>
