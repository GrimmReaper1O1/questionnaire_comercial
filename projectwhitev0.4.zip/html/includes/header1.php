<?php
?>
<html>
    <head></head>
    <body>
    <h1><a href="signup.php">Sign Up!</a> | <a href="index.php">Back To Main Page!</a></h1>