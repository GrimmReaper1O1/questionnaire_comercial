<?php
include '../includes/header_others.php';
$error2 = '';
$message = '';




if ($_SERVER['REQUEST_METHOD'] === 'POST') {

$moved = false;
    
    $error2 = '';
    $upload_path = '../uploads/';
    $max_size = 2137552;
    $allowed_types = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',];
    $allowed_exts = ['pdf', 'doc', 'docx',];

      $error2 = ($_FILES['document']['size'] <= $max_size) ? '' : 'Your file is too large. It must be under 2MB';
      $type = mime_content_type($_FILES['document']['tmp_name']);
      $error2 .= in_array($type, $allowed_types) ? '' : 'Your file is of the wrong type. It must be a pdf, doc or docx.';
      $ext = strtolower(pathinfo($_FILES['document']['name'], PATHINFO_EXTENSION));
       $error2 .= in_array($ext, $allowed_exts) ? '' : 'It must have the right file extension.';

       if (!$error2) {
        $filename = create_filename($_FILES['document']['name'], $upload_path);
        $destination = $upload_path . $filename;
        $moved = move_uploaded_file($_FILES['document']['tmp_name'], $destination);
        
       }
       if ($moved === true) {
        $row = $cms->getMember()->selectAdministratorViaUserId($_SESSION['id']);
    try {
        $check = $cms->getMember()->insertIntoLibrary($_POST['author'], $_POST['name'], $destination, $_POST['description'], $row['administrator_id']);
        $message .= "Your document updated successfully! ";
    } catch(Exception $e) {
        $error2 .= "We're sorry! There was a problem. Please try again.";
    }   
    
    }

}

echo $error2 . $message . '<br>';
if ($message == '') {
?>


<form action="upload_pdf.php" method="POST" enctype="multipart/form-data">
    <label for="name">PDF text name:</label>
    <input type="text" name="name"value="<?=  $_POST['name'] ?? '' ?>"><br>
   
    <label for="author">Author</label>
    <input type="text" size="50" name="author" value="<?= $_POST['author'] ?? '' ?>"><br>
    Description of file:<br>
    <textarea name="description" rows="10" cols="80"> <?= $_POST['description'] ?? '' ?></textarea><br>
    <label for="document">Upload PDF file:</label>
    <input type="file" name="document"><br>
    <input type="submit" name="submit" value="SUBMIT!">
    </form>

    <?php }