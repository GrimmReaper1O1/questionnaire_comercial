<html>
	<body>



<script type="module">
import {saveToIndexedDB, loadFromIndexedDB, } from './src/lMTest.js';
var test;
var result = saveToIndexedDB('test', {id: "version 5"}, 'class1subject1', 'test', 6).then(function (resolve) {
console.log(resolve);

}).catch(function (error) {
console.log(error);
test = error;
});
var result = saveToIndexedDB('test', {id: "version 6"}, 'class1subject2', 'test', 6).then(function (resolve) {
console.log(resolve);

}).catch(function (error) {
console.log(error);
test = error;
});
var result = loadFromIndexedDB('test', 'test', 'test').then(function (resolve) {
console.log(resolve);

}).catch(function (error) {
console.log(error);
test = error;
});
console.log(result);
console.log(test);

</script>

</body>
</html>
