<?php
	include "includes/header3b.php";
		if (isset($_SESSION['id'])) {



			?>
	
	<div id="main" class="main">
		<div class="mainbody">

		<div class="heightHeader">
		</div>

<div style="height: 200px;">
</div>

			<?php



	if (isset($_GET['reset'])) {
		unset($_SESSION['gate']);
		unset($_SESSION['allQuestions']);//
		unset($_SESSION['questionDesc']);//
		unset($_SESSION['sortedIds']);//
		unset($_SESSION['countedNumberOfQuestionsPerQuestion']);//
		unset($_SESSION['pageQuestionIds']);//
		unset($_SESSION['fast']);//
		unset($_SESSION['info']);//
		unset($_SESSION['numeral']);//
		unset($_SESSION['runs']);//

		unset($_SESSION['setFirst']);//
		unset($_SESSION['questionLimitNumber']);//
		unset($_SESSION['qr']);
		unset($_SESSION['pagesIds']);
		unset($_SESSION['loopNumber']);//
		unset($_SESSION['page']);
		unset($_SESSION['countOfPageQuestions']);//
		unset($_SESSION['choiceArray']);

		unset($_SESSION['countedIds']);
		unset($_SESSION['sourcedQuestions']);
		$_SESSION['reset'] = 'yes';
	if (!isset($_SESSION['countOfPageQuestions'])) {
		$questionPossition = $cms->getQuestions()->selectSubjectViaTableIdAndClassId();

		$_SESSION['numberOfQuestionsOnPage'] = $questionPossition['number_of_questions'];

		$numeralOfRem = $questionPossition['number_of_removal'];
	} else {
		$numeralOfRem = $_SESSION['number_of_removal'];
		$numberOfQuestionsOnPage = $_SESSION['countOfPageQuestions'];
	}


}

	if (isset($_GET['unset'])) {

unset($_SESSION['countedNumberOfQuestionsPerQuestion']);
unset($_SESSION['sortedIds']);
unset($_SESSION['loopNumber']);
unset($_SESSION['questionDesc']);

//unset($_SESSION['countOfPageQuestions']);
	}
	if (isset($_GET['newpg'])) {
		unset($_SESSION['gate']);
		$_SESSION['reset'] = 'yes';
		unset($_SESSION['fast']);
		unset($_SESSION['countedNumberOfQuestionsPerQuestion']);
		unset($_SESSION['pageQuestionIds']);
		unset($_SESSION['sortedIds']);
		unset($_SESSION['questionLimitNumber']);
		unset($_SESSION['qr']);
		unset($_SESSION['info']);
		unset($_SESSION['runs']);
		unset($_SESSION['loopNumber']);
		unset($_SESSION['countOfPageQuestions']);//
		unset($_SESSION['numeral']);
		unset($_SESSION['setFirst']);

		unset($_SESSION['questionDesc']);
		unset($_SESSION['countedIds']);
		unset($_SESSION['sourcedQuestions']);

			}

		$page = $_GET['page'] ?? 1;
	if (isset($_GET['newpg']) || isset($_GET['refresh']) || isset($_GET['reset'])) {
		$_SESSION['page'] = $page;
	}



	?>

	<?php
	// echo $_SESSION['fast'];


		if ((isset($_GET['reset']) ||  isset($_GET['refresh']) || isset($_GET['newpg'])) && !isset($_GET['buffer'])) {
		if (!isset($_SESSSION['fast'])) {

		if (isset($_SESSION['numberOfQuestionsOnPage'])) {
		$numeralOfRem = $_SESSION['numeralOfRem'];
		$numberOfQuestionsOnPage = $_SESSION['numberOfQuestionsOnPage'];

	}
if (!isset($_SESSION['countedNumberOfQuestionsPerQuestion'])) {

	// if (!isset($_SESSION['countedIds'])) {
	// $_SESSION['countedIds'] = $cms->getQuestions()->countQuestionIds();



	// } else {
	// 	$countedIds = $_SESSION['countedIds'];
	// }
	if (isset($_GET['newpg']) || isset($_GET['reset'])) {
		$questionIds = $cms->getQuestions()->selectQuestionIdsPagination($page, $numberOfQuestionsOnPage);
	$_SESSION['sourcedQuestions'] = count($questionIds[1]);
	}
	if (isset($questionIds)) {
		$pageQuestionIds = $cms->getQuestions()->selectQuestionInformationIdFromQuestionIds($questionIds[1]);
		$_SESSION['countOfPageQuestions'] = count($pageQuestionIds);

	}

 if(!isset($_SESSION['sortedIds'])) {

$sortedIds = $cms->getQuestions()->sortArrayViaQuestionIdsArray($questionIds[1], $pageQuestionIds);

$_SESSION['sortedIds'] = $sortedIds;
$pagesIds = $sortedIds;

} 	else {
	$pagesIds = $_SESSION['sortedIds'];
}

if ($_SESSION['sortedIds']['a' . 0] != 'empty') {








		$counted = count($pagesIds);


	for ($i = 0 ; $i < $counted ; $i++ ) {
	$countedNumberOfQuestionsPerQuestion['a' . $i] = count($pagesIds['a' . $i]);

	}


	$_SESSION['countedNumberOfQuestionsPerQuestion'] = $countedNumberOfQuestionsPerQuestion;
	$countedNumberOfQuestionsPerQuestion = $_SESSION['countedNumberOfQuestionsPerQuestion'];
	$pagesIds = $_SESSION['sortedIds'];
}
	} else {
	$countedNumberOfQuestionsPerQuestion = $_SESSION['countedNumberOfQuestionsPerQuestion'];
	$pagesIds = $_SESSION['sortedIds'];
	}



	if ($_SESSION['sortedIds']['a' . 0] != 'empty') {


			if (!isset($_SESSION['loopNumber'])) {
				$loopNumber = count($pagesIds);
				$_SESSION['loopNumber'] = $loopNumber;

		}	else {
			$loopNumber = $_SESSION['loopNumber']; }
		}
	}
		$totalPages = $_SESSION['totalPages'];


	if ($_SESSION['sortedIds']['a' . 0] != 'empty') {
	if (isset($_GET['fast'])) {
		$_SESSION['fast'] = 1;
	}

$info = $cms->getQuestions()->selectQuestionAllAtOnce($pagesIds, $countedNumberOfQuestionsPerQuestion);
$runs = $_SESSION['runs'];




$sourcedQuestions = $_SESSION['sourcedQuestions'];
$info['numeralOfRem'] = $_SESSION['numeralOfRem'];
	}}
	$sourcedQuestions = $_SESSION['sourcedQuestions'];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_GET['refresh']) && !isset($_GET['reset'])) {


} else {
?>
<script>
var posted;
</script>
<?php
}
?>
<div class="heightHeader"> </div>

<?php


if (isset($_GET['buffer'])) {

	?> <div class="width100">
	<form action="questionnaire.php?page=<?= $_SESSION['page'] ?>" method="POST">
		<?php
		for ($i = 0 ; $i < count($_SESSION['countedNumberOfQuestionsPerQuestion']) ; $i++ ) {

			?>

	<br>
	<div class="qanswer2">
	<div id="<?= $i ?>">


	<br>
	<h4 id="a<?= $i ?>"></h4>
	<br>
	</div>
		</div>
	<br>

	<?php
		} ?><div class="marginAuto width20">
		<input class="marginAuto width100" type="submit" value="SUBMIT!">
		</form>
		<form action="questionnaire.php?page=<?= $_SESSION['page'] ?>&newpg=yes<?php if (isset($_SESSION['fast'])) { echo "&fast=yes"; } ?>" method="POST">
		<input class="marginAuto width100" type="submit" value="RESET PAGE QUESTIONS!">
		</form>
		<form action="resBuff.php?tp=<?= $_SESSION['totalPages'] ?>" method="POST">
		<input class="marginAuto width100" type="submit" value="CHECK QUESTION STATS!">
		</from>
		<br>
		<br>
		<br></div>
		<div style="text-align: center; margin: 0 auto;" ><h1>PAGE:<?= $_SESSION['page'] ?><h1></div>

	</div>
	<div class="addHeight"></div>
	<div class="addHeight"></div>
		<?php
	}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_GET['refresh']) && !isset($_GET['reset'])) {
	
	
	if (isset($_SESSION['fast'])) { ?>

		<form action="questionnaire.php?refresh=yes&fast=yes&page=<?= $_SESSION['page'] ?>" method="POST">

	<?php } else { ?>

		<form action="questionnaire.php?refresh=yes&page=<?= $_SESSION['page'] ?>" method="POST">


	<?php } ?>

		<h4 class="reply" id="reply"></h4>
		<input style="display: block; margin-left: auto; margin-right: auto;" type="submit" value="NEXT QUESTION SET!"></form>

	</form>

	<div class="addHeight"></div>
	<div class="addHeight"></div>
	<?php

	?>





<?php
}

if (!isset($_GET['reset']) && !isset($_GET['refresh']) && !isset($_GET['buffer']) && !isset($_GET['newpg'])) {


	if (!isset($_SESSION['page'])) {
	$page = 1;

	}
	?>
	<script>
	
	var newpg = '<?= $_GET['newpg'] ?? 'no' ?>';
	var refresh = '<?= $_GET['refresh'] ?? 'no' ?>';

	var page = 'page' + <?= $_SESSION['page'] ?? 1 ?>;
var posted = <?= json_encode($_POST) ?>;
var databaseName = "QuestionnaireClass<?= $_SESSION['site']['cId'] ?>";
var key = "qS<?= $_SESSION['subject'] ?>C<?= $_SESSION['site']['cId'] ?>P<?= $page ?? 1?>";
var storeName = "QuestionnaireSubject<?= $_SESSION['subject'] ?>Class<?= $_SESSION['site']['cId'] ?>Page<?= $page ?? 1 ?>";
var  qAnsw = JSON.stringify(sessionStorage.getItem(page));
var style = {'coqaab': '<?= $_SESSION['layoutOfSite']['coqaab'] ?? 'white' ?>',
							'soqipip': '<?= $_SESSION['layoutOfSite']['soqipip'] ?? 80 ?>',
							'cotiqaab': '<?= $_SESSION['layoutOfSite']['cotiqaab'] ?? 'black' ?>',
							'qbc': '<?= $_SESSION['layoutOfSite']['qbc'] ?? 'black' ?>'
};
	</script>
<script src="script/loadMod2.js">
	</script>
	
<?php

}




// print_r($info);
if (isset($info)) {
	?>










<?php if (isset($_GET['reset']) || (isset($_GET['reset']) && isset($_GET['fast'])) || isset($_GET['refresh']) || isset($_GET['newpg'])) { ?>
	<div class="addHeight"></div>
	<div class="addHeight"></div>
<script>
	var whatthe = <?= $_SESSION['page'] ?>;
	sessionStorage.setItem('start', 'on');
var pg = 'page<?= $_SESSION['page'] ?>'
var databaseName = "QuestionnaireClass<?= $_SESSION['site']['cId'] ?>";
var key = "qS<?= $_SESSION['subject'] ?>C<?= $_SESSION['site']['cId'] ?>P<?= $page ?? 1?>";
var storeName = "QuestionnaireSubject<?= $_SESSION['subject'] ?>Class<?= $_SESSION['site']['cId'] ?>Page<?= $_SESSION['page'] ?? 1 ?>";
var fast = '<?= $_SESSION['fast'] ?? 'no' ?>';
var pageNo = '<?= $page ?? 1 ?>';
sessionStorage.setItem('pg', 'page<?= $_SESSION['page'] ?>');

var arr = <?= json_encode($info) ?>;
arr.fast = fast;
arr.db = {dN: databaseName, ky: key, sN: storeName,};
sessionStorage.setItem('arr', JSON.stringify(arr));
</script>

<?php if (isset($_GET['reset']) || isset($_GET['newpg'])) {
	?>
	<script>
		var reset = 'yes';
		sessionStorage.setItem('res', 'yes');
var arryFirst = {
		<?php
for ($i = 0 ; $i < $sourcedQuestions ; $i++) { ?>
	 a<?= $i ?>: { 0: {0:[]},
		 numeralPos: '<?= $i ?>',
	 },

<?php }

?> qr: {}, qAnsw: {rightAndWrong: {
<?php for ($i = 0; $i < $_SESSION['sourcedQuestions']; $i++) {
		?>
	  a<?= $i ?>: {right: 0, wrong: 0,},
	<?php } ?> length: <?php echo ($sourcedQuestions); ?>,
},},
qLength: <?php echo ($sourcedQuestions); ?>,
length: <?php echo ($sourcedQuestions); ?>,

};

sessionStorage.setItem('arryFirst', JSON.stringify(arryFirst));
</script>	<?php
} else { ?>
<script>
var reset = 'no';
</script>
<?php } 


if (isset($_GET['reset']) || isset($_GET['newpg'])) {
	   ?>

<script>













sessionStorage.setItem('pg', 'page<?= $_SESSION['page'] ?? 1 ?>');

sessionStorage.setItem('numeral', JSON.stringify(arr['numeral']));
sessionStorage.setItem('rem', JSON.stringify(arr['numeralOfRem']));
sessionStorage.setItem('arryFirst', JSON.stringify(arryFirst));

sessionStorage.setItem('qr', JSON.stringify(arryFirst['qr']));

if (typeof sessionStorage.getItem(pageNo) === null) {
sessionStorage.setItem(pageNo, JSON.stringify(arryFirst.qAnsw.rightAndWrong));
}
</script>
<?php }
 ?>
<script>

var page = 'page' + <?= $page ?? 1 ?>;
var sourcedQuestions = <?= $_SESSION['sourcedQuestions'] ?? 'undefined' ?>;

</script>

<script>
<?php 

			?>

		var newpg = '<?= $_GET['newpg'] ?? 'no' ?>';
		var refresh = '<?= $_GET['refresh'] ?? 'no' ?>';
		sessionStorage.setItem('arr', JSON.stringify(arr));
		
	</script>
 <?php if (isset($_GET['reset']) ||isset($_GET['refresh']) || isset($_GET['newpg']) || (isset($_GET['newpg']) && isset($_GET['fast']))) { ?>
 <script src="script/loadMod.js">

</script>








<?php
}

}
}



		if (isset($_GET['buffer'])) {
?>
<script>
<?php if (!isset($_SESSSION['fast'])) {
	
		?>

var databaseName = "QuestionnaireClass<?= $_SESSION['site']['cId'] ?>";
var key = "qS<?= $_SESSION['subject'] ?>C<?= $_SESSION['site']['cId'] ?>P<?= $page ?? 1?>";
var storeName = "QuestionnaireSubject<?= $_SESSION['subject'] ?>Class<?= $_SESSION['site']['cId'] ?>Page<?= $_SESSION['page'] ?>";
var page = 'page'+<?= $_SESSION['page'] ?? 1 ?>;
</script>
<?php } ?>
<script>
	
	
	var newpg = '<?= $_GET['newpg'] ?? 'no' ?>';
	var refresh = '<?= $_GET['refresh'] ?? 'no' ?>';
	var sourcedQuestions = <?= $sourcedQuestions ?>;
	</script>

<script src="script/loadMod3.js">
</script>
	<div style="text-align: center;">
	<?php
}

	$end = microtime(true);
		echo ($end - $start);
}
	?>
	</div>
</div>
</div>


<?php
if (isset($_SESSION['layoutOfSite']['enableMovingBars'])) {
    if ($_SESSION['layoutOfSite']['enableMovingBars'] == '1') {

?>
<div id="rightLowerSidebar" class="rightLowerSidebar">

	</div>
	</div>
	</div>

<?php

    }
}

if ($_SESSION['totalPages'] > 1 && isset($_GET['buffer'])) {
?>




<div id="pagination" class="pagination">
	<div class="pageWidthPombw">
<?php
$questionnaire = "questionnaireBuf.php";
$option = '';
echo get_pagination_links($_SESSION['page'], $_SESSION['totalPages'], $questionnaire, $option);
?>
</div>
</div>
<br>
<br>
<br>
<br>
<?php } ?>
<div>
<?php
include "includes/footer2.php";
?>
</div>
</body>
</html>
