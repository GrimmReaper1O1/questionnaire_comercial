

  function h4 (text) {
    var elemented = "<h4>" + text + "</h4>";
    return elemented;
  }
  function paragraph(text) {
    var para = "<p>"+text+"</p>";
    para.textContent = text;
    return para;
  }
  function paragraphs(text) {
  var paragraphs = text.split(/\r\r|\r\n/);

  var htmlParagraphs = [];

  paragraphs.forEach(function(paragraphText) {
    paragraphText = paragraphText.trim();

    var htmlParagraph = "<p>" + paragraphText + "</p>";

    htmlParagraphs.push(htmlParagraph);
  });

  var htmlOutput = htmlParagraphs.join("");


    return htmlOutput;
  }


  function countValues(obj) {
    let count = 0;

    for (let key in obj) {

        count++;
      }

    return count;
  }


  function runOne (arry, numeralOfRemoval) {

document.addEventListener("DOMContentLoaded", (arry, numeralOfRemoval) => {
const radioGroup = {}
for (var i = 0 ; i < arry.qLength ; i++) {
radioGroup[i] = {
    init: function() {
        const radioButtons = document.querySelectorAll('.r'+i+'adio-button');
        radioButtons.forEach(function(radioButton) {
            radioButton.addEventListener('click', function() {
                // Disable all other radio buttons
                radioButtons.forEach(function(rb) {
                    if (rb !== radioButton) {
                        rb.disabled = true;
                    }
                });
            });
        });
    },
}
radioGroup[i].init()
}
})
var text = '';
var newtext = '';
var finalText = '';
for (let i = 0 ; i <= arry.qLength - 1; i++) {
var div1 = document.getElementById('a'+i);

if (numeralOfRemoval != arry.qAnsw.rightAndWrong['a'+i]['right']) {
console.log('start');
console.log(arry.qLength)
console.log(arry['numeral']);
console.log(i);
text = arry['a' + i][0][arry['numeral'][i]]['question'];
newtext = paragraphs(text);
finalText = "Question: " + newtext;
for (let c = 1 ; c < 9 ; c++) {
var keyzero = {};
keyzero[c] = 'pa' + c;
if (arry['a' + i][0][arry['numeral'][i]][keyzero[c]] != 'empty') {
var text = arry['a' + i][0][arry['numeral'][i]][keyzero[c]];
newtext = paragraphs(text);
finalText += '<input type="radio" name="' + i + 'a' + c + '" class="r'+i+'adio-button" onclick="radioGroup['+i+']">' + "Answer: " + newtext;
var keyone = {};
    keyone[c] = 'hint' + c;
if (arry['a' + i][0][arry['numeral'][i]][keyone[c]] != 'empty') {
text = arry['a' + i ][0][arry['numeral'][i]][keyone[c]];
newtext = paragraphs(text);
finalText += "Hint: " + newtext;
            }
        }
    }
    div1.innerHTML += finalText;
} else {
    div1.innerHTML = "QUESTION COMPLETE!";
}
}
console.log('runhere');
return arry;
}

(function(){

  var rem = sessionStorage.getItem('rem');
  var arry = sessionStorage.getItem('arry');
  var arr = sessionStorage.getItem('arr');
  var qr = sessionStorage.getItem('qr');
  var arry2 = JSON.parse(arry);
  var pg = sessionStorage.getItem('pg');
// console.log(pg);
  // var arr = JSON.parse(arr);
  // arry.numeral = arr.numeral;
  // arry2['qAnsw'] = JSON.parse(qAnsw);
  // console.log('status');
  // console.log(arr);


arry2.qAnsw.rightAndWrong = JSON.parse(sessionStorage.getItem(pg));
  // console.log(pg);
  // console.log(JSON.parse(sessionStorage.getItem(pg)));

  console.log('below');
  console.log(pg);
  let result = runOne(arry2, rem);
  // sessionStorage.setItem(pg, JSON.stringify(result.qAnsw));
  // console.log(result);console.log('here');
  // console.log(result.qAnsw);
let arry3 = JSON.stringify(arry2);


}());
