


  function h4 (text) {
    var elemented = "<h4>" + text + "</h4>";
    return elemented;
  }
  function paragraph(text) {
    var para = "<p>"+text+"</p>";
    para.textContent = text;
    return para;
  }
  function paragraphs(text) {
  var paragraphs = text.split(/\r\r|\r\n/);

  var htmlParagraphs = [];

  paragraphs.forEach(function(paragraphText) {
    paragraphText = paragraphText.trim();

    var htmlParagraph = "<p>" + paragraphText + "</p>";

    htmlParagraphs.push(htmlParagraph);
  });

  var htmlOutput = htmlParagraphs.join("");


    return htmlOutput;
  }




function runTwo (arry, posted, color, width, colorOfText, borderColour) {

console.log(arry);
    var qr = arry['qr'];

var replyDiv = document.getElementById('reply');
var qn = {}
for (var i = 0 ; i < arry.qLength; i++ ) {

    for (var c = 1 ; c < 9 ; c++ ) {
       if (posted[i+'a'+c] === 'on') {
           qn = i;
    }
}
for (var c = 1 ; c < 9 ; c++ ) {


        if (posted[i+'a'+c] == 'on') {
var text1 = arry['a' + i][0][arry['numeral'][i]]['question'];
var text2 = arry['a' + i][0][arry['numeral'][i]]['answ' + c];
var text3 = arry['a' + i][0][arry['numeral'][i]]['hint' + c];
var text4 = arry['a' + i][0][arry['numeral'][i]]['pa' + c];
var breakLine = '<br><br>';

replyDiv.innerHTML += breakLine;

var finalText = '<div class="qanswer2" >' +
'Question: <br>' + paragraphs(text1) + "Answer given:<br>" + paragraphs(text4) + "Reply: <br>" + paragraphs(text2);



if (arry['a' + i][0][arry['numeral'][i]]['hint' + c] != 'empty') {

    finalText += "Hint given: <br>" + paragraphs(text3) + '</div>';

            } else {
                finalText += '</div>';

            }

    replyDiv.innerHTML += finalText;

    if (arry['a' + qn][0][arry['numeral'][i]]['correct'] === 'answ'+ c && posted[i+'a'+c] === 'on' ) {
      qr['a' + qn]++;
      console.log('hereo');

      arry['qAnsw']['rightAndWrong']['a'+i]['right']++;
    } else {
      arry['qAnsw']['rightAndWrong']['a'+i]['wrong']++;
      }
    }
  }
}



arry['qAnsw'];
arry['qr'] = qr;
return arry;
}


(function(){
let runOrNot = 0;
let rem = sessionStorage.getItem('rem');
let place = sessionStorage.getItem('arry');
let pg = sessionStorage.getItem('pg')
let qAnsw = JSON.parse(sessionStorage.getItem(pg));
console.log(place);
  let arry = JSON.parse(place);

arry.qAnsw.rightAndWrong = qAnsw;
  console.log(arry);
  arry = runTwo(arry, posted, style);
  let qr = arry['qr'];
  console.log('arry')
console.log(arry);
  sessionStorage.setItem('arry', JSON.stringify(arry));
  sessionStorage.setItem(pg, JSON.stringify(arry.qAnsw.rightAndWrong));
  console.log(pg);console.log('here');
  console.log(arry.qAnsw);
  // if (fast != 'undefined') {
  //   saveToIndexedDB(storeName, {id: arry}, key, databaseName);
  //   }



}());
