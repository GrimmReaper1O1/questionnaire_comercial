<?php
include '../includes/header4.php';
if ($_SESSION['administrator']['admin'] == 1) {
$error = '';
$error2 = '';
$message = '';

if (isset($_GET['delete'])) {

	if ($_GET['delete'] != 'none') {
	$result = $cms->getQuestions()->deleteApendix($_GET['delete']);
	if ($result < 0) {
		$error .= 'The deletion was successfull!<br>';
	} else {
		$error .= 'The deletion was not successfull.<br>';
	}

}

}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

$moved = false;


		try {
    $upload_path = '../uploads/';
    $max_size = 2500000;
    $allowed_types = ['image/jpeg', 'image/gif', 'image/png',];
    $allowed_exts = ['jpg', 'jpeg', 'png',];

      $error2 = ($_FILES['file']['size'] <= $max_size) ? '' : 'Your file is too large. It must be under 2MB';
      $type = mime_content_type($_FILES['file']['tmp_name']);
      $error2 .= in_array($type, $allowed_types) ? '' : 'Your file is of the wrong type. It must be a pdf, doc, docx, odt, txt, or rtf.';
      $ext = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
       $error2 .= in_array($ext, $allowed_exts) ? '' : 'It must have the right file extension.';

       if ($error2 === '') {
        $filename = create_filename($_FILES['file']['name'], $upload_path);
        $destination = $upload_path . $filename;
        $moved = move_uploaded_file($_FILES['file']['tmp_name'], $destination);


       }

} catch (Error $e) {
    $error .= "You didn't select a file.";
}
       if ($moved === true) {


  try {

$floatNum = floatval($_POST['floatNum']);

	    $cms->getQuestions()->insertApendix($filename, $_POST['alt'], $_SESSION['id'], $floatNum);
		$message .= "Your document updated successfully! ";




  	} catch(Exception $e) {
        $error2 .= "We're sorry! There was a problem. Please try again.";
   }

   }

}
$apendixArray = $cms->getQuestions()->selectImages();
$counter = 0;
foreach ($apendixArray as $apendix) {
	$apendixFloatNum[$counter] = $apendix['float_num'];

	$counter++;
}

?>


<script>
var floatNum = <?= JSON_encode($apendixFloatNum) ?>;

</script>

<?php
?>
<div class="heightHeader"></div>
<div id="main" class="main mainbody">
	<div style="text-align: right !important;">
		<div class="inline width20">
		<br><br>
		<span><a href="introductionToSubject.php?id=<?= $_SESSION['subject'] ?>">BACK TO INTRODUCTION!</a></span>
		<br><br>
	</div>
</div>
<div class="width80 marginAuto">
<div  class="floatLeft width50">
<br>
<br>
<br>
<?php

 echo $message . $error2 . $error; ?>
<form id='apendix' action="uploadApendix.php" method="POST" enctype="multipart/form-data">
  <div class="width50 inline"><label>Description of apendix:</label></div><div class="inline width50"><input type="text" name="alt" /><br></div><br>
  <div class="width50 inline"><label>Position via floating point number:</label></div><div class="inline width50"><input type="text" name="floatNum" /><br></div><br>
  <div class="width100 centeredText"><label>Apendix file choice:</label></div><br>
	<div class="centeredText"><input style="display: inline-block;" type="file" name="file" /></div>
<button form="apendix" type="submit">Submit!</button>
</form>

</div>
<div class="floatLeft width30">
<div class="mainFlex">
<?php
if ($apendixArray != false) {
$i = 0;
foreach ($apendixArray as $apendix){
?>
<div class="apendixTwo centeredText">
<figure>
 <img id="<?= $i ?>"  class="apendix" src="../uploads/<?= $apendix['file_name'] ?? '' ?>" alt="<?= $apendix['alt_text'] ?? '' ?>" width="30%" />
<figcaption>Apendix <?= $apendix['float_num'] ?? 'Not listed.' ?> </figcaption>
</figure>
<br>
<span>
<a href="uploadApendix.php?delete=<?= $apendix['id'] ?? 'none' ?>">DELETE APENDIX</a>
</span>
	<br>
</div>
	<?php
	$i++;
	}
}
 ?>


</div>
</div>

</div>



<div class="addHeight">
</div>
<div id="imageDiv">
	<div id="img" ><div id="placement" class="centeredText"></div></div>
	<div id="buttons centeredText marginAuto"></div>
	<div class="inline width100">
	<div id="one"><button id="left">Left</button></div><div id="cDiv"></div><div id="two"><button id="right">Right</button></div>
</div>
</div>
</div>
<?php
include '../includes/footer4.php'; ?>
<script src="../script/showImage.js"></script>
</body>
</html>





<?php
} else {
  header('Location: ../classes.php');
}
