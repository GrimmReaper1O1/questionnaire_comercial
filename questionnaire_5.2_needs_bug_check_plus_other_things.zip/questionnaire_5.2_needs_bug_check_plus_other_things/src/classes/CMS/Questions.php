<?php
namespace MySite\CMS;                                   // Declare namespace

class Questions
{
protected $db;
public function __construct(Database $db)
{
    $this->db = $db;
}

// Do this below preg replace to ensure people cant add strings $subjectId * 1; will throw error instead of allowing intrusion.

	public function updateClassName($id, $name){
		$arguments['id'] = $id;
		$arguments['name'] = $name;
		$sql = "update classes set class_name = :name where class_id like :id";
		return $this->db->runSql($sql, $arguments)->rowCount();
	}
	public function updateClassMakeLive($id) {
		$arguments['id'] = $id;
		$sql = "update classes set live = 1 where class_id like :id";
		return $this->db->runSql($sql, $arguments)->rowCount();
	}
	public function updateClassNotLive($id) {
		$arguments['id'] = $id;
		$sql = "update classes set live = 0 where class_id like :id";
		return $this->db->runSql($sql, $arguments)->rowCount();
	}
	public function updateSubjectMakeLive($id) {
		$arguments['id'] = $id;
		$sql = "update tables set live = 1, version = version + 1 where id like :id";
		return $this->db->runSql($sql, $arguments)->rowCount();
	}
	public function updateSubjectNotLive($id) {
		$arguments['id'] = $id;
		$sql = "update tables set live = 0 where id like :id";
		return $this->db->runSql($sql, $arguments)->rowCount();
	}
	
	
	public function selectAllClasses($page, $limit) {
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$limit = strval($limit);
		
		
		
		$sql = "select count(*) as count from (select * from classes";
		$sql .= ") t";
		$results[0] = $this->db->runSql($sql)->fetch();
		$offset = ($page - 1) * $limit;
		$limit = $limit * 1;
		
		
		$limit = preg_replace($patterns, $replacements, $limit);
		$sql = "select * from (select c.live, c.class_name, c.description_of_class, c.user_id, c.class_id, ";
		$sql .= "concat(u.first_name, ', ', u.last_name) as author from classes c left outer join ";
		$sql .= "users u on c.user_id = u.user_id) t order by class_name offset " . $offset;
		$sql .= " rows fetch next " . $limit . " rows only";
		$results[1] = $this->db->runSql($sql)->fetchAll();
		return $results;
	}
		public function selectAllClassesLive($page, $limit) {
			$patterns[0] = '/;/';
			$patterns[1] = '/go/';
			$replacements[0] = '';
			$replacements[1] = '';
			$limit = strval($limit);
		
		
		
		$sql = "select count(*) as count from (select * from classes where live like 1";
		$sql .= ") t";
		$results[0] = $this->db->runSql($sql)->fetch();
		$offset = ($page - 1) * $limit;
		
		
		
		$limit = preg_replace($patterns, $replacements, $limit);
		$sql = "select * from (select c.live, c.class_name, c.description_of_class, c.user_id, c.class_id, ";
		$sql .= "concat(u.first_name, ', ', u.last_name) as author from classes c left outer join ";
		$sql .= "users u on c.user_id = u.user_id where live like 1) t order by class_name offset " . $offset;
		$sql .= " rows fetch next " . $limit . " rows only";
		$results[1] = $this->db->runSql($sql)->fetchAll();
		return $results;
	}
	public function selectAllClassesViaLetter($page, $limit, $letter) {
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$limit = strval($limit);
		$letter = preg_replace($patterns, $replacements, $letter);	
		
		
		$sql = "select count(*) as count from (select * from classes where left(class_name, 1) like '" . $letter . "' ";
		$sql .=  ") t";
		$results[0] = $this->db->runSql($sql)->fetch();
		$offset = ($page - 1) * $limit;
		
		
		
		$limit = preg_replace($patterns, $replacements, $limit);
		$sql = "select c.live, c.class_name, c.description_of_class, c.user_id, c.class_id, ";
		$sql .= "concat(u.first_name, ', ', u.last_name) as author from Classes c left outer join ";
		$sql .= "users u on c.user_id = u.user_id where left(c.class_name, 1) like '" . $letter . "' ";
		$sql .= "order by c.class_name offset " . $offset;
		$sql .= " rows fetch next " . $limit . " rows only";
		$results[1] = $this->db->runSql($sql)->fetchAll();
		return $results;
	}
	public function selectAllClassesViaLetterLive($page, $limit, $letter) {
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$limit = strval($limit);
		$letter = preg_replace($patterns, $replacements, $letter);	
		
		
		$sql = "select count(*) as count from (select * from classes where left(class_name, 1) like '" . $letter . "' ";
		$sql .=  "and live like 1) t";
		$results[0] = $this->db->runSql($sql)->fetch();
		$offset = ($page - 1) * $limit;
		
		
		
		$limit = preg_replace($patterns, $replacements, $limit);
		$sql = "select c.live, c.class_name, c.description_of_class, c.user_id, c.class_id, ";
		$sql .= "concat(u.first_name, ', ', u.last_name) as author from Classes c left outer join ";
		$sql .= "users u on c.user_id = u.user_id where live like 1 and left(c.class_name, 1) like '" . $letter . "' ";
		$sql .= "order by c.class_name offset " . $offset;
		$sql .= " rows fetch next " . $limit . " rows only";
		$results[1] = $this->db->runSql($sql)->fetchAll();
		return $results;
	}
	public function deleteQuestion($id) {
		$arguments['id'] = $id;
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		
		$subjectId = $subjectId * 1;

		$subjectId = preg_replace($patterns, $replacements, $_SESSION['subject']);
		$sql = "delete from question_information" . $subjectId . " where id like :id";
		return $this->db->runSql($sql, $arguments)->rowCount();			
	}
	
	public function updateClassDescription($classId, $description) {
		$arguments['classId'] = $classId;
		$arguments['description'] = $description;
		$sql = "update classes set description_of_class = :description where class_id like :classId";
		return $this->db->runSql($sql, $arguments)->rowCount();
		
	}
	
	
	
	public function deleteFromSubjectsTableViaClassId($classId) {

		$arguments['classId'] = $classId;
		$sql = "delete from tables where class_id like :classId";
		return $this->db->runSql($sql, $arguments)->rowCount();
	
	}
	public function deleteFromQuestionDescriptionViaClassId($classId) {
		$arguments['classId'] = $classId;
		
		$sql = "delete from question_ids where class_id like :classId";
		$result = $this->db->runSql($sql, $arguments)->rowCount();
	}
	public function deleteFromQuestionInformationViaClassIdAndSubject($subject, $classId) {
			$arguments['classId'] = $classId;
			$patterns[0] = '/;/';
			$patterns[1] = '/go/';
			$replacements[0] = '';
			$replacements[1] = '';
			$subject = preg_replace($patterns, $replacements, $subject);
		
			$sql = "delete from question_information" . $subject . " where class_id like :classId";
			return $this->db->runSql($sql, $arguments)->rowCount();
		}
	public function deleteFromUsersOfClassesViaClassId($classId) {
			$arguments['classId'] = $classId;
			$sql = "delete from attached_users_to_classes where class_id like :classId";
			return $this->db->runSql($sql, $arguments)->rowCount();
	}
	public function selectAllFromLibraryViaClassId($classId) {
			$arguments['classId'] = $classId;
			$sql = "select * from library where class_id like :classId";
			return $this->db->runSql($sql, $arguments)->fetchAll();
			
		}
		public function deleteFromLibraryViaClassId($classId) {
			$arguments['classId'] = $classId;
			$sql = "delete from library where class_id like :classId";
			return $this->db->runSql($sql, $arguments)->rowCount();
			
		}
	public function deleteFromTermsViaClassId($classId) {
		$arguments['classId'] = $classId;
		$sql = "delete from terms where class_id like :classId";
		return $this->db->runSql($sql, $arguments)->rowCount();
	}
	public function deleteFromClassesViaClassId($classId) {
		$arguments['classId'] = $classId;		
		$sql = "delete from classes where class_id like :classId";
		return $this->db->runSql($sql, $arguments)->rowCount();
	
	}
	public function updateSubjectNameAndNumberOfQuestions($id, $name, $number) {
		$arguments['id'] = $id;
		$arguments['name'] = $name;
		$arguments['number'] = $number;
		$sql = "update tables set subject_information = :name, number_of_questions = :number where id like :id";
		return $this->db->runSql($sql, $arguments)->rowCount();
	}
	
	public function selectAllFromSubjectsAdmin($classId) {
		$arguments['classId'] = $classId;
		$sql = "select * from (select  t.id, t.live, t.table_id, t.subject_information, t.number_of_questions, t.class_id, c.class_name, c.description_of_class ";
		$sql .= " from tables t inner join classes c on t.class_id = c.class_id where t.class_id like :classId ) t ";
		$sql .= "";
		return $this->db->runSql($sql, $arguments)->fetchAll();
	}
	public function selectAllFromSubjects($classId) {
		$arguments['classId'] = $classId;
		$sql = "select * from (select t.live, t.id, t.table_id, t.subject_information, t.number_of_questions, t.class_id, c.class_name, c.description_of_class ";
		$sql .= " from tables t inner join classes c on t.class_id = c.class_id where t.class_id like :classId ) t ";
		$sql .= "order by subject_information";
		return $this->db->runSql($sql, $arguments)->fetchAll();
	}
	public function selectAllFromSubjectsLive($classId) {
		$arguments['classId'] = $classId;
		$sql = "select * from (select t.live, t.id, t.table_id, t.subject_information, t.number_of_removal, t.class_id, c.class_name, c.description_of_class ";
		$sql .= " from tables t inner join classes c on t.class_id = c.class_id where t.class_id like :classId and t.live like 1) t ";
		$sql .= "order by subject_information";
		return $this->db->runSql($sql, $arguments)->fetchAll();
	}
	public function selectSubjectViaTableId($tableId) {
		$arguments['tableId'] = $tableId;
		$sql = "select * from tables where table_id like :tableId";
		return $this->db->runSql($sql, $arguments)->fetch();
	}
	public function selectSubjectViaSubjectId($sId) {
		$arguments['sId'] = $sId;
		$sql = "select * from tables where id like :sId";
		return $this->db->runSql($sql, $arguments)->fetch();
	}
	public function selectSubjectViaTableIdAndClassId() {
		$arguments['tableId'] = $_SESSION['subject'];
		$arguments['class'] = $_SESSION['class'];
		$sql = "select * from tables where table_id like :tableId and class_id like :class";
		return $this->db->runSql($sql, $arguments)->fetch();
	}
	public function selectSubjectViaTableIdNSAndClassId($subjectId) {
		$arguments['tableId'] = $subjectId;
		$arguments['class'] = $_SESSION['class'];
		$sql = "select * from tables where table_id like :tableId and class_id like :class";
		return $this->db->runSql($sql, $arguments)->fetch();
	}
	public function selectMaxNumberFromSubject() {
		$arguments['class'] = $_SESSION['class'];
		$arguments['subject'] = $_SESSION['subject'];
		$sql = "select max(question_number) as max from question_ids ";
		$sql .= "where table_id like :subject and class_id like :class";
		return $this->db->runSql($sql, $arguments)->fetch();
		
	}
	public function updateSubjectRemoveQuestion($removeNumber){
		$arguments['subject'] = $_SESSION['subject'];
		$arguments['class'] = $_SESSION['class'];
		$arguments['removeNumber'] = $removeNumber;
		$sql = "update tables set number_of_removal = :removeNumber where ";
		$sql .= "class_id like :class and table_id like :subject";
		return $this->db->runSql($sql, $arguments)->rowCount();
	}
	public function selectSubjectViaSubjectName($name) {
		$arguments['name'] = $name;
		$sql = "select * from tables where subject_information like :name";
		return $this->db->runSql($sql, $arguments)->fetch();	
	}
	public function updateSubjects($subject, $id) {
		
		$arguments['entry'] = $subject;
		$arguments['id'] = $_SESSION['subject'];
		$arguments['class'] = $_SESSION['class'];
		$sql = "update tables set subject_information = :entry ";
		$sql .= "where table_id like :id and class_id like :class";
		return $this->db->runSql($sql, $arguments)->rowCount();
	}
	public function updateSubjectsInitial($subject, $numeralOfRemoval, $numberOfQuestions,
		$l1, $l2, $l3, $l4, $l5, $l6, $l7, $l8, 
		$l9, $l10, $d1, $d2, $d3, $d4, 
		$d5, $d6, $d7, $d8, $d9, $d10, 
		$sD) {
		$arguments['sD'] = $sD;
		$arguments['l1'] = $l1;
		$arguments['d1'] = $d1;
		$arguments['l2'] = $l2;
		$arguments['d2'] = $d2;
		$arguments['l3'] = $l3;
		$arguments['d3'] = $d3;
		$arguments['l4'] = $l4;
		$arguments['d4'] = $d4;
		$arguments['l5'] = $l5;
		$arguments['d5'] = $d5;
		$arguments['l6'] = $l6;
		$arguments['d6'] = $d6;
		$arguments['l7'] = $l7;
		$arguments['d7'] = $d7;
		$arguments['l8'] = $l8;
		$arguments['d8'] = $d8;
		$arguments['l9'] = $l9;
		$arguments['d9'] = $d9;
		$arguments['l10'] = $l10;
		$arguments['d10'] = $d10;
		$arguments['entry'] = $subject;
		$arguments['id'] = $_SESSION['subject'];
		$arguments['num'] = $numberOfQuestions;
		$arguments['class'] = $_SESSION['class'];
		$arguments['numeralOfRemoval'] = $numeralOfRemoval;
		$sql = "update tables set version = 1, subject_information = :entry, number_of_removal = :numeralOfRemoval, number_of_questions = :num,";
		$sql .= "link1 = :l1, link_description1 = :d1, link2 = :l2, link_description2 = :d2, ";
		$sql .= "link3 = :l3, link_description3 = :d3, link4 = :l4, link_description4 = :d4, ";
		$sql .= "link5 = :l5, link_description5 = :d5, link6 = :l6, link_description6 = :d6, ";
		$sql .= "link7 = :l7, link_description7 = :d7, link8 = :l8, link_description8 = :d8, ";
		$sql .= "link9 = :l9, link_description9 = :d9, link10 = :l10, link_description10 = :d10, ";
		$sql .= "introduction = :sD ";
		$sql .= "where table_id like :id and class_id like :class";
		return $this->db->runSql($sql, $arguments)->rowCount();
	}
	public function selectQuestionViaDescription($description) {
		$arguments['description'] = $description;
		$arguments['id'] = $_SESSION['subject'];
		$sql = "select * from question_ids where table_id like :id and description like :description";
		return $this->db->runSql($sql, $arguments)->fetch();
	}
	public function insertQuestionDescription($description, $questionPositionNumber){
		$arguments['id'] = $_SESSION['subject'];
		$arguments['description'] = $description;
		$arguments['position'] = $questionPositionNumber;
		$arguments['class'] = $_SESSION['class'];
		$sql = "insert into question_ids (table_id, description, question_number, class_id) ";
		$sql .= "values (:id, :description, :position, :class)";
		return $this->db->runSql($sql, $arguments);
	}
	public function selectQuestions($id, $page, $limit) {
		$arguments['id'] = $id;
		$arguments['class'] = $_SESSION['class'];
		$sql = "select count(*) as count from (select q.question_id, q.table_id, q.description, ";
		$sql .= "t.live from question_ids q "; 
		$sql .= "left join tables t on q.table_id = t.table_id ";
		$sql .= "where q.table_id like :id and q.class_id like :class) a";
		$results[0] = $this->db->runSql($sql, $arguments)->fetch();
		$offset = ($page - 1) * $limit;
		$limit = strval($limit);
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$limit = preg_replace($patterns, $replacements, $limit);
		$sql = "select * from (select q.question_id, q.table_id, q.description, ";
		$sql .= "t.live, q.question_number from question_ids q "; 
		$sql .= "inner join tables t on q.table_id = t.table_id and q.class_id = t.class_id ";
		$sql .= "where t.table_id = :id and q.class_id = :class) c  order by question_number ";
		$sql .= "offset " . $offset . " rows fetch next " . $limit . " rows only";
		$results[1] = $this->db->runSql($sql, $arguments)->fetchAll();
		return $results;
	}
	
	public function insertQuestion($question, $pa1, $pa2, $pa3, $pa4, $pa5, $pa6, $pa7, $pa8,
	$answ1, $answ2, $answ3, $answ4, $answ5, $answ6, $answ7, $answ8, $correctAnsw, $questionId,
	$hint1, $hint2, $hint3, $hint4, $hint5, $hint6, $hint7, $hint8) {
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$tableNumber = $_SESSION['subject'];
		$tableNumber = $tableNumber * 1;
		$tableNumber = preg_replace($patterns, $replacements, $tableNumber);
		$arguments['question'] = $question;
		$arguments['pa1'] = $pa1;
		$arguments['pa2'] = $pa2;
		$arguments['pa3'] = $pa3;
		$arguments['pa4'] = $pa4;
		$arguments['pa5'] = $pa5;
		$arguments['pa6'] = $pa6;
		$arguments['pa7'] = $pa7;
		$arguments['pa8'] = $pa8;
		$arguments['answ1'] = $answ1;
		$arguments['answ2'] = $answ2;
		$arguments['answ3'] = $answ3;
		$arguments['answ4'] = $answ4;
		$arguments['answ5'] = $answ5;
		$arguments['answ6'] = $answ6;
		$arguments['answ7'] = $answ7;
		$arguments['answ8'] = $answ8;
		$arguments['correct'] = $correctAnsw;
		$arguments['questionId'] = $questionId;
		$arguments['hint1'] = $hint1;
		$arguments['hint2'] = $hint2;
		$arguments['hint3'] = $hint3;
		$arguments['hint4'] = $hint4;
		$arguments['hint5'] = $hint5;
		$arguments['hint6'] = $hint6;
		$arguments['hint7'] = $hint7;
		$arguments['hint8'] = $hint8;
		$arguments['class'] = $_SESSION['class'];
		$sql = "insert into question_information$tableNumber  (class_id, question, pa1, pa2, pa3, pa4, pa5, pa6, pa7, pa8, ";
		$sql .= "answ1, answ2, answ3, answ4, answ5, answ6, answ7, answ8, correct, question_id, hint1, hint2, hint3, ";
		$sql .= " hint4, hint5, hint6, hint7, hint8) values ";
		$sql .= "(:class, :question, :pa1, :pa2, :pa3, :pa4, :pa5, :pa6, :pa7, :pa8, :answ1, :answ2, :answ3, :answ4, :answ5, ";
		$sql .= ":answ6, :answ7, :answ8, :correct, :questionId, :hint1, :hint2, :hint3, :hint4, :hint5, :hint6, :hint7, :hint8)";
		return $this->db->runSql($sql, $arguments);
	}
	public function updateQuestion($id, $question, $pa1, $pa2, $pa3, $pa4, $pa5, $pa6, $pa7, $pa8,
	$answ1, $answ2, $answ3, $answ4, $answ5, $answ6, $answ7, $answ8, $correctAnsw, $questionId,
	$hint1, $hint2, $hint3, $hint4, $hint5, $hint6, $hint7, $hint8) {
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$tableNumber = preg_replace($patterns, $replacements, $_SESSION['subject']);
		$arguments['question'] = $question;
		$arguments['id'] = $id;
		$arguments['pa1'] = $pa1;
		$arguments['pa2'] = $pa2;
		$arguments['pa3'] = $pa3;
		$arguments['pa4'] = $pa4;
		$arguments['pa5'] = $pa5;
		$arguments['pa6'] = $pa6;
		$arguments['pa7'] = $pa7;
		$arguments['pa8'] = $pa8;
		$arguments['answ1'] = $answ1;
		$arguments['answ2'] = $answ2;
		$arguments['answ3'] = $answ3;
		$arguments['answ4'] = $answ4;
		$arguments['answ5'] = $answ5;
		$arguments['answ6'] = $answ6;
		$arguments['answ7'] = $answ7;
		$arguments['answ8'] = $answ8;
		$arguments['correct'] = $correctAnsw;
		$arguments['questionId'] = $questionId;
		$arguments['hint1'] = $hint1;
		$arguments['hint2'] = $hint2;
		$arguments['hint3'] = $hint3;
		$arguments['hint4'] = $hint4;
		$arguments['hint5'] = $hint5;
		$arguments['hint6'] = $hint6;
		$arguments['hint7'] = $hint7;
		$arguments['hint8'] = $hint8;
		$sql = "update question_information" . $tableNumber . " set question = :question, pa1 = :pa1, pa2 = :pa2, pa3 = :pa3, ";
		$sql .= "pa4 = :pa4, pa5 = :pa5, pa6 = :pa6, pa7 = :pa7, pa8 = :pa8, answ1 = :answ1, answ2 = :answ2, answ3 = :answ3, ";
		$sql .= "answ4 = :answ4, answ5 = :answ5, answ6 = :answ6, answ7 = :answ7, answ8 = :answ8, correct = :correct, ";
		$sql .= "question_id = :questionId, hint1 = :hint1, hint2 = :hint2, hint3 = :hint3, hint4 = :hint4, hint5 = :hint5, ";
		$sql .= "hint6 = :hint6, hint7 = :hint7, hint8 = :hint8 where id like :id";
		return $this->db->runSql($sql, $arguments)->rowCount();
	}
	
	public function countNumberOfQuestions($questionNumber) {
		$arguments['questionId'] = $questionNumber;
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$_SESSION['subject'] = preg_replace($patterns, $replacements, $_SESSION['subject']);
		$sql = "select count(*) as count from question_information" . $_SESSION['subject'];
		$sql .= " where question_id like :questionId";
		return $this->db->runSql($sql, $arguments)->fetch();
		
	}
	
	public function countQuestionIds() {
		$arguments['classId'] = $_SESSION['class'];
		$arguments['tableId'] = $_SESSION['subject'];
		$sql = "select count(*) as count from question_ids where class_Id like :classId";
		$sql .= " and table_id like :tableId";
		return $this->db->runSql($sql, $arguments)->fetch();
	}

	public function selectQuestionIdsPagination($page, $limit) {
		$arguments['classId'] = $_SESSION['class'];
		$arguments['tableId'] = $_SESSION['subject'];
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		
		$limit = intval($limit);
		$limit = preg_replace($patterns, $replacements, $limit);
		$limit = $limit * 1;

		$offset = ($page - 1) * $limit;
		
		$sql = "select question_id from question_ids where class_id like :classId and ";
		$sql .= "table_id like :tableId order by question_number offset ";
		$sql .= $offset . " rows fetch next " . $limit . " rows only";
		$result[1] = $this->db->runSql($sql, $arguments)->fetchAll();
		return $result;
	
}

	public function selectAllQuestionsFromSubjectPagination($page, $limit) {
		$arguments['classId'] = $_SESSION['class'];
		$arguments['tableId'] = $_SESSION['subject'];
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$limit = intval($limit);
		$limit = preg_replace($patterns, $replacements, $limit);
		$sql = "select count(*) as count from question_ids where class_Id like :classId";
		$sql .= " and table_id like :tableId order by question_number, question_id";
		$result[0] = $this->db->runSql($sql, $arguments)->fetch();
			
		$offset = ($page - 1) * $limit;
		
		$sql = "select * from question_ids where class_id like :classId and ";
		$sql .= "table_id like :tableId order by question_number offset ";
		$sql .= $offset . " rows fetch next " . $limit . " rows only";
		$result[1] = $this->db->runSql($sql, $arguments)->fetchAll();
		return $result;
		
	}
	public function selectAllQuestionsFromSubject() {
		$arguments['classId'] = $_SESSION['class'];
		$arguments['tableId'] = $_SESSION['subject'];
		$sql = "select question_id from question_ids where class_id like :classId and ";
		$sql .= "table_id like :tableId order by question_number, question_id";
		$result[1] = $this->db->runSql($sql, $arguments)->fetchAll();
		return $result;
		
	}
		public function selectAllQuestionsFromSubjectPaginationCount($page, $limit) {
		$arguments['classId'] = $_SESSION['class'];
		$arguments['tableId'] = $_SESSION['subject'];
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$limit = intval($limit);
		$limit = preg_replace($patterns, $replacements, $limit);
		$sql = "select count(*) as count from question_ids where class_Id like :classId";
		$sql .= " and table_id like :tableId";
		$result[0] = $this->db->runSql($sql, $arguments)->fetch();
			
		$offset = ($page - 1) * $limit;
		
		$sql = "select count(*) as count from (select * from question_ids where class_id like :classId and ";
		$sql .= "table_id like :tableId order by question_number offset ";
		$sql .= $offset . " rows fetch next " . $limit . " rows only) t";
		$result[1] = $this->db->runSql($sql, $arguments)->fetchAll();
		return $result;
		
	}
	public function countQuestionsFromQuestionsIdsPagination($page, $limit) {
		$arguments['classId'] = $_SESSION['class'];
		$arguments['tableId'] = $_SESSION['subject'];
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$offset = ($page - 1) * $limit;
		
		$limit = intval($limit);
		$limit = preg_replace($patterns, $replacements, $limit);
		$sql = "select count(*) as count from question_ids where class_Id like :classId ";
		$sql .= "and table_id like :tableId";
		
		return $this->db->runSql($sql, $arguments)->fetch();
			
	}	
		
		
	public function selectQuestionViaQuestionAndc($question, $questionId, $correct) {
		$arguments['question'] = $question;
		$arguments['questionId'] = $questionId;
		$arguments['correct'] = $correct;
		$arguments['class'] = $_SESSION['class'];
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$subjectId = $_SESSION['subject'] * 1;
		$subjectId = preg_replace($patterns, $replacements, $subjectId);
		$sql = "select * from question_information" . $subjectId . " where question ";
		$sql .= "like :question and question_id like :questionId and class_id like :class and correct like :correct";
		return $this->db->runSql($sql, $arguments)->fetch();
	}
	
		public function selectQuestioninformation($questionId, $page, $limit, $subjectId) {
		$arguments['questionId'] = $questionId;
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$limit = strval($limit);
		$limit = preg_replace($patterns, $replacements, $limit);
		
		$sql = "select count(*) as count from (select * from question_information" . $subjectId;
		$sql .= " where question_id like :questionId) t";
		$results[0] = $this->db->runSql($sql, $arguments)->fetch();
		$offset = ($page - 1) * $limit;
		
		
		$limit = preg_replace($patterns, $replacements, $limit);
		$sql = "select * from (select s.id, s.question, s.question_id, s.correct, q.question_number, s.pa1, s.pa2, s.pa3, s.pa4, s.pa5, s.pa6, s.pa7, s.pa8, ";
		$sql .= "s.answ1, s.answ2, s.answ3, s.answ4, s.answ5, s.answ6, s.answ7, s.answ8, ";
		$sql .= "s.hint1, s.hint2, s.hint3, s.hint4, s.hint5, s.hint6, s.hint7, s.hint8, q.description from question_information" . $subjectId;
		$sql .= " s left outer join question_ids q on s.question_id = q.question_id ";
		$sql .= "where q.question_id like :questionId) t order by question_number ";
		$sql .= "offset " . $offset . " rows fetch next " . $limit . " rows only";
		$results[1] = $this->db->runSql($sql, $arguments)->fetchAll();
		return $results;
	}
	public function updateSubjectsTable($id) {
		$arguments['id'] = $id;
		$sql = "update tables set subject_information = 'empty', number_of_questions = null where table_id like :id";
		return $this->db->runSql($sql, $arguments)->rowCount();
	}
	public function deleteQuestionIds($id) {
		$arguments['id'] = $id;
		$sql = "delete from question_ids where table_id like :id";
		return $this->db->runSql($sql, $arguments)->rowCount();
	}
	public function deleteExactQuestionIds($id) {
		$arguments['id'] = $id;
		$sql = "delete from question_ids where question_id like :id";
		return $this->db->runSql($sql, $arguments)->rowCount();
	}
	public function selectToCheckQuestionNumberViaSubjectClassAndPossition($possition, $description) {
		$arguments['possition'] = $possition;
		$arguments['subject'] = $_SESSION['subject'];
		$arguments['class'] = $_SESSION['class'];
		$arguments['description'] = $description;
		$sql = "select * from question_ids where (class_id like :class and table_id like :subject) and ";
		$sql .= "(question_number like :possition or description like :description)";
		return $this->db->runSql($sql, $arguments)->fetchAll();
	}
		public function deleteAllEntriesFromQuesitonInformation($subjectId) {
		
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$subjectId = preg_replace($patterns, $replacements, $subjectId);
		$sql = "delete from question_information" . $subjectId;
		return $this->db->runSql($sql, $arguments)->rowCount();
}
	public function deleteAllEntriesFromAQuesitonInformation($subjectId, $questionId) {
		$arguments['id'] = $questionId;
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$subjectId = preg_replace($patterns, $replacements, $subjectId);
		$sql = "delete from question_information" . $subjectId . " where question_id like :id";
		return $this->db->runSql($sql, $arguments)->rowCount();
}
	public function selectQuestionViaQuestionId($id) {
		$arguments['id'] = $id;
		$arguments['class'] = $_SESSION['class'];
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		
		$subjectId = preg_replace($patterns, $replacements, $_SESSION['subject']);
		$sql = "select * from question_information" . $subjectId . " where id like :id and class_id like :class";
		return $this->db->runSql($sql, $arguments)->fetch();
	}
	
	
	public function selectQuestionDescriptionViaQuestionId($id) {
		$arguments['questionId'] = $id;
		$arguments['class'] = $_SESSION['class'];
		
	
		$sql = "select question_number, class_id, description, table_id, question_id from question_ids";
		$sql .= " where question_id like :questionId and class_id like :class";
		return $this->db->runSql($sql, $arguments)->fetch();
	}
	
	
	public function selectQuestionIdViaQuestionId($questionId) {
		
		$arguments['class'] = $_SESSION['class'];
		$arguments['questionId'] = $questionId;
		$arguments['subject'] = $_SESSION['subject'];
	
		$sql = "select question_number, class_id, description, table_id, question_id from question_ids";
		$sql .= " where question_id like :questionId and table_id like :subject and class_id like :class";
		return $this->db->runSql($sql, $arguments)->fetch();
	}
	public function updateQuestionDescriptionPossition($questionId, $possition) {
		$arguments['questionId'] = $questionId;
		$arguments['possition'] = $possition;
		$sql = "update question_ids set question_number = :possition where question_id like :questionId";
		return $this->db->runSql($sql, $arguments)->rowCount();
	}
	public function updateQuestionName(int $id, string $name) {
		$arguments['id'] = $id;
		$arguments['name'] = $name;
		$sql = "update question_ids set description = :name where question_id like :id";
		return $this->db->runSql($sql, $arguments)->rowCount();
		
	}


	public function countQuestionIdsViaSubjectAndClass() {
	$arguments['class'] = $_SESSION['class'];
	$arguments['tableId'] = $_SESSION['subject'];
	$sql = "select count(*) as count from question_ids where table_id like :tableId and ";
	$sql .= "class_id like :class";
	return $this->db->runSql($sql, $arguments)->fetch();
			
	}
	

	public function selectAllQuestionInformationIncludingId() {
	
	$arguments['classId'] = $_SESSION['class'];
	$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		
		$subjectId = preg_replace($patterns, $replacements, $_SESSION['subject']);

	$sql = "select q.class_id, q.question_id, q.id, i.question_number from question_information" . $subjectId . " q ";
	$sql .= "LEFT OUTER JOIN question_ids i on q.question_id = i.question_id ";
	$sql .= "where q.class_id like :classId order by i.question_number, q.question_id"; 
	
	return $this->db->runsql($sql, $arguments)->fetchAll();
	}	
	
	//may not work unless you have all question Ids
	
		public function sortArrayViaQuestionIdsArray($pagesIds, $questionInformationArray) {
			

	
		
			$counter1 = count($pagesIds);
			$counter1 = $counter1 - 1;
			$counter2 = count($questionInformationArray);
			$counter2 = $counter2 - 1;
			$counter3 = 0;
			for ($i = 0 ; $i <= $counter1 ; $i++) {
				$id['a' . $i] = $pagesIds[$i]['question_id'];
			}
				
				$counter10 = 0;
				for($b = 0 ; $b <= $counter1 ; $b++) {
					$counter3 = 0;
					$set = 0;
					for($d = 0 ; $d <= $counter2 ; $d++) {
			
						if ($questionInformationArray[$d]['question_id'] == $pagesIds[$b]['question_id']) {
							$arr2["a" . $counter10][$counter3]['question_id'] = $questionInformationArray[$d]['question_id'];
							$arr2['a' . $counter10][$counter3]['ident'] = $questionInformationArray[$d]['id'];
							$counter3++;
							$set = 1;

					}
				}
				if ($set == 1) {
				$counter10++;

				}
				
			}
	if (isset($arr2)) {
			return $arr2;
	} else {
		$arr2['a' . 0] = 'empty';
		return $arr2;
	}
		}
		
		
		
	
		

				public function sortArrayViaQuestionInformationAllAtOncePagination($pagesIds, $numberOfQuestionsOnPage, $page) {
	

	
		$counted2 = count($pagesIds[0]);
		$counter = 0;
		$notWorking = (($page - 1) * $numberOfQuestionsOnPage) ;
		
		$remainder = (($notWorking + $numberOfQuestionsOnPage) - 1);
		$remainder++;
	
	$counter2 = 0;
	$counter3 = 0;

	$counter3++;
	for ($c = $notWorking ; $c < $remainder ; $c++ ) {
		
	if (isset($pagesIds[$c])) {
		if ($pagesIds[$c]) {
	$arr2[$counter2] = $pagesIds[$c];
$counter2++;	
}
	}	
	
//	}
	
	
	}
			return $arr2;
		}
			
		
			
	public function selectQuestionAllAtOnce(array $pagesIds,  $countedNumberOfQuestionsPerQuestion) {
		
		$go = 0;
				
		unset($_SESSION['test']);
		$loopNumber = $_SESSION['loopNumber'];
		
	
		if (!isset($_SESSION['runs'])) {
			$_SESSION['runs'] = 0; 
			$runs = 0;
} else {
$runs = $_SESSION['runs'];

}
	 

$counted = count($countedNumberOfQuestionsPerQuestion);



			

		$counter777 = 0;
		if (!isset($_SESSION['fast'])) {
		
		for($i = 0 ; $i < $loopNumber ; $i++) {

	
	
			if (isset($_SESSION['questionLimitNumber']['a' . $i]))  
		{
			$limitNumber = $_SESSION['questionLimitNumber']['a' . $i];
			$maxQuestionLimit = $countedNumberOfQuestionsPerQuestion['a'.$i] - 1;
			} else {
				$limitNumber = 0;
				$_SESSION['questionLimitNumber'] = $limitNumber;
				$maxQuestionLimit = $countedNumberOfQuestionsPerQuestion['a'.$i] - 1;
			}
	
		


				if ($limitNumber <= $maxQuestionLimit) {
				if (!isset($_SESSION['numeral'][$i])) {
				$numeral[$i] = 0;
				$_SESSION['numeral'][$i] = 0;
				} else {
					$numeral[$i] = $_SESSION['numeral'][$i];
				}

		$offset = $numeral[$i];
		$array[$i] = $pagesIds['a' . $i][$offset]['ident'];
		
		
		}
		}
		
	
		
		
		for ($i = 0 ; $i < count($array) ; $i++ ) {
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$go = 1;
		$array2[$i] = preg_replace($patterns, $replacements, $array[$i]);
		$arguments['questionId' . $i] = $array2[$i];
		
		
		
		$runningArray[$i][$runs] = 0;
			if (!isset($array[$i])) {
				$runningArray[$i][$runs] = $counter;
				
			}
			$counter777++;
			
			
			
		
		}
		
	
		
		
		$sql = "select question, pa1, pa2, pa3, pa4, pa5, pa6, pa7, pa8, answ1, answ2, ";
		$sql .= "answ3, answ4, answ5, answ6, answ7, answ8, correct, hint1, hint2, hint3, ";
		$sql .= "hint4, hint5, hint6, hint7, hint8 from question_information" . $_SESSION['subject'];
		$sql .= " i left outer join question_ids q on i.question_id = q.question_id";
		$sql .= " where i.id like :questionId0 ";
		
		
		
	
		
		
		
		
		
		
		for($i = 1 ; $i < count($array) ; $i ++ ) {
		
		
			
			$sql .= " or i.id like :questionId" . $i . " "; 
			
		
		
		}
		$sql .= " order by q.question_number";
		
		
			if ($go === 1) {
			$info = $this->db->runSql($sql, $arguments)->fetchAll();
			}

			
			$_SESSION['sql'] = $sql;
		
		
		}
		unset($_SESSION['choiceArray']);
for ($i = 0 ; $i < $loopNumber ; $i++) {
			if (!isset($_SESSION['choiceArray'])) {
				$cA['a' . $i] = $i;
			}
}		if (isset($cA)) {
		$_SESSION['cA'] = $cA;
}


$counter10 = 0;
$counter20 = 0;
				
			if (!isset($dissable)) {

			for ($i = 0 ; $i < $loopNumber ; $i++) {
			
		
				
				
			
					if (isset($info[$i])) {
						if ($countedNumberOfQuestionsPerQuestion['a' . $i] > $runs) {
						// $giveOut['info'][$i] = $info[$i];
						$giveOut['info'][$cA['a' . $i]] = $info[$i];
						}
				}		
			
	
			}
			// for ($i = 0 ; $i < $loopNumber ; $i++ ) {
			// 	if (!isset($giveOut['info'][$i])) {
			// 		$giveOut['info'][$i] = 'empty';
			// 	}
			// }

		
		
				if (isset($_SESSION['setFirst'])) {
					$setFirst = $_SESSION['setFirst']; 
				}
			
			
$counter101 = 0;
			$counter[0] = 0;
				$counter[1] = 0;
				$counter[2] = 0;
				$counter[3] = 0;
				$counter10 = 0;
				$counter20 = 0;
			$counter777 = 0;
			$counter7772 = 0;
			for ($i = 0 ; $i < $loopNumber ; $i++ ) {
				if (!isset($_SESSION['numeral'][$i])) {
				$numeral[$i] = 0;
				} else {
					$numeral[$i] = $_SESSION['numeral'][$i];
				}
			
			if (!isset($_SESSION['setFirst'])) {
				$setFirst[$i] = 0;
			}
					
	
			
				
		
			
			$counted = $countedNumberOfQuestionsPerQuestion['a' . $i] - 1;
			// if (isset($_SESSION['info'][$i][$numeral[$i]])) {
			// 		$giveOutInfo["a" . $counter20] = $_SESSION['info'][$i][$numeral[$i]];
			// 		$counter20++;
			// 		}
			$giveOut['numeral'][$i] = $numeral[$i];
				if (isset($numeral[$i])) {
						
if ($numeral[$i] < $counted) {
					$numeral[$i] = $numeral[$i] + 1;
				} else {
					$numeral[$i] = 0;
					// enter set first here
					$setFirst[$i] = 1;
			
				}
				$_SESSION['numeral'][$i] = $numeral[$i];
			if ($setFirst == 1) {
				$counter777++;
			}		
			
	}			
				
				// count set first here
				

				if ($setFirst[$i] == 1) {
					$cA['a' . $counter101] = $i;
					$counter101++;
	
				}
				if ($counted == 0) {
					
					$counter7772++;

				}

			}
			$_SESSION['setFirst'] = $setFirst;

		if ($counter101 == count($pagesIds)) {
			$_SESSION['fast'] = 1;
			
		}
		
			$_SESSION['cA'] = $cA;
			
		
$runs++;
$_SESSION['runs'] = $runs;

$counter = 0;
		for ($i = 0 ; $i < $loopNumber ; $i++) {


if (isset($_SESSION['questionLimitNumber']['a' . $i])) {
			unset($limitNumber);
			unset($maxQuestionLimit);
			$limitNumber = $_SESSION['questionLimitNumber']['a' . $i];
			$maxQuestionLimit[$i] = $countedNumberOfQuestionsPerQuestion['a' . $i] - 1;
			
			if ($limitNumber < $maxQuestionLimit[$i]) {
			$_SESSION['questionLimitNumber']['a' . $i] = $limitNumber + 1;
			
			//if (count($_SESSION['info'][$i]) < ($maxQuestionLimit - 1)) {
			
		
		}
	} 
			$giveOut['runs'] = $runs;
			$giveOut['maxNumeral'][$i] = $countedNumberOfQuestionsPerQuestion['a' . $i];
			$giveOut['length'] = count($giveOut['maxNumeral']);
			if (isset($_SESSION['fast'])) {
				$giveOut['fast'] = 'on';
			}
			
} 


			}
		return $giveOut;
		//return $giveOutInfo;

	}


	public function selectQuestionInformationIdFromQuestionIds($questionIdArray) {

	for ($i = 0 ; $i < count($questionIdArray) ; $i++ ) {
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$go = 1;
		$array2[$i] = preg_replace($patterns, $replacements, $questionIdArray[$i]);
		$arguments['questionId' . $i] = $array2[$i]['question_id'];
		
		
	}
		
		
		$sql = "select id, question_id from question_information" . $_SESSION['subject'];
		$sql .= "  ";
		$sql .= " where question_id like :questionId0 ";
		
		
		
	
		
		
		
		
		
		
		for($i = 1 ; $i < count($questionIdArray) ; $i ++ ) {
		
		
			
			$sql .= " or question_id like :questionId" . $i . " "; 
			
		
		
		}
		return $this->db->runSql($sql, $arguments)->fetchAll();
	}

	public function recordResults($percentage, $data, $timestamp) {
		$arguments['timestamp'] = $timestamp;
		$arguments['realtime'] = strtotime('now');
		$arguments['percentage'] = $percentage;
		$arguments['data'] = $data;
		$arguments['user'] = $_SESSION['id'];
		$arguments['class'] = $_SESSION['class'];
		$arguments['subject'] = $_SESSION['subject'];
		$sql = "insert into users_results (user_id, string, score, timestamp, class, subject, realtime) values ";
		$sql .= "(:user, :data, :percentage, :timestamp, :class, :subject, :realtime)";
		return $this->db->runSql($sql, $arguments);
	}
	public function recordSubjectResultsInitial($data, $maxTime) {
	
		$arguments['data'] = $data;
		$arguments['user'] = $_SESSION['id'];
		$arguments['class'] = $_SESSION['class'];
		$arguments['subject'] = $_SESSION['subject'];
		$arguments['maxT'] = $maxTime;
		$sql = "insert into subject_results (user_id, string, class, subject, max_time) values ";
		$sql .= "(:user, :data, :class, :subject, :maxT)";
		return $this->db->runSql($sql, $arguments);
	}
	
	public function updateSubjectResults($data, $maxTime) {
		$arguments['data'] = $data;
		$arguments['user'] = $_SESSION['id'];
		$arguments['class'] = $_SESSION['class'];
		$arguments['subject'] = $_SESSION['subject'];
		$arguments['maxT'] = $maxTime;
		$sql = "update subject_results set max_time = :maxT, string = :data where user_id like :user and class like :class and subject like :subject";
		return $this->db->runSql($sql, $arguments)->rowCount();

	}

	public function selectResultsString() {
		if (isset($_SESSION['classId'])) {
			$arguments['class'] = $_SESSION['classId'];
			} else {
				$arguments['class'] = $_SESSION['class'];
				
			}
		$arguments['subject'] = $_SESSION['subject'];
		$arguments['id'] = $_SESSION['id'];
		$sql = "select string from subject_results where class like :class and subject like :subject and user_id like :id";
		return $this->db->runSql($sql, $arguments)->fetch();
	}
	public function selectFirstResult() {
		if (isset($_SESSION['classId'])) {
			$arguments['class'] = $_SESSION['classId'];
			} else {
				$arguments['class'] = $_SESSION['class'];
				
			}
		$arguments['subject'] = $_SESSION['subject'];
		$arguments['id'] = $_SESSION['id'];
		$sql = "select score, timestamp from users_results where class like :class and subject like :subject and user_id like :id order by id offset 0 rows fetch next 1 rows only";
		return $this->db->runSql($sql, $arguments)->fetch();
	}
	public function selectMaxResult($id) {
		if (isset($_SESSION['classId'])) {
			$arguments['class'] = $_SESSION['classId'];
			} else {
				$arguments['class'] = $_SESSION['class'];
				
			}
		$arguments['subject'] = $_SESSION['subject'];
		$arguments['id'] = $id;
		$sql = "select max(timestamp) as fake_time, max(realtime) as realtime from users_results where class like :class and subject like :subject and user_id like :id";
		return $this->db->runSql($sql, $arguments)->fetch();
	}
	public function selectAllResultsPagination($page, $limit, $id) {
		if (isset($_SESSION['classId'])) {
		$arguments['class'] = $_SESSION['classId'];
		} else {
			$arguments['class'] = $_SESSION['class'];
			
		}
		$arguments['subject'] = $_SESSION['subject'];
		$arguments['id'] = $id;

		$sql = "select count(*) as count from users_results where class like :class and subject like :subject and user_id like :id";
		$count = $this->db->runSql($sql, $arguments)->fetch();
		$totalPages = ceil($count['count'] / $limit);
		$offset = ($page - 1) * $limit;
		$sql = "select id, score, realtime, timestamp from users_results where class like :class and subject like :subject and user_id like :id order by id desc offset ".$offset." rows fetch next ".$limit." rows only";
		$select = $this->db->runSql($sql, $arguments)->fetchAll();
		$arry['totalPages'] = $totalPages;
		$arry['select'] = $select;
		$arry['count'] = $count;
		return $arry;
	}

	public function selectIndividualResult($scoreId) {
		$arguments['id'] = $scoreId;
		$sql = "select string, score from users_results where id like :id";
		return $this->db->runSql($sql, $arguments)->fetch();
		
	}
// for bio results page
	
public function selectUndertakenClassesViaLetter($userId, $page, $limit, $letter) {
	$arguments['userId'] = $userId;
	$arguments['letter'] = $letter;
	$patterns[0] = '/;/';
	$patterns[1] = '/go/';
	$replacements[0] = '';
	$replacements[1] = '';
		
	$limit = intval($limit);
	$limit = preg_replace($patterns, $replacements, $limit);
	$limit = $limit * 1;

	$offset = ($page - 1) * $limit;
	
	$sql = "select count(*) as count from (select c.class_name, r.class, r.user_id from classes c left join tables s ";
	$sql .= "on c.class_id = s.class_id left join users_results r on s.class_id = r.class ";
	$sql .= "group by c.class_name, r.class, r.user_id) t where user_id like :userId and left(class_name, 1) like :letter ";
	$result[0] = $this->db->runSql($sql, $arguments)->fetch();

	$sql = "select * from (select c.class_name, r.class from classes c left join tables s ";
	$sql .= "on c.class_id = s.class_id left join users_results r on s.class_id = r.class ";
	$sql .= "where r.user_id like :userId and left(c.class_name, 1) like :letter ) t group by class_name, class order by class_name ";
	$sql .= " offset $offset rows fetch next $limit rows only";
	$result[1] = $this->db->runSql($sql, $arguments)->fetchAll();

	return $result;
}

	public function selectUndertakenClasses($userId, $page, $limit) {
		$arguments['userId'] = $userId;
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		
		$limit = intval($limit);
		$limit = preg_replace($patterns, $replacements, $limit);
		$limit = $limit * 1;

		$offset = ($page - 1) * $limit;
		$sql = "select count(*) as count from (select c.class_name, r.class from classes c left join tables s ";
	$sql .= "on c.class_id = s.class_id left join users_results r on s.class_id = r.class ";
	$sql .= "where r.user_id like :userId group by class_name, class) t";
	$result[0] = $this->db->runSql($sql, $arguments)->fetch();

		$sql = "select * from (select c.class_name, r.class from classes c left join tables s ";
		$sql .= "on c.class_id = s.class_id left join users_results r on s.class_id = r.class ";
		$sql .= "where r.user_id like :userId) t group by class_name, class order by class_name";
		$sql .= " offset $offset rows fetch next $limit rows only";
		$result[1] = $this->db->runSql($sql, $arguments)->fetchAll();

	return $result;
	}
	public function selectUndertakenSubjects($userId, $classId) {
		$arguments['userId'] = $userId;
		$arguments['classId'] = $classId;
		$sql = "select * from (select x.subject_information, max(y.subject) as id, x.table_id from tables x right join ";
		$sql .= "users_results y on x.table_id = y.subject where y.user_id like :userId and y.class like ";
		$sql .= ":classId group by x.subject_information, y.class, x.table_id) t order by subject_information asc";
		return $this->db->runSql($sql, $arguments)->fetchAll();
	}
	public function selectMaxMinScoreFromSubject($userId, $classId, $subjectId) {
		$arguments['userId'] = $userId;
		$arguments['classId'] = $classId;
		$arguments['subjectId'] = $subjectId;
		$sql = "select min(score) as min, max(score) as max from users_results where class like :classId and ";
		$sql .= "subject like :subjectId and user_id like :userId";
		return $this->db->runSql($sql, $arguments)->fetch();
	}
	public function selectLastScoreFromSubject($userId, $classId, $subjectId) {
		$arguments['userId'] = $userId;
		$arguments['classId'] = $classId;
		$arguments['subjectId'] = $subjectId;
		$sql = "select top 1 * from users_results where class like :classId and subject like :subjectId ";
		$sql .= "and user_id like :userId desc";
		return $this->db->runSql($sql, $arguments)->fetch();
	}

	public function findClassesAverageScoreAdminOnly($userId, $classId, array $subjectsArray) {
		$arguments['classId'] = $classId;
		$counter = 0;
		$finalCountOfScores = 0;
		foreach($subjectsArray as $id) {
		
		$arguments['userId'] = $userId;
		$arguments['id'] = $id['id'];
		

		$sql ="select avg(score) as class_average from users_results where class like :classId and user_id like :userId and subject like :id";
		$result[$counter] = $this->db->runSql($sql, $arguments)->fetch();
		$finalCountOfScores = $finalCountOfScores + intval($result[$counter]['class_average']);
		$counter++;
		}
		return ($finalCountOfScores / $counter);
	}

	public function findClassesMaxScoreAdminOnly($userId, $classId, array $subjectsArray) {
		$arguments['classId'] = $classId;
		$counter = 0;
		$finalCountOfScores = 0;
		foreach($subjectsArray as $id) {
		
		$arguments['userId'] = $userId;
		$arguments['id'] = $id['id'];
		

		$sql ="select Max(score) as class_average from users_results where class like :classId and user_id like :userId and subject like :id";
		$result[$counter] = $this->db->runSql($sql, $arguments)->fetch();
		$finalCountOfScores = $finalCountOfScores + intval($result[$counter]['class_average']);
		$counter++;
		}
		return ($finalCountOfScores / $counter);
	}

	public function findClassesLastScoreAdminOnly($userId, $classId, array $subjectsArray) {
		$arguments['classId'] = $classId;
		$counter = 0;
		$finalCountOfScores = 0;
		foreach($subjectsArray as $id) {
		
		$arguments['userId'] = $userId;
		$arguments['id'] = $id['id'];
		

		$sql ="select top 1 score as class_average from users_results where class like :classId and user_id like :userId and subject like :id order by id desc";
		$result[$counter] = $this->db->runSql($sql, $arguments)->fetch();
		$finalCountOfScores = $finalCountOfScores + intval($result[$counter]['class_average']);
		$counter++;
		}
		return ($finalCountOfScores / $counter);
	}


}
		