<?php 
include 'includes/header3.php';

if (isset($_GET['class'])) {
$classId = $_GET['class'];
$_SESSION['class'] = $classId;
}
$start = microtime(true);
$subjects = $cms->getQuestions()->selectUndertakenSubjects($_SESSION['id'], $_SESSION['class']);
echo '<br><br>';
$counter = 0;
if ($_SESSION['administrator']['admin'] == 1) {
foreach($subjects as $subject) {
    if ($subject['subject_information'] != 'empty') {
$arr[$counter]['id'] = $subject['table_id']; 

    }
}
}








        foreach($subjects as $subject) {
            if ($subject['subject_information'] != 'empty') {

                if(isset($_GET['a']) && $_SESSION['administrator']['admin'] == 1) {
$averageClassScore = $cms->getQuestions()->findClassesAverageScoreAdminOnly($_SESSION['id'], $_SESSION['class'], $arr);

?>

<h2>AVERAGE SCORE FROM CLASS: <?= $averageClassScore ?><h2><br>
<?php
                }
    if(isset($_GET['m']) && $_SESSION['administrator']['admin'] == 1) {
$maxClassScore = $cms->getQuestions()->findClassesMaxScoreAdminOnly($_SESSION['id'], $_SESSION['class'], $arr);
?>

<h2>Max SCORE FROM CLASS: <?= $maxClassScore ?><h2><br>
<?php
                }
    if(isset($_GET['l']) && $_SESSION['administrator']['admin'] == 1) {
$lastClassScore = $cms->getQuestions()->findClassesLastScoreAdminOnly($_SESSION['id'], $_SESSION['class'], $arr);
?>
<h2>Last SCORE FROM CLASS: <?= $lastClassScore ?><h2><br>

<?php
                }

                if($_SESSION['administrator']['admin'] == 1) {
?>

<a href="bioTwo.php?a=yes">Check avarage score</a><br>
<a href="bioTwo.php?m=yes">Check average max score</a><br>
<a href="bioTwo.php?l=yes">Check average last score</a><br>
<?php
                }
?>

<a href="bioThree.php?subject=<?=$subject['id'] ?? '' ?>"><?= $subject['subject_information'] ?? '' ?> </a><br><br>


<br>
<br>

<?php
    }
}
$end = microtime(true);
echo ($end - $start);