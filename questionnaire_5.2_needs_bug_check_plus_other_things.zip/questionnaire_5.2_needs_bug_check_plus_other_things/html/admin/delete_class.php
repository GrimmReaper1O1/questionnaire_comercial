<?php 
include "../includes/header4.php";
$error = '';
if ($_SESSION['administrator']['admin'] == 1) {
	
	if (isset($_GET['class'])) {
		$result01 = 0;
		for($i = 1; $i < 31; $i++) {
		$result0 = $cms->getQuestions()->deleteFromQuestionInformationViaClassIdAndSubject($i, $_GET['class']);
		
		if ($result0 < 0) {
			$result01 = $result0;
		}
		}
		$result1 = $cms->getQuestions()->deleteFromQuestionDescriptionViaClassId($_GET['class']);
		$result2 = $cms->getQuestions()->deleteFromSubjectsTableViaClassId($_GET['class']);
	//	$result3 = $cms->getQuestions()->deleteFromUsersOfClassesViaClassId($_GET['class']);
	//	$array = $cms->getQuestions()->selectAllFromLibraryViaClassId($_GET['class']);
	//	$result4 = $cms->getQuestions()->deleteFromLibraryViaClassId($_GET['class']);
	//	$result5 = $cms->getQuestions()->deleteFromTermsViaClassId($_GET['class']);
		$result6 = $cms->getQuestions()->deleteFromClassesViaClassId($_GET['class']);
	//	if ($result01 > 0) {
	//		$error .= "INFORMAITON WAS DELETED FROM THE QUESITON INFORMATION TABLE.<br>";
	//	} else {
	//		$error .= "THERE MAY NOT HAVE BEEN INFROMATION TO DELETE FROM THE QUESITON INFORMATION TABLE <br>";
	//		$error .= "OR THERE WAS A PROBLEM. TRY AGAIN VIA THE BUTTON BELOW.<br>";
	//	}
	//	if ($result1 > 0) {
	//		$error .= "INFORMAITON WAS DELETED FROM THE QUESTION DESCRIPTION TABLE.<br>";
	//	} else {
	//		$error .= "THERE MAY NOT HAVE BEEN INFROMATION TO DELETE FROM THE QUESTION DESCRIPTION TABLE <br>";
	//		$error .= "OR THERE WAS A PROBLEM. PLEASE TRY AGAIN <br>";
	//	}
	//	if ($result2 > 0) {
	//		$error .= "INFORMAITON WAS DELETED FROM .<br>";
	//	} else {
	//		$error .= "THERE MAY NOT HAVE BEEN INFROMATION TO DELETE FROM THE SUBJECTS TABLE <br>";
	//		$error .= "OR THERE WAS A PROBLEM. PLEASE TRY AGAIN  <br>";
	//		
	//	}
	//	if ($result3 > 0) {
	//		$error .= "INFORMAITON WAS DELETED FROM FROM USERS IN CLASSES TABLE.<br>";
	//	} else {
	//		$error .= "THERE MAY NOT HAVE BEEN INFROMATION TO DELETE FROM USERS IN CLASSES TABLE <br>";
	//		$error .= "OR THERE WAS A PROBLEM. PLEASE TRY AGAIN <br>";
	//		
	//	}
	//	$count = 1;
	//	foreach($array as $row) {
	//	
	//	if(unlink($row['file_location'])) {
	//		$count++;
	//	}
	//		
	//	}
//
//		
//		if ($count > 0) {
//			$error .= "THERE WERE " . $count . " FILES DELETED FROM THE LIBRARY.<br>";
//		} else {
//			$error .= "THERE MAY NOT HAVE BEEN INFROMATION TO DELETE FROM THE LIBRARY TABLE  <br>";
//			$error .= "OR THERE WAS A PROBLEM. PLEASE TRY AGAIN <br>";
//			
//		}
//		if ($result4 > 0) {
//			$error .= "THERE WERE ENTRIES DELETED FROM THE LIBRARY.<br>";
//		} else {
//			$error .= "THERE MAY NOT HAVE BEEN INFROMATION TO DELETE FROM THE LIBRARY TABLE  <br>";
//			$error .= "OR THERE WAS A PROBLEM. PLEASE TRY AGAIN <br>";
//			
//		}
//		if ($result5 > 0) {
//			$error .= "INFORMAITON WAS DELETED FROM THE TERMS TABLE.<br>";
//		} else {
//			$error .= "THERE MAY NOT HAVE BEEN INFROMATION TO DELETE FROM THE TERMS TABLE  <br>";
//			$error .= "OR THERE WAS A PROBLEM. PLEASE TRY AGAIN <br>";
//		
//		}
//		
		if ($result6 > 0) {
	$error .= "INFORMAITON WAS DELETED FROM THE CLASSES TABLE.<br>";
		} else {
			$error .= "THERE MAY NOT HAVE BEEN INFROMATION TO DELETE FROM THE CLASSES TABLE <br>";
			$error .= "OR THERE WAS A PROBLEM. PLEASE TRY AGAIN <br>";
		
		}
	//	echo "IF THERE IS NO INFORMATION IN A TABLE IT IS NORMAL TO SEE A NO SUCCESS MESSAGE.<br>";
		echo $error;
		?>
<form action="delete_class.php?class=<?= $_GET['class'] ?>" method="POST">
			<input type="submit" value="TRY AGAIN!">
			</form>
	<?php
	
		}
	
} else {
    header("Location: how_dare_you.php");
    exit();
}
