<?php
include "../includes/header4.php";
if ($_SESSION['administrator']['admin'] == 1) {
$error = '';
$enter = 0;
if (isset($_GET['unset'])) {
	unset($_SESSION['pageQuestionSets']);
}

if (isset($_GET['page'])) {
	$page = isset($_GET['page']) ? $_GET['page'] :  $_SESSION['pageQuestionSets'];
	$_SESSION['pageQuestionSets'] = $page;
} elseif (isset($_SESSION['pageQuestionSets'])) {
$page = $_SESSION['pageQuestionSets'];

} else {
		$page = 1;
	}
	$limit = 15;
$error = '';

if (isset($_GET['id'])) {
$_SESSION['subject'] = $_GET['id'];
}
$start = microtime(true);



if (isset($_SESSION['subject'])) {

foreach($_SESSION['subjectsFromPage'] as $subjects) {
	
if ($subjects['live'] == 0 && $subjects['id'] == $_SESSION['subject']) {
	$enter = 1;
	
}
}
}


if (($enter == 1 || $_SESSION['administrator']['root'] == 1) && (isset($_SESSION['class']) && isset($_SESSION['subject']))) {
$questions = $cms->getQuestions()->selectQuestions($_SESSION['subject'], $page, $limit);
$totalQuestions = $questions[0]['count'];
$totalPages = ceil($totalQuestions / $limit);
echo '<a href="subjects.php">BACK TO MAIN ADMINISTRATIVE PAGE!</a><br>';
echo "<h1>" . $_SESSION['subject_information'] . "</h1><br>";

foreach($questions[1] as $question) {
	?><h3>QUESTION POSSITION:</h3><br><?= $question['question_number'] ?><br>
	<?php 
	if ($question['live'] == 0 || $_SESSION['administrator']['root'] == 1) {
	?>
	
	
	<a href="reposition_question.php?ids=<?= $question['question_id'] ?>">REPOSSITION QUESTION!</a><br>
	<h4><p><a href="addQuestionInformation.php?name=yes&id=<?= $question['question_id'] ?>">UPDATE QUESTION NAME!</a></p></h4><br>
	<?php
	} 
	?>
	<h3>DESCRIPTION OF QUESTION:</h3>
	<h4><p><a href="questionsAndAnswers.php?unset=yes&id=<?= $question['question_id'] ?>"><?= $question['description'] ?></a></p></h4>
	<?php 
	if ($question['live'] == 0 || $_SESSION['administrator']['root'] == 1) {
	?>
	
	<h4><p><a href="updateQuestionAndAnswers.php?id=<?= $question['question_id'] ?>">ADD QUESTION INFORMATION!</a></p></h4>
	<h4><p><a href="deleteIndividualQuestion.php?delete=<?=$question['question_id'] ?>">DELETE QUESTION!</a></p></h4><br><br><br>
	<?php
	} 
	?>
	
	
<?php
} echo "-";
for($i = 1; $i <= $totalPages; $i++){
?>
<a href="questionSets.php?page=<?= $i ?>&info=<?= $_SESSION['subject_information'] ?>"><?= $i ?>-</a>
<?php
}
} else {
	header("Location: classes.php?reset=yes");
	exit;
}


$end = microtime(true);
echo ($end - $start);
 
} else {
    header("Location: how_dare_you.php");
    exit();
}
