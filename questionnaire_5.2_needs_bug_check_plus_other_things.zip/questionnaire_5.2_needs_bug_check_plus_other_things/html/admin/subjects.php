<?php
include "../includes/header4.php";
if ($_SESSION['administrator']['admin'] == 1) {
	if (isset($_SESSION['class'])) {
$error = '';
$enter = 0;
if (isset($_GET['page'])) {
	$page = isset($_GET['page']) ? $_GET['page'] : $_SESSION['pageSubjects'] ;
	$_SESSION['pageSubjects'] = $page;
} elseif (isset($_SESSION['pageSubjects'])) {
	$page = $_SESSION['pageSubjects'];
	
	} else {
		$page = 1;
	}
	
	
	
$limit = 15;
$error = '';
if (isset($_GET['unset'])) {
	unset($_SESSION['subject']);

	unset($_SESSION['subject_information']);
}
if (isset($_GET['class'])) {
if ($_GET['class'] > 0 && $_GET['class'] != '') {
$_SESSION['class'] = $_GET['class'];

}
}

$start = microtime(true);



if (isset($_GET['makeLive']) || isset($_GET['sid'])) {
	$subject = $cms->getQuestions()->selectSubjectViaTableIdNSAndClassId($_GET['sid']);
		if (($_GET['sid'] == $subject['table_id'] && $subject['live'] == 0) ) {
		
		$enter = 1;
		
		}
	}





if (($enter == 1 || $_SESSION['administrator']['root'] == 1) && isset($_SESSION['class'])) {
	if (isset($_GET['makeLive'])) {
	$result = $cms->getQuestions()->updateSubjectMakeLive($_GET['sid']);
	
	if ($result > 0) {
		$error .= "THE SUBJECT IS NOW LIVE!<br>";	
	} else { 
		$error .= "THE SUBJECT STILL IS NOT LIVE!<br>";
	}
	
}


if (isset($_GET['takeDown'])) {
	$result = $cms->getQuestions()->updateSubjectNotLive($_GET['sid']);
	
	if ($result > 0) {
		$error .= "THE SUBJECT HAS BEEN TAKEN DOWN!<br>";
} else {
		$error .= "THE SUBJECT HAS NOT BEEN TAKEN DOWN.<br>";
}
}

}





	








$subjectsArray = $cms->getQuestions()->selectAllFromSubjectsAdmin($_SESSION['class']);
echo $error;
echo "<h1>SELECT THE SUBJECT TO ALTER</h1><br>
<h2>All questions must have at least one question filled within their question set 
before the subject is made live, otherwise the system will not function propperly.</h2><br>";	
	$_SESSION['subjectsFromPage'] = $subjectsArray;

foreach($subjectsArray as $subjects) {
	

	
	?>
	<h3><?php if ($subjects['live'] == 1) { echo "LIVE!<br>"; } else { echo "NOT LIVE!<br>"; } 
	if ($_SESSION['administrator']['root'] == 1) {?>
	<a href="subjects.php?makeLive=yes&sid=<?= $subjects['id'] ?>">MAKE SUJBECT LIVE!</a><br>
	<a href="subjects.php?takeDown=yes&sid=<?= $subjects['id'] ?>">TAKE DOWN SUJBECT!</a><br>
	<?php 
	} 
	?>
	
	SUBJECT: <?php if ($subjects['subject_information'] != 'empty') 
	{
		
?>
<a href="introductionToSubject.php?id=<?= $subjects['table_id'] ?>"><?= $subjects['subject_information'] ?></a><br>
	THE SUBJECT DISPLAYS <?= $subjects['number_of_questions'] ?> QUESTIONS.<br>
	<?php
	if ($subjects['live'] == 0) {
	?>

<br> <a href="fillQuestionnaireOne.php?id=<?= $subjects['table_id'] ?>">ADD QUESTIONS OR ALTER SUBJECT NAME.</a><br><br>
	<a href="deleteAllQuestionsFromSubject.php?id=<?= $subjects['table_id'] ?>">DELETE ALL INFORMATION FROM TABLE ABOVE!</a><br><br>
	<a href="updateSubject.php?updateSubject=<?= $subjects['id'] ?>">UPDATE SUBJECT NAME OR NUMBER OF QUESTIONS!</a></h3><br><br><br>
	<?php } }	else { echo '<br> <a href="fillQuestionnaireOne.php?id=' . $subjects['table_id'] . '">FILL SUBJECT!</a>'; } 
	
	

}




$end = microtime(true);
echo ($end - $start);


} else {
	header("Location: classes.php?reset=yes");
	exit;
}

} else {
    header("Location: how_dare_you.php");
    exit();
}