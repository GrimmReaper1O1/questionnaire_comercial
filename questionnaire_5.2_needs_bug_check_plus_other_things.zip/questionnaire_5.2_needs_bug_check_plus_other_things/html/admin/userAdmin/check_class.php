<?php 
include '../../includes/header5.php';
$start = microtime(true);
if (isset($_GET['id'])) {
    $_SESSION['ident'] = $_GET['id'];
}
if (isset($_GET['letter'])) {
	$_SESSION['letter'] = $_GET['letter'];
    }
$limit = 10;

$letterString = 'A B C D E F G H I J K L M N O P Q R S T U V W X Y Z';
$letterArray = preg_split('/[\s]+/', $letterString);

if (isset($_GET['unset'])) {
    unset($_SESSION['letter']);
    unset($_SESSION['page']);
}

$_SESSION['page'] = $_GET['page'] ?? 1;

if (isset($_GET["letter"])) {
    $_SESSION['letter'] = $_GET['letter'];
}

if (isset($_SESSION['letter'])) {
    
    $classesArray = $cms->getQuestions()->selectUndertakenClassesViaLetter($_SESSION['ident'], $_SESSION['page'], $limit, $_SESSION['letter']);

    $totalResults = $classesArray[0]['count'];
	

    $totalPages = ceil($totalResults / $limit);

}

if (!isset($_SESSION['letter'])) {
    
    $classesArray = $cms->getQuestions()->selectUndertakenClasses($_SESSION['ident'], $_SESSION['page'], $limit);
    
    $totalResults = $classesArray[0]['count'];
	
    $totalPages = ceil($totalResults / $limit);

    

}



if (isset($classesArray)) {
	if ($classesArray[0] != false) {

	    $totalResults = $classesArray[0]['count'];
	
        $totalPages = ceil($totalResults / $limit);
	

foreach($letterArray as $letters) { ?>
<?= "-" ?><a href="check_class.php?unset=yes&letter=<?= $letters ?>"><?= $letters ?></a><?= "-" ?>

<?php
}
?>
<br><a href="check_class.php?unset=yes">GO BACK TO ALPHABETICAL ORDER!</a><br>
<?php



foreach($classesArray[1] as $class) {

?>

<h4>Class:<br>
<a href="check_subject.php?classId=<?= $class['class'] ?>"><?= $class['class_name'] ?></a></h4><br><br>
	


<?php
       }
    }
}
?>




<?php 

	
echo "-";
for ($i = 1; $i <= $totalPages; $i++) {
    echo '<a href="bioOne.php?page=' . $i . '">' . $i . '</a> - ';
}
		
$end = microtime(true);
echo ($end - $start);



	
 ?>