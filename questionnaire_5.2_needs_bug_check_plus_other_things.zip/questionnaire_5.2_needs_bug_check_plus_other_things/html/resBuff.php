<?php 

?>

<!DOCTYPE HTML>
<html>
	<head>
</head>
<body>

<script src='/src/jquery-3.7.1.js'></script>
<script>
	
<?php for ($i = 1; $i <= $_GET['tp']; $i++) { ?>
var page<?= $i ?> = JSON.parse(sessionStorage.getItem('page<?= $i ?>'));

	<?php
}
?>
var pages = {}
<?php for ($i = 1; $i <= $_GET['tp']; $i++) { ?>
pages.pg<?= $i ?> = page<?= $i ?>;

	<?php
}
?>
console.log(pages);
var place = JSON.stringify(pages);
console.log(place);
console.log(JSON.parse(place));

var url = 'results.php';
var form = $("<form action='" + url + "' method='post'>" +
  "<input type='text' name='data' value='" + place + "' />" +
  '</form>');
$('body').append(form);
form.submit();
  
</script>

</body>
</html>
