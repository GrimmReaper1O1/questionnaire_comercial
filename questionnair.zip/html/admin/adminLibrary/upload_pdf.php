<?php
include '../../includes/header5.php';
if ($administrator['admin'] == 1) {
$error = '';
$error2 = '';
$message = '';




if ($_SERVER['REQUEST_METHOD'] === 'POST') {
if ($_POST['class'] != '') {
	unset($_SESSION['class']);
}
$moved = false;
    
	$row = $cms->getMember()->selectClassViaName($_POST['class']);
echo $_SESSION['class'];
	if($row != false || isset($_SESSION['class'])) {
		
    $upload_path = '../../uploads/';
    $max_size = 2137552 * 3;
    $allowed_types = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',];
    $allowed_exts = ['pdf', 'doc', 'docx',];

      $error2 = ($_FILES['document']['size'] <= $max_size) ? '' : 'Your file is too large. It must be under 2MB';
      $type = mime_content_type($_FILES['document']['tmp_name']);
      $error2 .= in_array($type, $allowed_types) ? '' : 'Your file is of the wrong type. It must be a pdf, doc or docx.';
      $ext = strtolower(pathinfo($_FILES['document']['name'], PATHINFO_EXTENSION));
       $error2 .= in_array($ext, $allowed_exts) ? '' : 'It must have the right file extension.';

       if ($error2 === '') {
        $filename = create_filename($_FILES['document']['name'], $upload_path);
        $destination = $upload_path . $filename;
        $moved = move_uploaded_file($_FILES['document']['tmp_name'], $destination);
		$destination = "../uploads/" . $filename;
		echo "here2";
       }
	   
       if ($moved === true) {
		   echo "here";
			if ($_POST['class'] != '') {
				$class = $row['class_id'];
			} else {
				$class = $_SESSION['class'];
			}
   try {
	        $check = $cms->getLibrary()->insertIntoLibrary($_POST['author'], $_POST['name'], $destination, $_POST['description'], $_SESSION['id'], $class);
		$message .= "Your document updated successfully! ";
    } catch(Exception $e) {
        $error2 .= "We're sorry! There was a problem. Please try again.";
   }   
    
   }
	} else {
		$error .= "THE CLASS WASN'T FOUND OR YOU WERE NOT IN A CLASS WHEN YOU ENTERED THIS PAGE.";
	}
}

echo $error2 . $message . '<br>';
if ($message == '' || $error2 != '' || $message != '') {
?>
CLASS NOT REQUIRED IF YOU ENTERED THROUGH ADMIN CLASSES. IF SO LEAVE IT BLANK AND IT<br>
WILL ASSING TO THE CLASS YOU WERE IN.<br><br>

<form action="upload_pdf.php" method="POST" enctype="multipart/form-data">
    <label for="class">CLASS NAME:</label>
    <input type="text" size="50" name="class" value="<?= $_POST['class'] ?? '' ?>"><br>
	<label for="name">Document name:</label>
    <input type="text" name="name"value="<?=  $_POST['name'] ?? '' ?>"><br>
	
    <label for="author">Author:</label>
    <input type="text" size="50" name="author" value="<?= $_POST['author'] ?? '' ?>"><br>
    Description of file:<br>
    <textarea name="description" rows="10" cols="80"> <?= $_POST['description'] ?? '' ?></textarea><br>
    <label for="document">Upload PDF file:</label>
    <input type="file" name="document"><br>
    <input type="submit" name="submit" value="SUBMIT!">
    </form>

    <?php }
	} else {
		header("Location: how_dare_you.php");
		exit();
	}