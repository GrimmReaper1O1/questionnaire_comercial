<?php
include "../../includes/header5.php";
if ($administrator['admin'] == 1) {
// include administrative function
$limit = 20;
$page = $_GET['page'] ?? 1;

$showAllAdminPersonel = $cms->getMember()->getAllAdministrators($page, $limit);
		
$totalResults = $showAllAdminPersonel[0]['count'];
	

$totalPages = ceil($totalResults / $limit);

        if ($showAllAdminPersonel === false) {
            $error = "There was an error in the attempt to show all administrators. Please try again.";
        } else {

	foreach ($showAllAdminPersonel[1] as $row) {
		?>
		<h4>
		Full name: <?= $row['concat_full_name'] ?><br>
		Email: <?= $row['email'] ?><br>
		Phone number: <?= $row['phone_number'] ?><br>	
		Created by administrator: <?= $row['creator_name'] ?><br>
		Administrator created on: <?php echo date('d-m-y h:i a', $row['timestamp']); ?><br>
		</h4>

	<?php
	}

echo "-";
for ($i = 1; $i <= $totalPages; $i++) {
    echo '<a href="show_all_administrators.php?page=' . $i . '">' . $i . '</a> - ';
}
}

} else {
    header("Location: how_dare_you.php");
    exit();
}