<?php 
include 'includes/headerstart.php';
if (isset($_SESSION['id'])) {
unset($_SESSION['class']);
unset($_SESSION['live']);
$start = microtime(true);
$page = $_GET['page'] ?? 1;
$limit = 1;
$letter = $_GET['letter'] ?? 1;
$letterString = 'A B C D E F G H I J K L M N O P Q R S T U V W X Y Z';
$letterArray = preg_split('/[\s]+/', $letterString);
if (isset($_GET['unset'])) {
	unset($_SESSION['letter']);
	unset($_SESSION['search']);
	unset($_SESSION['new']);
}
if (isset($_GET['reset'])) {
	unset($_SESSION['subject']);
	unset($_SESSION['letter']);
	unset($_SESSION['search']);
	$_SESSION['new'] = 1;
	
}


if (isset($_GET['letter'])) {
	$_SESSION['letter'] = $_GET['letter'];
	
}
?>
<div id="main">
	<div class="margin80">
	<br><br><br>
		<div class="letters"><p class="letters">
	<?php
foreach($letterArray as $letters) { ?>
<?= " -" ?><a href="classes.php?unset=yes&letter=<?= $letters ?>"><?= $letters ?></a><?= "- " ?>
<?php
} ?>
</p>
	

	<div class="headings">
		<br><br><br><br>
<h1>Welcome to questionnaire!</h1><br>
	<h3><a href="classes.php?reset=yes">Please select the class you want to enroll in via alphabetical order.</a><br> 
<!-- <a href="search_for_class.php?unset=yes">Or, search for a class.</a></h3><br><br> -->
	</div>
	<div class="letters">
<?php
if (isset($_SESSION['letter'])) {
	$classesArray = $cms->getQuestions()->selectAllClassesViaLetterLive($page, $limit, $_SESSION['letter']);
	echo '<a href="classes.php?reset=yes">Return to alphabetical order</a><br>';
	}
	?>
	</div>
<?php
if (isset($_SESSION['new'])) {
$classesArray = $cms->getQuestions()->selectAllClassesLive($page, $limit);
}
if (isset($classesArray)) {
	if ($classesArray[0] != false) {

	$totalResults = $classesArray[0]['count'];
	

$totalPages = ceil($totalResults / $limit);
?>

	<div class="headings">

<?php	
	foreach($classesArray[1] as $class) {
	?>
	
	<h2>
	<a href="selectSubject.php?class=<?= $class['class_id'] ?>"><?= $class['class_name'] ?></a></h4><br>
	</h2>

	
	<p><?php echo paragraph($class['description_of_class']); ?><br><br>
<br><br><br><br><br><br><br>	

<?php
$end = microtime(true);
echo '<br>' . ($end - $start);

?>
<br><br><br>
<?php 
	
	}

	?>
	
	
</div>
</div>
	<div id="bottom">
		<div id="pagination">
			
			<?php
	$url = 'classes.php';
echo '<p>' . get_pagination_links($page, $totalPages, $url, '') . '<p>';

	}
	}	
?>
</div>
</div>
</div>
</body>
</html>

<?php
} else {
	header("Location: login.html");
	exit();
}
?>