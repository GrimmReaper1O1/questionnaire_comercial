<?php
include "includes/header3.php";
if (isset($_GET['id'])) {
	unset($_SESSION['startTime']);
	$_SESSION['startTime'] = microtime(true);
$id = $_GET['id'] ?? '';
$_SESSION['subject'] = $id;
}
$_SESSION['gate'] = 'enter';

if (isset($_GET['id'])) {
	$row = $cms->getQuestions()->selectSubjectViaTableIdAndClassId();
	print_r($row['number_of_questions']);
$_SESSION['version'] = $row['version'];
$_SESSION['numberOfQuestionsOnPage'] = $row['number_of_questions'];
$_SESSION['numeralOfRem'] = $row['number_of_removal'];


	$introduction = $row['introduction'] ?? '';
}
	?>
<div id="main" class="centeredText">
	<h1><?= ' ' . $row['subject_information'] ?? '' ?></h1><br><br>
<div  ><h1><i><a href="questionnaireBuf.php">ENTER SUBJECT.</a><i></h1><br>
<br>
<br>
<?php 
// if ($row['video'] == 1) { // do a pregmatch on the type of file and if matched then choose file with php
?>
	
	<video   poster="<?= $row['posterFilename'] ?? '' ?>"
	id="subjectVideo"
	type="video/webm" preload="auto"
	controls >
	<source src="<?= $row['videoFilename'] ?? '' ?>uploads/one.webm" type="video/webm" />
	<source src="<?= $row['videoFileName'] ?? '' ?>uploads/one.mpg" type="video/mp4" />
</video><br>
<audio controls>
  <source src="<?= $row['audioFilename'] ?? '' ?>" type="audio/ogg">
  <source src="<?= $row['audioFilename'] ?? '' ?>" type="audio/mpeg">
Your browser does not support the audio element.
</audio><br>
	<?php
// }
?>
</div>
<div class="width80">
<div id="rightSideInner" style="text-align: justify !important;" >	<div class="textBoxes"><?php echo '<p><h3>' . paragraph($introduction) . '</h3></p>'; ?><br><div>
<?php
for ($i = 1; $i <= 10; $i++) {
if ($row['link' . $i] != 'empty') {
	//remember to link colour with question set colour field.
	
	?>
<p ><a  style="color: black !important;" href="http:\\<?= $row['link' . $i] ?>"><?= $row['link_description' . $i] ?></a></p><br>		
	<?php
}
}
?>
</div>
</div>
<br>
<?php

?></div></div>
<div id="leftSideInner"> 
<?php
if (!isset($imageArry)) {
	for ($i = 0 ; $i< 15 ; $i++) {
	// foreach($imagaArray as $image) {
		?>
		<figure>
		<image src="<?= $image['filename'] ?? '' ?>images/plants dancing.jpg" alt="<?= $image['description'] ?? '' ?>" class="apendix">
		<figcaption><?= $image['identifier'] ?? '' ?> </figcaption>
	</figure>
		<caption>stuff</caption> 
	<?php
	}
}
?>
</div>



</div>

</div>
</body>
</html>
