<?php 


include '../includes/header4.php';
if ($_SESSION['administrator']['admin'] == 1) {

$page = $_GET['page'] ?? 1;
$limit = 2;
$error = "";

if (isset($_GET['unset'])) {
	unset($_SESSION['updateQuestion']);
	unset($_SESSION['updateId']);
	unset($_SESSION['questionId']);
	
}

$enter = 0;




if ($enter == 1 || $_SESSION['administrator']['root'] == 1 || $_SESSION['subjectsInfo']['live'] == 0) {

$failureInsert = 0;
$failureFound = 0;
$failureUpdate = 0;
$success = 0;
$failure = 0;
$failureLength = 0;
$failureNumber = 0;
$question = $_POST['question'] ?? 'empty';
$correct = isset($_POST['correct']) ? 'answ' . $_POST['correct'] : 'answ';
$numeralString[0] = 'empty';
$numeralString[1] = 'ONE';
$numeralString[2] = 'TWO';
$numeralString[3] = 'THREE';
$numeralString[4] = 'FOUR';
$numeralString[5] = 'FIVE';
$numeralString[6] = 'SIX';
$numeralString[7] = 'SEVEN';
$numeralString[8] = 'EIGHT';
for ($i = 1 ; $i <= 8 ; $i++) {
	$pa[$i] = 'empty';
	$answ[$i] = 'empty';
	$hint[$i] = 'empty';


}
if ($_SERVER['REQUEST_METHOD'] == "POST") {
for ($i = 1 ; $i <= 8 ; $i++) {
if ($_POST['pa'.$i] != '') {
	$pa[$i] = $_POST['pa'.$i];
} 

	if ($_POST['answ'.$i] != '') {
		$answ[$i] = $_POST['answ'.$i];
	} 
	
if ($_POST['hint'.$i] != '') {
		$hint[$i] = $_POST['hint'.$i];
	} 
	

}
}


if (isset($_GET['delete'])) {
	$result = $cms->getQuestions()->deleteQuestion($_GET['delete']);
	if ($result > 0) {
		$error .= "THE DELETION WAS A SUCCESS!";
	} else {
		$error .= "THE DELETION WAS NOT SUCCESSFULL.";
	}
}
if (isset($_GET['updateQuestion']) && isset($_GET['id'])) {
		$_SESSION['updateQuestion'] = $_GET['updateQuestion'];
		$_SESSION['updateId'] = $_GET['id'];
	
}
if (isset($_GET['unset'])) {
	unset($_SESSION['updateQuestion']);
	unset($_SESSION['updateId']);
	unset($_SESSION['questionId']);
}


if ((isset($_SESSION['updateQuestion']) && isset($_SESSION['updateId']) && isset($_POST['question']))) {
	
// $correct = 'answ' . $correct;
$count = $cms->getQuestions()->updateQuestion($_SESSION['updateId'], $question, $pa[1], $pa[2], $pa[3], $pa[4], $pa[5], $pa[6], $pa[7], $pa[8],
	$answ[1], $answ[2], $answ[3], $answ[4], $answ[5], $answ[6], $answ[7], $answ[8], $correct, $_SESSION['qid'],
	$hint[1], $hint[2], $hint[3], $hint[4], $hint[5], $hint[6], $hint[7], $hint[8]);
if ($count > 0) {
	$error .= "THE UPDATE WAS SUCCESSFULL!";
	
	
} else {
	$error .= "THE UPDATE WAS NOT SUCCESSFULL!";
}
}
if (isset($_SESSION['updateQuestion']) && isset($_SESSION['updateId'])) {
	
	$info = $cms->getQuestions()->selectQuestionViaQuestionId($_SESSION['updateId']);
	$row = $cms->getQuestions()->selectSubjectViaTableId($_SESSION['subject']);
	$_SESSION['subjectQuestions'] = 8;
if (isset($_GET['id'])) {
	$_SESSION['qid'] = $info['question_id'];
	$correct = preg_replace('/answ/', '', $info['correct']);
	}

?>
	<div id="main">
	<div class="centeredText">
		<?php
	if ($info != false) {
	echo $error;
?>
		<div class="margin80">
		
	<fieldset class="fieldset3">
		<h4>PLEASE ENTER ALL THE INFORMATION FOR THE INSTANCE OF THE QUESTION.</h4><br>
			<form action="questionsAndAnswers.php?updateQuestion=yes&id=<?= $_SESSION['updateId'] ?>" method="POST">
			<label for="question">QUESTION:</label><br><br>
			<textarea name='question' rows='20' cols='80'><?php if($info['question'] != 'empty') { echo $info['question']; } ?></textarea><br><br>
			<label for="correct">PLEASE ENTER THE NUMBER FOR THE CORRECT ANSWER IN THE FORM OF A NUMERAL: </label><br><br>
			<input type="text" name="correct" size="82" value="<?php if($info['correct'] != 'answ') { echo $correct; } ?>"><br><br>
			
<?PHP
for ($i = 1 ; $i <= 8 ; $i++) {
			?>
			<label for="pa<?= $i ?>">SELECTION <?= $numeralString[$i] ?>:</label><br><br>
			<input type="text" name="pa<?= $i ?>" value="<?php if($info['pa'.$i] != 'empty') { echo $info['pa'.$i]; } ?>" size="82"><br><br>
			<label for="answ<?= $i ?>">ANSWER TO SELECTION <?= $numeralString[$i] ?>:</label><br><br>
			<input type="text" name="answ<?= $i ?>" size="82" value="<?php if($info['answ'.$i] != 'empty') { echo $info['answ'.$i]; }?>"><br><br>
			<label for="hint<?= $i ?>">HINT <?= $numeralString[$i] ?>:</label><br><br>
			<input type="text" name="hint<?= $i ?>" size="82" value="<?php if($info['hint'.$i] != 'empty') { echo $info['hint'.$i]; }?>"><br><br>
<?PHP
}
?>
			<input type="submit" name="fill" value="SUBMIT!">
			</form>
</fieldset>
		<?php
		
}
}
}


if ((isset($_GET['id']) || isset($_SESSION['questionId'])) && !isset($_SESSION['updateQuestion'])) {
	if (isset($_GET['id'])) {
	$_SESSION['questionId'] = $_GET['id'];
	}
	echo $page;
	$questions = $cms->getQuestions()->selectQuestionInformation($_SESSION['questionId'], $page, $limit, $_SESSION['subject']);
	$totalQuestions = $questions[0]['count'];
	$totalPages = ceil($totalQuestions / $limit);
	
	if (isset($questions[1][0])) {

	?>
	<div id="main">
		<div class="margin80">
		<div class="right-align">
	
	<a href="questionSets.php">BACK TO MAIN ADMINISTRATIVE PAGE!</a><br>
	</div>
	<div class="centeredText">
		<?= $error ?>
		<?php
	
	
	foreach($questions[1] as $question) {
		if ($_SESSION['live'] == 0) { 
		?>
		<h4><a href="questionsAndAnswers.php?delete=<?= $question['id'] ?? '' ?>">DELETE QUESTION!</a></h4><br>
		<h4><a href="questionsAndAnswers.php?updateQuestion=yes&id=<?= $question['id'] ?? '' ?>">UPDATE QUESTION!</a></h4><br>
		<?php
		} ?>
		
		<h3>CORRECT ANSWER:</h3><br><?= $question['correct'] ?? '' ?><br>
		<h3>QUESTION:</h3><br><p><?php echo paragraph($question['question']) ?> </p><br>
		<h3>POSSIBLE ANSWER ONE:</h3><p><br><?php echo paragraph($question['pa1']) ?> </p><br>
		<h3>ANSWER:</h3><br><p><?php echo paragraph($question['answ1']) ?> </p><br>
		<?php } if ($question['hint1'] != 'empty') { ?>
		<h3>HINT:</h3><br><p><?php echo paragraph($question['hint1']) ?> </p><br>
		<?php } ?>
		<h3>POSSIBLE ANSWER TWO:</h3><br><p><?php echo paragraph($question['pa2']) ?> </p><br>
		<h3>ANSWER:</h3><br><p><?php echo paragraph($question['answ2']) ?> </p><br>
		<?php  if ($question['hint2'] != 'empty') { ?>
		<h3>HINT:</h3><br><p><?php echo paragraph($question['hint2']) ?> </p><br>
		<?php if ($question['pa3'] !== 'empty') { ?>
		<h3>POSSIBLE ANSWER THREE:</h3><br><p><?php echo paragraph($question['pa3']) ?> </p><br>
		<h3>ANSWER:</h3><br><p><?php echo paragraph($question['answ3']) ?> </p><br>
		<?php } if ($question['hint3'] != 'empty') { ?>
		<h3>HINT:</h3><br><p><?php echo paragraph($question['hint3']) ?> </p><br>
		<?php } if ($question['pa4'] != 'empty') { ?>
		<h3>POSSIBLE ANSWER FOUR:</h3><br><?php echo paragraph($question['pa4']) ?> </p><br>
		<h3>ANSWER:</h3><br><p><?php echo paragraph($question['answ4']) ?> </p><br>
		<?php } if ($question['hint4'] != 'empty') { ?>
		<h3>HINT:</h3><br><p><?php echo paragraph($question['hint4']) ?> </p><br>
		<?php } if ($question['pa5'] != 'empty') { ?>
		<h3>POSSIBLE ANSWER FIVE:</h3><br><?php echo paragraph($question['pa5']) ?> </p><br>
		<h3>ANSWER:</h3><br><p><?php echo paragraph($question['answ5']) ?> </p><br>
		<?php } if ($question['hint5'] != 'empty') { ?>
		<h3>HINT:</h3><br><p><?php echo paragraph($question['hint5']) ?> </p><br>
		<?php } if ($question['pa6'] != 'empty') { ?>
		<h3>POSSIBLE ANSWER SIX:</h3><br><p><?php echo paragraph($question['pa6']) ?> </p><br>
		<h3>ANSWER:</h3><br><p><?php echo paragraph($question['answ6']) ?> </p><br>
		<?php } if ($question['hint6'] != 'empty') { ?>
		<h3>HINT:</h3><br><p><?php echo paragraph($question['hint6']) ?> </p><br>
		<?php } if ($question['pa7'] != 'empty') { ?>
		<h3>POSSIBLE ANSWER SEVEN:</h3><br><?php echo paragraph($question['pa7']) ?> </p><br>
		<h3>ANSWER:</h3><br><p><?php echo paragraph($question['answ7']) ?> </p><br>
		<?php } if ($question['hint7'] != 'empty') { ?>
		<h3>HINT:</h3><br><p><?php echo paragraph($question['hint7']) ?> </p><br>
		<?php } if ($question['pa8'] != 'empty') { ?>
		<h3>POSSIBLE ANSWER EIGHT:</h3><br><?php echo paragraph($question['pa8']) ?> </p><br>
		<h3>ANSWER:</h3><br><p><?php echo paragraph($question['answ8']) ?> </p><br>
		<?php } if ($question['hint8'] != 'empty') { ?>
		<h3>HINT:</h3><br><p><?php echo paragraph($question['hint8']) ?> </p><br>
		<?php } ?><br><br>
		
		</div>
		</div>
	<?php
	} 
	?>
	<div id="pagination">
	<?php
	$url = 'questionsAndAnswers.php';
	echo get_pagination_links($page, $totalPages, $url, '');
	?>
	</div>
	<?php
	}
	}
	
	} else {
		header("Location: ../classes.php");
		exit();
	}