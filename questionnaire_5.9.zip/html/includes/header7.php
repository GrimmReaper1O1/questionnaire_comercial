<?php
require '../../src/bootstrap.php';
if (isset($_SESSION['id'])) {
	if (isset($_GET['class'])) {
		$_SESSION['class'] = $_GET['class'];
		
	}
	
	
	?>
	<html>
	
	
		<head>
			<style>
		/* everything */
		a {color: white;}
	a:visited {color: white}
	a:hover {color: blue}
	a:active {color: yellow}
	body {
		color: white;
			background-color: rgb(16,13,217);
	}
	
	
	.fieldset2 {
	width: 50%;
	margin: 0 auto;
	border: none
}
	
	#banner {
		position: fixed;
		top: 17px;
		height: 50px;
		width:75px;
		z-index: 10;
	}
	#nav {
		width: 100%;
		height: 17px;
		size: 17px;
		position: fixed;
		top: 0;
		z-index: 10;
		background-color: rgb(16,13,217);	color: white;
	}
	#container, #name {
		margin: 0 auto;
	width: 100%
	
	}
	#bannerid {
		position: fixed;
		top: 17px;
		left: 0;
		width: 100%;
		z-index:10;
		background-color: rgb(16,13,217);
		height: 50px;
		border-bottom: 1px solid black;
		
	
	}
	#bname {
		color: white; 
	}
	
	#name {
		position:fixed;
		line-height: 20px;
		z-index:10;
		width: 100%;
			margin: 0 auto;
		text-align:center;
		margin: 0 auto;
	}
	.sideDiv {
	position:fixed;
	z-index: 9;
	top:16px;
	
	width: 7%;
	height: 100%;
	background-color: black;
	}
	#left {
	float: left;
	z-index: 9;
	right: 0px;
	}
	#right {
	float: right;
	left: 0px;
	z-index: 8;
	}
	#main {
		width: 100%;
		
	}
	#bottom {
	position: fixed;
	z-index: 7;
	bottom: 0px;
	width: 100%;

}
#pagination {
	width: 100%;
	text-align: center;


}
.marginAuto {
	margin: 0 auto;
}
#divSmallField {
width: 100%
}

/* fix when I know more not centered */
.fieldset1 {
	padding-left: 35%;
	padding-right: 35%;
	border: 0px solid;
	
}
.right-text-align {
	text-align: right;
}
.centeredText {
	text-align: center;
}
#pagination {
	position: fixed;
	z-index: 3;
	bottom: 0;
	width: 100%;
	text-align: center;
	background-color: rgb(16,13,217);
}

div.settings5 {
	width: 30%;
	display: inline-flex;
	flex-flow: column wrap;
	flex-wrap: wrap;
	justify-content: space-between;
	margin 2;
	padding-bottom: 5px;
}
div.settings6 {
	width: 65%;
	display: inline-flex;
	flex-flow: column wrap;
	flex-wrap: wrap;
	justify-content: space-between;
	margin 2;
	padding-bottom: 5px;
}
.margin50 {
	width: 50%;
	margin: 0 auto;
}
.margin25 {
	width: 25%;
	margin: 0 auto;
}
.submit-middle {
	margin: 0 auto;
	width: 20%;
}
.margin30 {
	width: 30%;
	margin: 0 auto;
}
.copyright {
	z-index: 9;
	position: fixed;
	bottom: 0;
	text-align: right;
	width: 80%;
	margin: 0 auto;
}
p>a {
	color: black;
}
	</style>
	</head>
	<div id="bannerid">
	<img src="../images/BIRD.png" id="banner"  />
	<div id="name">
	<h1 id="bname">QUESTIONNAIRE</h1>
</div>
	<?php 
		?>
		 <nav id="nav"><a href="../classes.php?reset=yes">Classes</a>  | <a href="../../bioOne.php">Results</a>  
		<?php
		echo ' | <a href="library.php">Students Library</a> '; 
	?>	
		| <a href="../changeInfo.php">Settings</a> | <a href="contactUs.php">Contact Us</a>
		<?PHP 
		if ($_SESSION['administrator']['admin'] == 1) {
			if ($_SESSION['administrator']['root'] == 1) {
			echo ' | <a href="../admin/adminLibrary/upload_pdf.php">Upload to library</a>';
			}
			echo " | <a href='../admin/userAdmin/set_administrator_options.php'>Administer users library and classes</a>" . 
			" | <a href='../admin/classes.php?reset=yes'>Administer classes</a>";} 
			?> 
			| <a href="../logout.php">Sign Out</a> </nav></div>
    <br>
    <br>
    <br>
	<div id="container">
	<div class="sideDiv" id="left"> </div>

<div class="sideDiv" id="right"> </div>	 <br>
		<br>
		<br>
		<?php
		}
		?>