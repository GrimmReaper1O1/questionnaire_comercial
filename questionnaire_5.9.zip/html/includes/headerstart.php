<?php
require '../src/bootstrap.php';
if (isset($_SESSION['id'])) {
if (isset($_GET['class'])) {
	$_SESSION['class'] = $_GET['class'];
	
}
if (isset($_GET['unset'])) {
	unset($_SESSION['class']);
}
 if (!isset($_SESSION['administrator'])) {
$_SESSION['administrator'] = $cms->getMember()->selectAdminViaUserId($_SESSION['id']);
 }


print_r($_SESSION['administrator']);
?>
<html>
	<body>
		<head>
		<meta http-equiv=”expires” content=”-1” />
	<meta http-equiv="Content-Type" 
      content="text/html; charset=utf-8">
	  <meta http-equiv="Content-Type" 
      content="application/javascript; charset=utf-8">
	<link href="css/styleSheet.css">
	
<style>
/* everything */
a {color: white;}
a:visited {color: white;}
a:hover {color: blue;}
a:active {color: yellow;}
body {
	color: white;
		background-color: rgb(16,13,217);
}




#banner {
	position: fixed;
	top: 17px;
	height: 50px;
	width:75px;
	z-index: 10;
}
#nav {
	width: 100%;
	height: 17px;
	size: 17px;
	position: fixed;
	top: 0;
	z-index: 10;
	background-color: rgb(16,13,217);	
	color: white;
}
#container, #name {
	margin: 0 auto;
width: 100%;

}
.margin50 {
	width: 55%;
	margin: 0 auto;

}
#bannerid {
	position: fixed;
	top: 17px;
	left: 0;
	width: 100%;
	z-index:10;
	background-color: rgb(16,13,217);
	height: 50px;
	border-bottom: 1px solid black;
	

}
#bname {
	color: white; 
}

#name {
	position:fixed;
	line-height: 20px;
	z-index:10;
	width: 100%;
		margin: 0 auto;
	text-align:center;
	margin: 0 auto;
}
.sideDiv {
position:fixed;
z-index: 9;
top:16px;

width: 7%;
height: 100%;
background-color: black;
}
#left {
float: left;
z-index: 9;
right: 0px;
}
#right {
float: right;
left: 0px;
z-index: 8;
}
#main {
	width: 100%;
	margin: auto auto;
}
.headings {

	text-align: center;
}
.letters {
	text-align: center;
}
#bottom {
	position: fixed;
	z-index: 7;
	bottom: 0px;
	width: 100%;
	text-align: center;

}
#pagination {
	position: fixed;
	width: 100%;
	text-align: center;
	z-index: 4;

	bottom: 0;
	background-color: rgb(16,13,217);

}
.mainbody {
	width: 100%;
}
.margin80 {
	width: 80%;
	margin: 0 auto;
}
.margin25 {
	width: 25%;
	margin: 0 auto;
}

.copyright {
	z-index: 9;
	position: fixed;
	bottom: 0;
	text-align: right;
	width: 80%;
	margin: 0 auto;
}
.centeredText {
	text-align: center;
}
.marginAuto {
	margin: 0 auto;
}
div.settings10 {
	width: 20%;
    display: inline-flex;
	flex-flow: wrap;
    justify-content: center;
    flex-wrap: wrap;
	
}
</style>
</head>
    <body>
   
	<div id="bannerid">
	<img src="images/BIRD.png" id="banner"  />
	<div id="name">
	<h1 id="bname">QUESTIONNAIRE</h1>
</div>
	<nav id="nav">
		
	<?php 
	?>
	<a href="classes.php?reset=yes">Classes</a> | <a href="bioOne.php">Results</a> | 
	<?php
		
	if ($_SESSION['administrator']['admin'] != 1) { 
	echo ' | <a href="library/library.php">Library</a> '; } 
	if ($_SESSION['administrator']['admin'] == 1) { echo '| <a href="library/library.php">Students Library</a> '; } 
	?>
	| <a href="enterMathematics.php">Mathematics</a> | <a href="changeInfo.php">Settings</a> | <a href="contactUs.php">Contact Us</a>
	<?PHP 
	if ($_SESSION['administrator']['admin'] == 1) {
		if ($_SESSION['administrator']['root'] == 1) {
		echo ' | <a href="admin/adminLibrary/upload_pdf.php">Upload to library</a>';
		}
		echo " | <a href='admin/userAdmin/set_administrator_options.php'>Administer users, library, and classes</a>" . 
		" | <a href='admin/classes.php'>Administer classes</a>";} 
		?> 
		| <a href="logout.php">Sign Out</a> </nav></div>
    <br>
    <br>
    <br>
	<div id="container">
	<div class="sideDiv" id="left"> </div>

<div class="sideDiv" id="right"> </div>	

<?php
} else {
	header('login.php');
	exit();
}