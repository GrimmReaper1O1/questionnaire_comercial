<?php ?><p>
<footer class="marginAuto">Copyright &copy; 2023</footer>
</p>
<?php 
