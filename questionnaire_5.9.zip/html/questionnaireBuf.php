<?php 
include "../src/bootstrap.php";

$page = $_GET['page'] ?? 1;

$_SESSION['countedIds'] = $cms->getQuestions()->countQuestionIds();
	
$_SESSION['totalPages'] = ceil($_SESSION['countedIds']['count'] / $_SESSION['numberOfQuestionsOnPage']);


?>
<!DOCTYPE html>
<html>
<body style="background-color: blue;">
    <?= $_SESSION['version'] ?>
<script type='module'>

        function openDB(storeName, databaseName){
            var dbRequest = indexedDB.open(databaseName);
    
          dbRequest.onupgradeneeded = function(event) {
            var database    = event.target.result;
            var data = {};
            var objectStore = {};
            <?php 
            for ($i = 1 ; $i <= $_SESSION['totalPages'] ; $i++) { 
                ?>
            data = "QuestionnaireSubject<?= $_SESSION['subject'] ?>Class<?= $_SESSION['class'] ?>Page";
            data += <?= $i ?>;
             objectStore['<?= $i ?>'] = database.createObjectStore(data, {keypath: 'id'});
           
          
            objectStore['<?= $i ?>'].onsuccess = function (event) {
            console.log('store created successfully');
           
          }
          
      
          objectStore['<?= $i ?>'].onerror = function (event) {
              
            console.log('the store failed to be created.');
          }
           
          <?php 
        } 
        ?>
        
          };
    
          dbRequest.onsuccess = function(event) {
            var db = event.target.result;
            db.close();
          }
    
          dbRequest.onerror = function(event) {
              reject(Error('Error text'));
            };
    
          };

    import {deleteDB, loadFromIndexedDB, updateDelDB, saveToIndexedDB, createStoreDB} from './src/loadMod.js';
var databaseName = "QuestionnaireClass<?= $_SESSION['class'] ?>";
var key = "qS<?= $_SESSION['subject'] ?>C<?= $_SESSION['class'] ?>P<?= $page ?? 1?>";
var storeName = "QuestionnaireSubject<?= $_SESSION['subject'] ?>Class<?= $_SESSION['class'] ?>Page<?= $page ?? 1?>"

var version = localStorage.getItem("QuestionnaireSubject<?= $_SESSION['subject'] ?>Class<?= $_SESSION['class'] ?>");

console.log(version);
var test = 'on';
var page = <?= $page ?? 1 ?>;
if ( page == 1 && test == <?php if (isset($_SESSION['gate'])) {echo "'on'";} else {echo "'off'";} ?>) {
  sessionStorage.clear();
  var qr = {};
  for (let i = 0; i < <?= $_SESSION['numberOfQuestionsOnPage'] ?> ; i++) {
	   
	    qr[i] = 0;
	   
   }			
 
   var string = JSON.stringify(qr);
   console.log(string);
   sessionStorage.setItem('qr', string);
  <?php
  unset($_SESSION['class'.$_SESSION['class']]['subject'.$_SESSION['subject']]);
  unset($_SESSION['gate']);
 ?>
}
if (version != <?= $_SESSION['version'] ?? 1 ?>) {
    localStorage.setItem("QuestionnaireSubject<?= $_SESSION['subject'] ?>Class<?= $_SESSION['class'] ?>",  "<?= $_SESSION['version'] ?? 1?>");
console.log(version); console.log(<?= $_SESSION['version'] ?>)
var test = 'on';
var page = <?= $page ?? 1 ?>;
if ( page == 1 && test == <?php if (isset($_SESSION['gate'])) {echo "'on'";} else {echo "'off'";} ?>) {
  sessionStorage.clear();
  var qr = {};
  for (let i = 0; i < <?= $_SESSION['numberOfQuestionsOnPage'] ?> ; i++) {
	   
	    qr[i] = 0;
	   
   }			
 
   var string = JSON.stringify(qr);
   console.log(string);
   sessionStorage.setItem('qr', string);
  <?php
  unset($_SESSION['class'.$_SESSION['class']]['subject'.$_SESSION['subject']]);
  unset($_SESSION['gate']);
 ?>
} 

deleteDB(databaseName);



sessionStorage.setItem('start', 'on');

openDB(storeName, databaseName, version)

window.location.replace('/questionnaire.php?reset=yes&page=<?= $page ?? 1 ?>');

} else {
  
  var test = 'on';
var page = <?= $page ?? 1 ?>;
if ( page == 1 && test == <?php if (isset($_SESSION['gate'])) {echo "'on'";} else {echo "'off'";} ?>) {
  sessionStorage.clear();
  var qr = {};
  for (let i = 0; i < <?= $_SESSION['numberOfQuestionsOnPage'] ?> ; i++) {
	   
	    qr[i] = 0;
	   
   }			

   var string = JSON.stringify(qr);
   console.log(string);
   sessionStorage.setItem('qr', string);
  <?php
  unset($_SESSION['class'.$_SESSION['class']]['subject'.$_SESSION['subject']]);
  unset($_SESSION['gate']);
 ?>
}
loadFromIndexedDB(storeName, key, databaseName).then(function (resolve) {
    let arry = resolve.id;
arry = JSON.parse(arry);
console.log(arry);



if (arry.fast == 'on') {
   
    sessionStorage.setItem('start', 'on');

    window.location.replace('/questionnaire.php?newpg=yes&fast=yes&page=<?= $page ?? 1 ?>');
} else {
      
        sessionStorage.setItem('start', 'on');

    window.location.replace('/questionnaire.php?reset=yes&page=<?= $page ?? 1 ?>');
}}).catch(function (error){

  sessionStorage.setItem('start', 'on');

    window.location.replace('/questionnaire.php?reset=yes&page=<?= $page ?? 1 ?>');
});
}
 


</script>
</body>
</html>