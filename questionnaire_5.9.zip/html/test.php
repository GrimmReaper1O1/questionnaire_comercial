<?php
include "../src/bootstrap.php";
$_SESSION['class'] = 10007;
$_SESSION['subject'] = 1;
$description = "this is a question";
$question = "this is the description";
$pa1 = "possible answer ";
 $pa2 = "possible answer "; 
  $pa3 = "possible answer ";
   $pa4 = "possible answer ";
    $pa5 = "possible answer ";
     $pa6 = "possible answer ";
      $pa7 = "possible answer ";
       $pa8 = "possible answer ";
$answ1 = "answer ";
 $answ2 = "answer ";
  $answ3 = "answer ";
   $answ4 = "answer ";
    $answ5 = "answer ";
     $answ6 = "answer ";
      $answ7 = "answer ";
       $answ8 = "answer ";
        
         

	$hint1 = "hint ";
     $hint2 = "hint ";
      $hint3 = "hint ";
       $hint4 = "hint ";
        $hint5 = "hint ";
         $hint6 = "hint ";
          $hint7 = "hint ";
           $hint8 = "hint ";
for ($i = 1; $i < 40; $i++) {
    $cms->getQuestions()->insertQuestionDescription($description.$i, floatval($i));
    $row = $cms->getQuestions()->selectQuestionViaDescription($description.$i);
    $counter = 0;
    for ($c = 1; $c < 6; $c++) {
$counter = intval($counter);
        $counter++;
$answ = 'answ';
$correctAnsw = $answ . strval($counter);
    try{   $result = $cms->getQuestions()->insertQuestion($question.$c, $pa1.$c, $pa2.$c, $pa3.$c, $pa4.$c, $pa5.$c, $pa6.$c, $pa7.$c, $pa8.$c,
	$answ1.$c, $answ2.$c, $answ3.$c, $answ4.$c, $answ5.$c, $answ6.$c, $answ7.$c, $answ8.$c, $correctAnsw, $row['question_id'],
	$hint1.$c, $hint2.$c, $hint3.$c, $hint4.$c, $hint5.$c, $hint6.$c, $hint7.$c, $hint8.$c); 
        echo "yay!<br>";
        echo "yep!<br><br>";
} catch(Exception $e) {
        echo "wonky<br>";
    }
    }




}
