
<?php
include "../../includes/header5.php";

if ($_SESSION['administrator']['admin'] == 1) {
	?>
	<div id="main" class="main">

		<div class="heightHeader">
		</div>
		<div class="mainbody">
			<br>
			<br>
			<br>
			<div id="mainBody" class="centeredText">
				<h2>  <?php if ($_SESSION['administrator']['admin'] == 1) { ?>
					<a href="../adminLibrary/adminLibrary.php?unset=yes">Admin Library</a><br>

				<?php }	?>
				<?php if ($_SESSION['administrator']['admin'] == 10) { ?>
					<a href="allow_entry_to_users.php">Allow entry to users</a><br>
				<?php }?>
				<?php if ($_SESSION['administrator']['admin'] == 1) { ?>
					<a href="../chooseProfile.php">Choose style to alter or delete</a><br>

				<?php }   ?>
				<?php if ($_SESSION['administrator']['root'] == 1 || $_SESSION['administrator']['can_delete_all'] == 10) { ?>

					<a href="createAdministrator.php">Create administrative account</a><br>
				<?php } ?>
				<?php if ($_SESSION['administrator']['admin'] == 1 && $_SESSION['administrator']['viewer'] == 0) { ?>
					<a href="create_new_class.php">Create new class</a><br>
					<a href="../colourChangePage.php?reset=yes">Change style of page</a><br>
				<?php }   ?>
				<?php if ($_SESSION['administrator']['admin'] == 10) { ?>
					<a href="create_user_and_assign_class.php">Create user and assign class</a><br>
				<?php }   ?>
				<?php if ($_SESSION['administrator']['can_remove_class'] == 10 || $_SESSION['administrator']['root'] == 10) { ?>
					<a href="delete_class.php">Delete class</a><br>

				<?php }   ?>
				<?php if ($_SESSION['administrator']['admin'] == 1 ) { ?>

					<a href="../adminLibrary/delete_document.php?unset=yes">Delete document</a><br>

				<?php }   ?>
				<?php if ($_SESSION['administrator']['admin'] == 10) { ?>

					<a href="delete_subject_from_class.php">Delete subject from class</a><br>
				<?php }   ?>
				<?php if ($_SESSION['administrator']['admin'] == 10) { ?>
					<a href="delete_user_from_class.php">Delete user</a><br>
				<?php }   ?>

				<?php if ($_SESSION['administrator']['admin'] == 10) { ?>


					<a href="search_for_user.php">Search for user in classes</a><br>


				<?php }
				if ($_SESSION['administrator']['admin'] == 1) { ?>
					<a href="show_all_administrators.php">Show all administrators</a><br>
				<?php }   ?>

				<?php if ($_SESSION['administrator']['root'] == 1) { ?>

				<?php }   ?>
				<?php if ($_SESSION['administrator']['root'] == 1 || $_SESSION['administrator']['viewer'] == 1) { ?>
					<a href="search_via_email.php">Search via name or email</a><br>

					<?php
				}
				if ($_SESSION['administrator']['admin'] == 1) { ?>

					<a href="../adminLibrary/upload_pdf.php">Upload a pdf, docx, or doc file to the library</a><br>
				<?php }   ?>


				<?php if ($_SESSION['administrator']['admin'] == 1) { ?>

				<?php }   ?>
				<?php if ($_SESSION['administrator']['admin'] == 1) { ?>


				<?php }   ?>

			</h2>
		</br>
		<div style="height: 1200px;">
		</div>
	</div>
</div>
</div>

<?php
if (isset($_SESSION['layoutOfSite']['enableMovingBars'])) {
	if ($_SESSION['layoutOfSite']['enableMovingBars'] == 1) {

		?>
		<div id="rightLowerSidebar" class="rightLowerSidebar">

		</div>

		<?php

	}
}

?>
</div>
</div>
<div class="copyright">
	<?php
	include "../../includes/footer.php";
	?>
</div>
<?php
} else {
	header("Location: ../../classes.php");
	exit();
}
?>

<div>
	<?php include '../../includes/footer5.php'; ?>
</div>
</body>
</html>
