<?php
	include "../src/bootstrap.php";
	$start = microtime(true);
	$_SESSION['page'] = 1;
	$limit = 4;
	$_SESSION['class'] = 20014;
	$_SESSION['subject'] = 2;
	if (isset($_GET['unset'])) {
	unset($_SESSION['chosenNumbers']);
	unset($_SESSION['rowAndCounter']);
	}
	
	
	
	
	
	// might as well select all question Ids from subject and class and store in session to remove the next request and utilize via sorting and for loop
	
	//$questionDesc = $cms->getQuestions()->selectAllQuestionsFromSubjectPagination($_SESSION['page'], $limit);
	if (!isset($_SESSION['questionDesc'])) {
	$questionDesc = $cms->getQuestions()->selectAllQuestionsFromSubject();
	$_SESSION['questionDesc'] = $questionDesc;
	$_SESSION['rowAndCounter']['counter'] = count($_SESSION['questionDesc'][1]);
	}
	echo 'questionIDS' . '<br>';
	
	print_r($_SESSION['questionDesc'][1]);
	$questionIdsArray = $_SESSION['questionDesc'][1];
	echo "<br><br>";
	// might as well select all question ids instead here too.
	$array = $cms->getQuestions()->selectAllQuestionInformationIncludingId( 20014);
	
	if (!isset($_SESSION['sortedIds'])) {
	$sortedIds = $cms->getQuestions()->sortArrayViaQuestionIdsArray($_SESSION['questionDesc'][1], $array);
	$_SESSION['sortedIds'] = $sortedIds;
	}
	
	
	
	
	echo "final test";
	
	
	
	echo "all questions" . '<br>';
	print_r($array);
	// $sorted = $cms->getQuestions()->sortArrayViaQuestionIdsArraySwitch($questionDesc[1], $array);
	$line = '';	

	echo "<br><br>";
	
	
	echo "<br><br>";
	echo "sorted question_id id array" . '<br>';
	print_r($_SESSION['sortedIds']);
	$counted = count($_SESSION['sortedIds']);
	echo $counted;
	for ($c = 0 ; $c < $counted ; $c++) {
	$_SESSION['countedNumberOfQuestionsPerQuestion']['a' . $c]	= count($_SESSION['sortedIds']['a' . $c]);
	
	}
	
	$countedQuestionIds = $_SESSION['rowAndCounter']['counter'];
	echo "<br><br>";
	echo "question id etc<br>";
	print_r($_SESSION['questionDesc'][1]);
	print_r($_SESSION['countedNumberOfQuestionsPerQuestion']);
	//echo $_SESSION['counts']['count1'];

	if (!isset($wowser)) {
	$cnArray = selectRandomNumberNotInArrayAllAtOnce($_SESSION['questionDesc'][1], $_SESSION['countedNumberOfQuestionsPerQuestion']);
	
	
	
	 // $questionInformationArray = $cms->getQuestions()->selectQuestionAllQuestions($questionDesc[1], $_SESSION['lastNumbers'], $cnArray, $_SESSION['count'], $sortedIds);
	echo "<br><br>";
	echo "count Array<br>";
	//print_r($_SESSION['count']);
		echo "<br><br>";
	echo "chosen number Array<br>";
	
	
	print_r($cnArray);
	echo "<br><br>";
	//echo $_SESSION['counts']['count1'];
	//echo $_SESSION['counts']['count2'];
	echo "<br><br>" . $_SESSION['a' . 0]['test'];
	echo "<br><br>" . $_SESSION['a' . 1]['test'];
	echo "<br><br>" . $_SESSION['a' . 2]['test'];
	echo "<br><br>" . $_SESSION['a' . 3]['test'];
	}
	$end = microtime(true);
	echo ($end - $start);
	print_r($_SESSION['countedNumberOfQuestionsPerQuestion']);
	//print_r($_SESSION['counts']['count1']);