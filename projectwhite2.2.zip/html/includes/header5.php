<?php
require '../../../src/bootstrap.php';
if (isset($_GET['class'])) {
	$_SESSION['class'] = $_GET['class'];
	
}
$administrator = $cms->getMember()->selectAdminViaUserId($_SESSION['id']);


?>
<html>
<style>
aside {
  display: inline-block,
  float: left,
  width: 10%,
}
#main {
  display: inline-block,
  float: right,
  width: 88%,
}
</style>

    <head></head>
    <body>
    <img src="banner">'
	<?php 
	?>
     <nav><a href="../../classes.php?unset=yes">Classes</a> 
	<?php 
	if (isset($_SESSION['class'])) {
	if (isset($_SESSION['class']) && $administrator['admin'] != 1) { 
	echo '| <a href="../../library/library.php">Library</a> '; } 
	if ($administrator['admin'] == 1) { echo '| <a href="../../library/library.php">Students Library</a> '; } 
	} ?>
	| <a href="../../changeInfo.php">Settings</a> | <a href="contactUs.php">Contact Us</a>
	<?PHP 
	if ($administrator['admin'] == 1) {
		if ($administrator['root'] == 1) {
		echo ' | <a href="../adminLibrary/upload_pdf.php">Upload to library</a>';
		}
		echo " | <a href='../userAdmin/set_administrator_options.php'>Administer users library and classes</a>" . 
		" | <a href='../classes.php?reset=yes'>Administer classes</a>";} 
		?> 
		| <a href="../../logout.php">Sign Out</a> </nav>  <br>
    <br>
    <br>
