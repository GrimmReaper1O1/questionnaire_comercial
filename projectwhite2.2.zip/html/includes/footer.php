<?php ?>
<footer>copywrite 2023</footer>
</body>
</html>
<?php 
