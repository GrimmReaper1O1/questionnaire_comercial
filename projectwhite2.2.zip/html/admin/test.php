<?php
include "../includes/header4.php";
$zero = 0;
$one = 1;
$two = 2;
$three = 3;

$_SESSION['stuff'][$three]['info'] = "information three";
$_SESSION['stuff'][$two]['info'] = "information two";
$_SESSION['stuff'][$one]['info'] = "information one";
$_SESSION['stuff'][$zero]['info'] = "information zero";

foreach($_SESSION['stuff'] as $other)  {
	echo $other['info'];
	
}