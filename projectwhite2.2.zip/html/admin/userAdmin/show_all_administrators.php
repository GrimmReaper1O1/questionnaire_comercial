<?php
include "../../includes/header5.php";
if ($administrator['admin'] == 1) {
// include administrative function
$limit = 20;
$page = $_GET['page'] ?? 1;

$showAllAdminPersonel = $cms->getMember()->getAllAdministrators($page, $limit);
		
$totalResults = $showAllAdminPersonel[0]['count'];
	

$totalPages = ceil($totalResults / $limit);

        if ($showAllAdminPersonel === false) {
            $error = "There was an error in the attempt to show all administrators. Please try again.";
        } else {

	foreach ($showAllAdminPersonel[1] as $row) {
		?>
		<h4>
		FULL NAME: <?= $row['concat_full_name'] ?><br>
		EMAIL: <?= $row['email'] ?><br>
		PHONE NUMBER: <?= $row['phone_number'] ?><br>	
		CREATED BY ADMINISTRATOR: <?= $row['creator_name'] ?><br>
		ADMINISTRATOR CREATED ON: <?php echo date('d-m-y h:i a', $row['timestamp']); ?><br>
		SUPER USER PRIVILEGES:<?php if($row['all_access_administrator'] == 1) { echo "YES!"; } else { echo "NO!"; }

		if ($administrator['root'] == 1) {
		?><br>
		<a href="delete_admin.php?id=<?= $row['administrator_id'] ?>">DELETE ADMINISTRATOR</a>
		<?php
		} 
		?>
		</h4>

	<?php
	}

echo "-";
for ($i = 1; $i <= $totalPages; $i++) {
    echo '<a href="show_all_administrators.php?page=' . $i . '">' . $i . '</a> - ';
}
}

} else {
    header("Location: how_dare_you.php");
    exit();
}