<?php
$currentPath = dirname(__DIR__); 
include "includes/header3.php";
?>
<div class="heightHeader"></div>
<div class="mainBody">
<div class="centeredText">
    <div style="height: 50px;"></div>
<a href="addition.php?reset=yes">Addition</a><br>
<a href="division.php?reset=yes">Division</a><br>
<a href="multiplication.php?reset=yes">Multiplication</a><br>
<a href="subtraction.php?reset=yes">Subtraction</a><br>
<div class="addHeight"></div><div class="addHeight"></div>
</div>
</div>
</div>
<?php 
include "includes/footer2.php";
?>
</body>
</html>