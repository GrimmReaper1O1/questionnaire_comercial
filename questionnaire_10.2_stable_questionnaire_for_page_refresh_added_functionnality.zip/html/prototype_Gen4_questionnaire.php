<?php
include "includes/header3.php";
if (isset($_SESSION['id'])) {

	//prototype gen 4

	if (isset($_GET['reset'])) {
		unset($_SESSION['allQuestions']);//
		unset($_SESSION['questionDesc']);//
		unset($_SESSION['sortedIds']);//
		unset($_SESSION['countedNumberOfQuestionsPerQuestion']);//
		unset($_SESSION['pageQuestionIds']);//
		unset($_SESSION['godly']);//
		unset($_SESSION['info']);//
		unset($_SESSION['numeral']);//
		unset($_SESSION['runs']);//
		unset($_SESSION['numberOfQuestionsOnPage']);
		unset($_SESSION['setFirst']);//
		unset($_SESSION['questionLimitNumber']);//
		unset($_SESSION['qr']);
		unset($_SESSION['pagesIds']);
		unset($_SESSION['loopNumber']);//
		unset($_SESSION['page']);
		unset($_SESSION['countOfPageQuestions']);//
		unset($_SESSION['choiceArray']);
		unset($_SESSION['numeralOfRem']);
		if (!isset($_SESSION['countOfPageQuestions'])) {
			$questionPossition = $cms->getQuestions()->selectSubjectViaTableIdAndClassId();

			$_SESSION['numberOfQuestionsOnPage'] = $questionPossition['number_of_questions'];
			$numberOfQuestionsOnPage = $questionPossition['number_of_questions'];
			$_SESSION['numeralOfRem'] = $questionPossition['number_of_removal'];
			$numeralOfRem = $questionPossition['number_of_removal'];
		} else {
			$numeralOfRem = $_SESSION['number_of_removal'];
			$numberOfQuestionsOnPage = $_SESSION['numberOfQuestionsOnPage'];
		}


	}

	if (isset($_GET['unset'])) {

		unset($_SESSION['countedNumberOfQuestionsPerQuestion']);
		unset($_SESSION['sortedIds']);
		unset($_SESSION['loopNumber']);
		unset($_SESSION['questionDesc']);

		//unset($_SESSION['countOfPageQuestions']);
	}
	if (isset($_GET['newpg'])) {
		unset($_SESSION['godly']);
		unset($_SESSION['countedNumberOfQuestionsPerQuestion']);
		unset($_SESSION['pageQuestionIds']);
		unset($_SESSION['sortedIds']);
		unset($_SESSION['questionLimitNumber']);
		unset($_SESSION['qr']);
		unset($_SESSION['info']);
		unset($_SESSION['runs']);
		unset($_SESSION['loopNumber']);
		unset($_SESSION['countOfPageQuestions']);//
		unset($_SESSION['numeral']);
		unset($_SESSION['setFirst']);
		unset($_SESSION['page']);
		unset($_SESSION['questionDesc']);


	}

	$page = $_GET['page'] ?? 1;
	if (!isset($_SESSION['page'])) {
		$_SESSION['page'] = $page;

	} else {
		$page = $_SESSION['page'];

	}


	$start = microtime(true);








	if (isset($_POST['submit2'])) {
		for($i = 0; $i < count($_SESSION['info']); $i++) {

			for($c = 1; $c <= 8; $c++) {


				if (isset($_POST[$i . 'a' . $c])) {
					echo "<b>Message:</b><br>";
					echo "<p>" . paragraph($_SESSION[$i .'answ' . $c]) . "</p><br>";
					echo "<b>Quesiton:</b><br>";
					echo "<p>" . paragraph($_SESSION[$i .'question']) . "</p><br>";
					echo "<b>Answer chosen:</b><br>";
					echo "<p>" . paragraph($_SESSION[$i .'pa' . $c]) . "</p><br>";
					echo "<b>Hint given:</b><br>";
					if($_SESSION[$i .'hint' . $c] !== "empty") {
						echo "<p>" . paragraph($_SESSION[$i .'hint' . $c]) . "</p><br><br>";
					}
					if ($_SESSION[$i . 'correct'] == 'answ' . $c && isset($_POST[$i . 'a' . $c])) {
						$_SESSION['qr'][$i]++;		// goes above
					}
				}
			}
		}
		?>
		<form action="questionnaire.php?refresh=yes" method="post">
			<input type="submit" value="NEXT SET OF QUESTIONS!">
		</form>
		<?php
	}


	if (isset($_GET['reset']) || isset($_GET['page']) || isset($_GET['refresh'])) {
		if (!isset($_SESSSION['godly'])) {
			if (!isset($numeralOfRem)) {
				$numeralOfRem = $_SESSION['numeralOfRem'];
				$numberOfQuestionsOnPage = $_SESSION['numberOfQuestionsOnPage'];

			}
			if (!isset($_SESSION['countedNumberOfQuestionsPerQuestion'])) { echo "im doing this!";
				// get count
				if (!isset($_SESSION['countedIds'])) {
					$_SESSION['countedIds'] = $cms->getQuestions()->countQuestionIds();
					$_SESSION['totalPages'] = ceil($_SESSION['countedIds']['count'] / $numberOfQuestionsOnPage);
				} else {
					$countedIds = $_SESSION['countedIds'];
				}
				if (isset($_GET['newpg']) || isset($_GET['reset'])) {
					$questionIds = $cms->getQuestions()->selectQuestionIdsPagination($page, $numberOfQuestionsOnPage);
				}

				if (isset($questionIds)) {
					$pageQuestionIds = $cms->getQuestions()->selectQuestionInformationIdFromQuestionIds($questionIds[1]);
					$_SESSION['countOfPageQuestions'] = count($pageQuestionIds);

				}

				if(!isset($_SESSION['sortedIds'])) {

					$sortedIds = $cms->getQuestions()->sortArrayViaQuestionIdsArray($questionIds[1], $pageQuestionIds);

					$_SESSION['sortedIds'] = $sortedIds;
					$pagesIds = $sortedIds;

				} 	else {
					$pagesIds = $_SESSION['sortedIds'];
				}

				if ($_SESSION['sortedIds']['a' . 0] != 'empty') {








					$counted = count($pagesIds);


					for ($i = 0 ; $i < $counted ; $i++ ) {
						$countedNumberOfQuestionsPerQuestion['a' . $i] = count($pagesIds['a' . $i]);

					}


					$_SESSION['countedNumberOfQuestionsPerQuestion'] = $countedNumberOfQuestionsPerQuestion;
					$countedNumberOfQuestionsPerQuestion = $_SESSION['countedNumberOfQuestionsPerQuestion'];
					$pagesIds = $_SESSION['sortedIds'];
				}
			} else {
				$countedNumberOfQuestionsPerQuestion = $_SESSION['countedNumberOfQuestionsPerQuestion'];
				$pagesIds = $_SESSION['sortedIds'];
			}



			if ($_SESSION['sortedIds']['a' . 0] != 'empty') {


				if (!isset($_SESSION['loopNumber'])) {
					$loopNumber = count($pagesIds);
					$_SESSION['loopNumber'] = $loopNumber;

				}	else {
					$loopNumber = $_SESSION['loopNumber']; }
				}
			}
			$totalPages = $_SESSION['totalPages'];


			if ($_SESSION['sortedIds']['a' . 0] != 'empty') {

				$info = $cms->getQuestions()->selectQuestionAllAtOnceProto($pagesIds, $countedNumberOfQuestionsPerQuestion);


				echo "<br>counted number of questions per question<br>";
				print_r($countedNumberOfQuestionsPerQuestion);?>
				<form action="questionnaire.php" method="POST">
					<?php





					if (isset($info)) {

						for ($c = 0 ; $c < count($info) ; $c++) {

							if (!isset($_SESSION['qr'][$c])) {
								$_SESSION['qr'][$c] = 0;
							}

							if (isset($info['a' . 0]['question'])) { ?>
								<?php
								echo "numeral of rem " . $_SESSION['qr'][$c] . "<br>";
								if ($_SESSION['qr'][$c] < $numeralOfRem) {


									echo "<p>" . $info['a'.$c]['question'] . "</p>" ?><br>

									<?php
									$_SESSION[$c . 'question'] = $info['a' . $c]['question'];
									$_SESSION[$c . 'correct'] = $info['a' . $c]['correct'];

									for($i = 1; $i <= 8; $i++) {

										if ($info['a' . $c]['pa' . $i] != 'empty') {
											?>

											<input type="radio" name="<?= $c . "a" . $i ?>"> <p>
												<?php
												echo paragraph($info['a' . $c]['pa' . $i]); ?></p>

												<?php
											}
											if ($info['a' . $c]['pa' . $i] != 'empty') {
												if ($info['a' .$c]['pa' . $i] != 'empty') { echo paragraph($info['a' . $c]['hint' . $i]); } ?></p>
												<?php
												$_SESSION[$c .'answ' . $i] = $info['a' . $c]['answ' . $i];
												$_SESSION[$c . 'pa' . $i] = $info['a' . $c]['pa' . $i];
												$_SESSION[$c . 'hint' . $i] = $info['a' . $c]['hint' . $i];

											}
										}
									}






								} else {

									echo "There is no question information assigned to question ID:"  ;

								}?><br><br> <br><br><br><?php
							}	?> <br><br>
							<input type="submit" value="NEXT GROUP OF QUESTIONS" name="submit2">
						</form>
						<form action="questionnaire.php?newpg=yes&page=<?= $_SESSION['page'] ?>" method="POST">
							<input type="submit" value="RESET PAGE!">
						</from> <?php
						for($i = 1; $i <= $totalPages; $i++){
							?>
							<a href="questionnaire.php?newpg=yes&page=<?= $i ?>"><?= $i ?>-</a>
							<?php
						}

					}
				} else {
					echo "<h1>YOU MAY NOT HAVE A SINGLE QUESTION SET THAT IS EMPTY IN THE LAST PAGE NOR MAY YOU HAVE";
					echo " ALL SETS EMPTY ON ANY PAGE. YOUR HEAD ADMINISTRATOR SHOULD NOT MAKE ANY CLASS LIVE WITHOUT";
					echo " ALL QUESITONS WITH AT LEAST ONE ENTRY. THIS CLASS SHOULD NOT BE LIVE. TELL YOUR ADMINISTRATOR. <h1>";
				}
				$end = microtime(true);
				echo ($end - $start);

			}
		}
		include "includes/footer3.php";
		?>

	</body>
	</html>
