<?php
include "includes/header3b.php";
if (isset($_SESSION['id'])) {



	?>

	<div id="main" class="main">
		<div class="mainbody">

			<div class="heightHeader">
			</div>

			<div style="height: 200px;">
			</div>

			<?php



			if (isset($_GET['reset'])) {
				
				unset($_SESSION['allQuestions']);//
				unset($_SESSION['questionDesc']);//
				unset($_SESSION['sortedIds']);//
				unset($_SESSION['countedNumberOfQuestionsPerQuestion']);//
				unset($_SESSION['pageQuestionIds']);//
				unset($_SESSION['fast']);//
				unset($_SESSION['info']);//
				unset($_SESSION['numeral']);//
				

				unset($_SESSION['setFirst']);//
				unset($_SESSION['questionLimitNumber']);//
				unset($_SESSION['qr']);
				unset($_SESSION['pagesIds']);
				unset($_SESSION['loopNumber']);//
				unset($_SESSION['page']);
				unset($_SESSION['countOfPageQuestions']);//
				unset($_SESSION['choiceArray']);

				unset($_SESSION['countedIds']);
				unset($_SESSION['sourcedQuestions']);
				$_SESSION['reset'] = 'yes';
				if (!isset($_SESSION['countOfPageQuestions'])) {
					$questionPossition = $cms->getQuestions()->selectSubjectViaTableIdAndClassId();

					$_SESSION['numberOfQuestionsOnPage'] = $questionPossition['number_of_questions'];

					$numeralOfRem = $questionPossition['number_of_removal'];
				} else {
					$numeralOfRem = $_SESSION['number_of_removal'];
					$numberOfQuestionsOnPage = $_SESSION['countOfPageQuestions'];
				}


			}

			if (isset($_GET['unset'])) {

				unset($_SESSION['countedNumberOfQuestionsPerQuestion']);
				unset($_SESSION['sortedIds']);
				unset($_SESSION['loopNumber']);
				unset($_SESSION['questionDesc']);

				//unset($_SESSION['countOfPageQuestions']);
			}
			if (isset($_GET['newpg'])) {
				
				$_SESSION['reset'] = 'yes';
				unset($_SESSION['fast']);
				unset($_SESSION['countedNumberOfQuestionsPerQuestion']);
				unset($_SESSION['pageQuestionIds']);
				unset($_SESSION['sortedIds']);
				unset($_SESSION['questionLimitNumber']);
				unset($_SESSION['qr']);
				unset($_SESSION['info']);
				
				unset($_SESSION['loopNumber']);
				unset($_SESSION['countOfPageQuestions']);//
				unset($_SESSION['numeral']);
				unset($_SESSION['setFirst']);

				unset($_SESSION['questionDesc']);
				unset($_SESSION['countedIds']);
				unset($_SESSION['sourcedQuestions']);

			}

			$page = $_GET['page'] ?? 1;
			if (isset($_GET['newpg']) || isset($_GET['refresh']) || isset($_GET['reset'])) {
				$_SESSION['page'] = $page;
			}



			?>

			<?php
			// echo $_SESSION['fast'];


			if ((isset($_GET['reset']) ||  isset($_GET['refresh']) || isset($_GET['newpg'])) && !isset($_GET['buffer'])) {
				if (!isset($_SESSSION['fast'])) {

					if (isset($_SESSION['numberOfQuestionsOnPage'])) {
						$numeralOfRem = $_SESSION['numeralOfRem'];
						$numberOfQuestionsOnPage = $_SESSION['numberOfQuestionsOnPage'];

					}
					if (!isset($_SESSION['countedNumberOfQuestionsPerQuestion'])) {

						// if (!isset($_SESSION['countedIds'])) {
						// $_SESSION['countedIds'] = $cms->getQuestions()->countQuestionIds();



						// } else {
						// 	$countedIds = $_SESSION['countedIds'];
						// }
						if (isset($_GET['newpg']) || isset($_GET['reset'])) {
							$questionIds = $cms->getQuestions()->selectQuestionIdsPagination($page, $numberOfQuestionsOnPage);
							$_SESSION['sourcedQuestions'] = count($questionIds[1]);
						}
						if (isset($questionIds)) {
							$pageQuestionIds = $cms->getQuestions()->selectQuestionInformationIdFromQuestionIds($questionIds[1]);
							$_SESSION['countOfPageQuestions'] = count($pageQuestionIds);

						}

						if(!isset($_SESSION['sortedIds'])) {

							$sortedIds = $cms->getQuestions()->sortArrayViaQuestionIdsArray($questionIds[1], $pageQuestionIds);

							$_SESSION['sortedIds'] = $sortedIds;
							$pagesIds = $sortedIds;

						} 	else {
							$pagesIds = $_SESSION['sortedIds'];
						}

						if ($_SESSION['sortedIds']['a' . 0] != 'empty') {








							$counted = count($pagesIds);


							for ($i = 0 ; $i < $counted ; $i++ ) {
								$countedNumberOfQuestionsPerQuestion['a' . $i] = count($pagesIds['a' . $i]);

							}


							$_SESSION['countedNumberOfQuestionsPerQuestion'] = $countedNumberOfQuestionsPerQuestion;
							$countedNumberOfQuestionsPerQuestion = $_SESSION['countedNumberOfQuestionsPerQuestion'];
							$pagesIds = $_SESSION['sortedIds'];
						}
					} else {
						$countedNumberOfQuestionsPerQuestion = $_SESSION['countedNumberOfQuestionsPerQuestion'];
						$pagesIds = $_SESSION['sortedIds'];
					}



					if ($_SESSION['sortedIds']['a' . 0] != 'empty') {


						if (!isset($_SESSION['loopNumber'])) {
							$loopNumber = count($pagesIds);
							$_SESSION['loopNumber'] = $loopNumber;

						}	else {
							$loopNumber = $_SESSION['loopNumber']; }
						}
					}
					$totalPages = $_SESSION['totalPages'];


					if ($_SESSION['sortedIds']['a' . 0] != 'empty') {
						if (isset($_GET['fast'])) {
							$_SESSION['fast'] = 1;
						}
						
						if (isset($_GET['runs'])) {
						$_SESSION['runs'] = intval($_GET['runs']);
					}
						$info = $cms->getQuestions()->selectQuestionAllAtOnce($pagesIds, $countedNumberOfQuestionsPerQuestion);
						$runs = $_SESSION['runs'];




						$sourcedQuestions = $_SESSION['sourcedQuestions'];
						$info['numeralOfRem'] = $_SESSION['numeralOfRem'];
					}}
					$sourcedQuestions = $_SESSION['sourcedQuestions'];
					if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_GET['refresh']) && !isset($_GET['reset'])) {


					} else {
						?>
						<script>
						var posted;
					</script>
					<?php
				}
				?>
				<div class="heightHeader"> </div>

				<?php

echo $_SESSION['offset'];
echo $_SESSION['counted'];


					?> <div class="width100">
						<?php
						echo $_SESSION['runs'];
?>
							<br>
							<div id="questions">

							</div>
							<div id="reply">

							</div>
							<br>

							<div class="marginAuto width20">

							<form action="resBuff.php?tp=<?= $_SESSION['totalPages'] ?>" method="POST">
								<input class="marginAuto width100" type="submit" value="CHECK QUESTION STATS!">
							</from>
							<br>
							<br>
							<br></div>
							<div style="text-align: center; margin: 0 auto;" ><h1>PAGE:<?= $_SESSION['page'] ?><h1></div>

							</div>
						</div>
							<div class="addHeight"></div>
							<?php






						// print_r($info);
						if (isset($info)) {
							?>










							<?php if (isset($_GET['reset']) || (isset($_GET['reset']) && isset($_GET['fast'])) || isset($_GET['refresh']) || isset($_GET['newpg'])) { ?>
								<div class="addHeight"></div>
								<div class="addHeight"></div>
								<script>
								var whatthe = <?= $_SESSION['page'] ?>;
								sessionStorage.setItem('start', 'on');
								var pg = 'page<?= $_SESSION['page'] ?>'
								var databaseName = "QuestionnaireClass<?= $_SESSION['site']['cId'] ?>S<?= $_SESSION['subject'] ?>";

								var	storeName = "QuestionnaireSubject<?= $_SESSION['subject'] ?>Class<?= $_SESSION['site']['cId'] ?>Page<?= $_SESSION['page'] ?? 1 ?>";
							
								var key = "id";
								var fast = '<?= $_SESSION['fast'] ?? 'no' ?>';
								var pageNo = '<?= $page ?? 1 ?>';
								sessionStorage.setItem('pg', 'page<?= $_SESSION['page'] ?>');

								var arr = <?= json_encode($info) ?>;
								arr.fast = fast;
								arr.db = {dN: databaseName, ky: key, sN: storeName,};
								console.log(arr);
								var res = [];
								<?php if (isset($_SESSION['gate'])) { ?>
								
								for (let i = 0; i < <?= $_SESSION['totalPages'] ?>; i++) {
								res[i] = 1;
								
							}
							sessionStorage.setItem('res', JSON.stringify(res));
									<?php unset($_SESSION['gate']); } ?>
							</script>

								<?php if (isset($_GET['reset'])) {
								?>
							<script>
							var reset = 'yes';

						</script>
									<?php
								} else { ?> 
								<script>
							var reset = 'no';
						</script>
								<?php }
								?>
	<?php if (isset($_GET['newpg'])) {
									?>
							<script>
							var newpg = 'yes';
							</script>
									<?php
								} else { ?> 
								<script>
									var newpg = 'no';
									</script>
								<?php }

if (isset($_GET['reset']) || isset($_GET['newpg'])) {
	?>
								<script>
							
								var arryFirst = {
									<?php
									for ($i = 0 ; $i < $sourcedQuestions ; $i++) { ?>
										a<?= $i ?>: { 0: {0:[]},
										numeralPos: '<?= $i ?>',
									},

									<?php }

									?> qr: {}, qAnsw: {rightAndWrong: {
										<?php for ($i = 0; $i < $_SESSION['sourcedQuestions']; $i++) {
											?>
											a<?= $i ?>: {right: 0, wrong: 0,},
											<?php } ?> length: <?php echo ($sourcedQuestions); ?>,
										},},
										qLength: <?php echo ($sourcedQuestions); ?>,
										length: <?php echo ($sourcedQuestions); ?>,
										db: {dN: databaseName, ky: key, sN: storeName,},
										numeralOfRemoval: arr.numeralOfRem,
									};

									sessionStorage.setItem('arryFirst', JSON.stringify(arryFirst));
									sessionStorage.setItem('arr', JSON.stringify(arr));
								</script>	<?php
							} else { ?>
								<script>
								var reset = 'no';
								var arryFirst = 1;
							</script>
						<?php }


						if (isset($_GET['reset']) || isset($_GET['newpg'])) {
							?>

							<script>

							sessionStorage.setItem('pg', 'page<?= $_SESSION['page'] ?? 1 ?>');

							sessionStorage.setItem('numeral', JSON.stringify(arr['numeral']));
							sessionStorage.setItem('rem', JSON.stringify(arr['numeralOfRem']));
							sessionStorage.setItem('arryFirst', JSON.stringify(arryFirst));

							sessionStorage.setItem('qr', JSON.stringify(arryFirst['qr']));

							if (typeof sessionStorage.getItem(pageNo) === null) {
								sessionStorage.setItem(pageNo, JSON.stringify(arryFirst.qAnsw.rightAndWrong));
							}
						</script>
					<?php }
					?>
					<script>

					var page = 'page' + <?= $page ?? 1 ?>;
					var sourcedQuestions = <?= $_SESSION['sourcedQuestions'] ?? 'undefined' ?>;

				</script>

				<script>
				<?php

				?>

				var newpg = '<?= $_GET['newpg'] ?? 'no' ?>';
				var refresh = '<?= $_GET['refresh'] ?? 'no' ?>';
				sessionStorage.setItem('arr', JSON.stringify(arr));

				</script>
				<?php if (isset($_GET['reset']) ||isset($_GET['refresh']) || isset($_GET['newpg']) || (isset($_GET['newpg']) && isset($_GET['fast']))) { ?>
					<script src="script/loadMod.js">

					</script>








					<?php
				}

			}
		}




		$end = microtime(true);
		echo ($end - $start);
	}
	?>
</div>
</div>
</div>


<?php
if (isset($_SESSION['layoutOfSite']['enableMovingBars'])) {
	if ($_SESSION['layoutOfSite']['enableMovingBars'] == '1') {

		?>
		<div id="rightLowerSidebar" class="rightLowerSidebar">

		</div>
	</div>
</div>

<?php

}
}

if ($_SESSION['totalPages'] > 1) {
	?>




	<div id="pagination" class="pagination">
		<div class="pageWidthPombw">
			<?php
			$questionnaire = "questionnaireBuf.php";
			$option = '&newpg=yes';
			echo get_pagination_links($_SESSION['page'], $_SESSION['totalPages'], $questionnaire, $option);
			?>
		</div>
	</div>
	<br>
	<br>
	<br>
	<br>
<?php } ?>
<div>
	<?php
	include "includes/footer2.php";
	?>
</div>
</body>
</html>
