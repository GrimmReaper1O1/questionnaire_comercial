


  function h4 (text) {
    var elemented = "<h4>" + text + "</h4>";
    return elemented;
  }
  function paragraph(text) {
    var para = "<p>"+text+"</p>";
    para.textContent = text;
    return para;
  }
  function paragraphs(text) {
  var paragraphs = text.split(/\r\r|\r\n/);

  var htmlParagraphs = [];

  paragraphs.forEach(function(paragraphText) {
    paragraphText = paragraphText.trim();

    var htmlParagraph = "<p>" + paragraphText + "</p>";

    htmlParagraphs.push(htmlParagraph);
  });

  var htmlOutput = htmlParagraphs.join("");


    return htmlOutput;
  }




function runTwo (arry, posted, color, width, colorOfText, borderColour) {
  let layout = JSON.parse(localStorage.getItem('layout'));
console.log(arry);
    let qr = arry['qr'];

let $div = $('#reply');
let qn;
let $div2 = {};
let counter;
console.log('did it at least get here');
console.log(posted);
for (var i = 0; i < arry.qLength; i++ ) {
  counter = 0;
  
  for (let c = 1 ; c < 9 ; c++ ) {
    key = i+'a'+(c-1);
     console.log(key);
    if (posted[key] == 'on') {
      qn = i;
      $div2[counter] = $('<div>', {
        class: 'individualQuestions',
      });
      console.log('got here');
    }
    
    console.log['posted'];
    console.log[posted];
    if (posted[key] == 'on') {
let text1 = arry['a' + i][0][arry['numeral'][i]]['question'];
let text2 = arry['a' + i][0][arry['numeral'][i]]['answ' + c];
let text3 = arry['a' + i][0][arry['numeral'][i]]['hint' + c];
let text4 = arry['a' + i][0][arry['numeral'][i]]['pa' + c];
let breakLine = '<br><br>';

console.log(text1);
console.log(counter);
console.log(c);
let question, answer, reply, hint;
 question = 'Question: ' + paragraphs(text1);
 answer = 'Answer given: ' + paragraphs(text4);
 reply = 'Reply: ' + paragraphs(text2);


if (arry['a' + i][0][arry['numeral'][i]]['hint' + c] != 'empty') {

    hint = "Hint given: " + paragraphs(text3);

  } else {
    hint = 'empty';
  }
            $br = $('<br>');
            $div2[counter].append(question);
            $div2[counter].append($br)
            $div2[counter].append(answer);
            $div2[counter].append($br)
            $div2[counter].append(reply);
            $div2[counter].append($br)
if (hint != 'empty') {
            $div2[counter].append(hint)
            $div2[counter].append($br);
}
    if (arry['a' + qn][0][arry['numeral'][i]]['correct'] === 'answ'+ c && posted[i+'a'+(c-1)] === 'on' ) {
      qr['a' + qn]++;
      console.log('hereo');

      arry['qAnsw']['rightAndWrong']['a'+i]['right']++;
    } else {
      arry['qAnsw']['rightAndWrong']['a'+i]['wrong']++;
      }
    }
  }
  
  for (let c = 1 ; c < 9 ; c++ ) {
    key = i+'a'+(c-1);
    if (posted[key] == 'on') {
     $div2[counter].css({'color': layout.cotiqp, 'background-color': layout.coqaab, 'border': '3px solid ' + layout.qbc,'border-radius': '75px', 'width': layout.soqipip + "%", 'margin': '0 auto', 'padding': '40px', });
     // $div2[i].attr('style', 'color: ' + layout.cotiqp + ' !important;');
     $div.append($div2[counter]);
     $div.append($('<br>'));
     counter++;
    }
  }
}

arry['qAnsw'];
arry['qr'] = qr;
return arry;
}


(function(){
let runOrNot = 0;
let rem = sessionStorage.getItem('rem');
let place = sessionStorage.getItem('arry');
let pg = sessionStorage.getItem('pg')
let qAnsw = JSON.parse(sessionStorage.getItem(pg));
console.log(place);
  let arry = JSON.parse(place);

arry.qAnsw.rightAndWrong = qAnsw;
  console.log(arry);
  arry = runTwo(arry, posted, style);
  let qr = arry['qr'];
  console.log('arry')
console.log(arry);
  sessionStorage.setItem('arry', JSON.stringify(arry));
  sessionStorage.setItem(pg, JSON.stringify(arry.qAnsw.rightAndWrong));
  console.log(pg);console.log('here');
  console.log(arry.qAnsw);
  // if (fast != 'undefined') {
  //   saveToIndexedDB(storeName, {id: arry}, key, databaseName);
  //   }



}());
