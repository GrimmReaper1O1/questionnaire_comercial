

  function h4 (text) {
    var elemented = "<h4>" + text + "</h4>";
    return elemented;
  }
  function paragraph(text) {
    var para = "<p>"+text+"</p>";
    para.textContent = text;
    return para;
  }
  function paragraphs(text) {
  var paragraphs = text.split(/\r\r|\r\n/);

  var htmlParagraphs = [];

  paragraphs.forEach(function(paragraphText) {
    paragraphText = paragraphText.trim();

    var htmlParagraph = "<p>" + paragraphText + "</p>";

    htmlParagraphs.push(htmlParagraph);
  });

  var htmlOutput = htmlParagraphs.join("");


    return htmlOutput;
  }


  function countValues(obj) {
    let count = 0;

    for (let key in obj) {

        count++;
      }

    return count;
  }


  function runOne (arry, numeralOfRemoval) {
console.log(numeralOfRemoval);

let layout = JSON.parse(localStorage.getItem('layout'));
let text, newText, finalText;
let $holdingDiv = $('#questions');
let $div = {};
for (let a = 0; a < arry.qLength; a++) {

$div[a] = $('<div>',
{
  class:  'individualQuestions',
});

}
let $firstInnerDiv = {}, $secondInnerDiv = {}, $el = {};
for (let i = 0; i < arry.qLength; i++) {

  for (let b = 0; b < 8 ;b++) {
    $el[b] = $('<input>', {
      type: 'radio',
      class: 'r'+i+'adio-button',
      name: i+'a'+(b),
      onclick: 'radioGroup['+i+']',
    } );
  }

  if (numeralOfRemoval != arry.qAnsw.rightAndWrong['a'+i]['right']) {
    text = arry['a'+i][0][arry['numeral'][i]]['question'];
    newtext = paragraphs(text);
    finalText = "Quesiton: " + newtext + ' <br>';

    $firstInnerDiv[i] = $('<div>').html(finalText);
    $secondInnerDiv[i] = $('<div>');
    let keyzero = {};
    let keyone = {};
    let text1, text2, text3, text4;
    for (let c = 1; c < 9 ;c++) {
      $secondInnerDiv[i].append($el[c]);
        text1 = '';
        text3 = '';
        text2 = '';
        text4 = '';
        keyzero[c] = 'pa' + c;
        keyone[c] = 'hint' + c;
// console.log('got here');
        if (arry['a'+i][0][arry['numeral'][i]][keyzero[c]] != 'empty') {
          text1 = arry['a'+i][0][arry['numeral'][i]][keyzero[c]];
          text1 = 'Answer: ' + text1;
          text1 = paragraphs(text1);
          // console.log(text1);
          text2 = text1 + '<br>';
          $firstInnerDiv[i].append($el[c-1]);

        }
        if (arry['a'+i][0][arry['numeral'][i]][keyone[c]] != 'empty') {
        text3 = 'Hint: ' + arry['a'+i][0][arry['numeral'][i]][keyone[c]];
        text3 = paragraphs(text3) + '<br>';

      }
// console.log(c);
      text4 = text2 + text3;
      let span = {};
          span[c] = $('<span>').html(text4);
// console.log(text4);
      $firstInnerDiv[i].append(span[c]);

  }

  $div[i].append($firstInnerDiv[i]);
} else {

  $div[i].html('<h4>COMPLETE!</h4>');
 

  }

  $div[i].css({'color': layout.cotiqp, 'background-color': layout.coqaab, 'border': '3px solid ' + layout.qbc,'border-radius': '75px', 'width': layout.soqipip + "%", 'margin': '0 auto', 'padding': '40px', });
  $holdingDiv.append($div[i]);

}
console.log(layout);
  let radioGroup = [];
  console.log("I'm here");
  for (let i = 0 ; i < arry.qLength ; i ++ ) {
    radioGroup[i] = {
      init: function() {
        const $radioButtons = $('.r'+i+'adio-button');
        $radioButtons.click( function() {
        // When one radio button is checked, uncheck others with the same class
        if ($(this).is(':checked')) {
            $radioButtons.not(this).prop('disabled', true);
        }
    });
      }
    }
    radioGroup[i].init();
  }

return arry;
}


(function(){

  var rem = sessionStorage.getItem('rem');
  var arry = sessionStorage.getItem('arry');
  var arr = sessionStorage.getItem('arr');
  var qr = sessionStorage.getItem('qr');
  var arry2 = JSON.parse(arry);
  var pg = sessionStorage.getItem('pg');


  arry2.qAnsw.rightAndWrong = JSON.parse(sessionStorage.getItem(pg));
  console.log(arry2);
  console.log(pg);
  console.log('below');
  let result = runOne(arry2, rem);
  let arry3 = JSON.stringify(arry2);


}());
