<?php
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"></head>
<body>
<script>
var storeName = 'questionnaire';
var database;
/* Inicializamos la base de datos */
async function initiate() {
   database  = indexedDB.open("tester", 1);

  database.onupgradeneeded = function (event) {
    activate = database.result;
    tester = activate.createObjectStore("questionnaire", { keyPath: 'id', autoIncrement: false });
    tester.createIndex('id', 'info', { unique: false} );
  }

  database.onsuccess = function (event) {
    alert('there is a database');
    
  }

  database.onerror = function (event) {
    alert('there is a problem with the database');
  }
}
</script>

<script>
function saveToIndexedDB(storeName, object){
  return new Promise(
    function(resolve, reject) {
      if (object.id === undefined) reject(Error('object has no id.'));
      var dbRequest = indexedDB.open(storeName);

      dbRequest.onerror = function(event) {
        reject(Error("IndexedDB database error"));
      };

      dbRequest.onupgradeneeded = function(event) {
        var database    = event.target.result;
        var objectStore = database.createObjectStore(storeName, {keyPath: "id"});
      };

      dbRequest.onsuccess = function(event) {
        var database      = event.target.result;
        var transaction   = database.transaction([storeName], 'readwrite');
        var objectStore   = transaction.objectStore(storeName);
        var objectRequest = objectStore.put(object); // Overwrite if exists

        objectRequest.onerror = function(event) {
          reject(Error('Error text'));
        };

        objectRequest.onsuccess = function(event) {
          resolve('Data saved OK');
        };
      };
    }
  );
};

var data = {id: 'id'};
initiate();
saveToIndexedDB(storeName, data).then(function (response) {
  alert('data saved');
}).catch(function (error) {
  alert(error.message);
}); 

</script>
<script type='module'>
import {loadFromIndexedDB} from './src/loadMod.js';
var res;
res = loadFromIndexedDB(storeName, 'string' ).then(function (reponse) {
  res = reponse;

  alert('data loaded OK');
}).catch(function (error) {
  alert(error.message);
});

</script>

<script>


initiate();


console.log(res);



</script>

</body>
</html>