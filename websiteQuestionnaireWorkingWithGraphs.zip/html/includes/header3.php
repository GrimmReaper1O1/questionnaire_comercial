<?php
require '../src/bootstrap.php';
if (isset($_SESSION['id'])) {
if (isset($_GET['class'])) {
	$_SESSION['class'] = $_GET['class'];
	
}



$start = microtime(true);
?>
<!DOCTYPE HTML>
<html>
<title>questionnaire</title>

    <head>

	<meta http-equiv="Content-Type" 
      content="text/html; charset=utf-8">
	  <meta http-equiv="Content-Type" 
      content="application/javascript; charset=utf-8">
	
	</head>
		<style>

a {color: white;},
a:visited {color: purple},
a:hover {color: blue},
a:active {color: yellow},

</style>

    <body style="background-color: rgb(16,13,217); width: 100%; ">
    <img src="banner">
    <nav>
		
	<?php 
	?>
	<a href="classes.php?reset=yes">Classes</a> 
	<?php
		
	if ($_SESSION['administrator']['admin'] != 1) { 
	echo '| <a href="library/library.php">Library</a> '; } 
	if ($_SESSION['administrator']['admin'] == 1) { echo '| <a href="library/library.php">Students Library</a> '; } 
	?>
	| <a href="enterMathematics.php">Mathematics</a> | <a href="changeInfo.php">Settings</a> | <a href="contactUs.php">Contact Us</a>
	<?PHP 
	if ($_SESSION['administrator']['admin'] == 1) {
		if ($_SESSION['administrator']['root'] == 1) {
		echo ' | <a href="admin/adminLibrary/upload_pdf.php">Upload to library</a>';
		}
		echo " | <a href='admin/userAdmin/set_administrator_options.php'>Administer users, library, and classes</a>" . 
		" | <a href='admin/classes.php'>Administer classes</a>";} 
		?> 
		| <a href="logout.php">Sign Out</a> </nav>
    <br>
    <br>
    <br>
	<div style="width: 89%; margin-left: 5%; margin-right: 5%;">
<?php
}
?>