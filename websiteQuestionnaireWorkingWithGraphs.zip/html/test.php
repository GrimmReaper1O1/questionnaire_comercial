<?php
?>
<DOCTYPE! HTML>
	<html>
		<head>
</head>
<body>

<canvas id="myCanvas" width="600" height="300" style="border: 1px solid 
black; background-color: 'rgb(0,0,255)';"></canvas>

<script src="src/canvas.js"></script>
<script>
 window.onload = function () {
            var myLineChart = new LineChart({
                canvasId: "myCanvas",
                minX: 0,
                minY: 0,
                maxX: 140,
                maxY: 100,
                unitsPerTickX: 10,
                unitsPerTickY: 10
            });

            var data = [{
                x: 0,
                y: 0
            }, {
                x: 20,
                y: 10
            }, {
                x: 40,
                y: 15
            }, {
                x: 60,
                y: 40
            }, {
                x: 80,
                y: 60
            }, {
                x: 100,
                y: 50
            }, {
                x: 120,
                y: 85
            }, {
                x: 140,
                y: 100
            }];

            myLineChart.drawLine(data, "green", 3);

            var data = [{
                x: 20,
                y: 85
            }, {
                x: 40,
                y: 75
            }, {
                x: 60,
                y: 75
            }, {
                x: 80,
                y: 45
            }, {
                x: 100,
                y: 65
            }, {
                x: 120,
                y: 40
            }, {
                x: 140,
                y: 35
            }];

            myLineChart.drawLine(data, "red", 3);
        };
    </script>

</body>
</html>
