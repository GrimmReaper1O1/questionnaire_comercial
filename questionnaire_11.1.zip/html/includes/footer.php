<?php ?><p>
  <footer class="marginAuto">Copyright &copy; 2023</footer>
</p>
<script src="<?= $string[1] ?>script/styling.js"></script>
<?php
