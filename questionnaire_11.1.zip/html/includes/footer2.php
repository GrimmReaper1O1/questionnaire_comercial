<?php ?>
<script src="<?= $string[1] ?>script/styling.js"></script>
