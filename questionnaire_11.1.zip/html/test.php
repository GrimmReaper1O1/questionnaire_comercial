<?php

$now = time();
$m = 'm';
$y = 'Y';
$d = 'd';
$month = date($m, $now);
$year = date($y, $now);
$day = date($d, $now);
if ($month == '01' & $day < '03') {
    $pMonth = 12;
    $pDay = 3;
    $pYear = $year - 1;
} else {
    $pMonth = $month;
    $pYear = $year;
    $pDay = '03';
}

$periodStart = $pMonth.'/'.$pDay.'/'.$pYear;
$periodStartUnix = strtotime($periodStart);

if ($month == '12' && $day > '03') {
    $ePMonth = '01';
    $ePYear = $year + 1;
    $ePDay = '03';
} else {
    $ePMonth = $month+1;
    $ePYear = $year;
    $ePDay = '03';
}
$periodEnd = $ePMonth.'/'.$ePDay.'/'.$ePYear;
$periodEndUnix = strtotime($periodEnd);

echo $periodStart . '<br>';
echo $periodEnd . '<br>';
echo $periodStartUnix . '<br>';
echo $periodEndUnix. '<br>';