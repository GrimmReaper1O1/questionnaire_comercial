<?php
include "includes/header3a.php";
if (isset($_GET['id'])) {
	unset($_SESSION['startTime']);
	$_SESSION['startTime'] = microtime(true);
$id = $_GET['id'] ?? '';
$_SESSION['subject'] = $id;
}
$_SESSION['gate'] = 'enter';

if (isset($_GET['id'])) {
	$row = $cms->getQuestions()->selectSubjectViaTableIdAndClassId();
	
$_SESSION['version'] = $row['version'];
$_SESSION['numberOfQuestionsOnPage'] = $row['number_of_questions'];
$_SESSION['numeralOfRem'] = $row['number_of_removal'];


	$introduction = $row['introduction'] ?? '';
}
	?>
	<div id="main" class="main">
	<?php 
	if (isset($_SESSION['layoutOfSite']['enableMovingBars'])) {
		if (intval($_SESSION['layoutOfSite']['enableMovingBars']) == 0) {
			?>
			<div class="heightHeader">
			</div>
			<?php
		}
	
	}
	
	?>
	<div class="mainbody">
	<br>
<div class="centeredText"><h1><?= ' ' . $row['subject_information'] ?? '' ?></h1><br><br>
<h1><i><a href="questionnaireBuf.php">ENTER SUBJECT.</a></i></h1><br>
<br>
<br>
</div>
<div class="margin50">
<?php 
// if ($row['video'] == 1) { // do a pregmatch on the type of file and if matched then choose file with php
?>
	
	<video style="width: 100%;"  poster="<?= $row['posterFilename'] ?? '' ?>"
	id="subjectVideo"
	type="video/webm" preload="auto"
	controls >
	<source src="<?= $row['videoFilename'] ?? '' ?>uploads/one.webm" type="video/webm" />
	<source src="<?= $row['videoFileName'] ?? '' ?>uploads/one.mpg" type="video/mp4" />
</video><br>
<audio style="width: 100%;" controls>
  <source src="<?= $row['audioFilename'] ?? '' ?>" type="audio/ogg">
  <source src="<?= $row['audioFilename'] ?? '' ?>" type="audio/mpeg">
Your browser does not support the audio element.
</audio><br>
</div>

<div class="content">
	<div style="display: flex;">
<div class="leftSideInner" style="text-align: justify !important;" >	<div class="textBoxes" style="width: 100%;"><?php echo '<p><h3>' . paragraph($introduction) . '</h3></p>'; ?><br>
<?php
for ($i = 1; $i <= 10; $i++) {
if ($row['link' . $i] != 'empty') {
	//remember to link colour with question set colour field.
	
	?>
<p ><a  style="color: black !important;" href="http:\\<?= $row['link' . $i] ?>"><?= $row['link_description' . $i] ?></a></p><br>		
	<?php
}
}
?>

<br>
</div>
</div>
<div class="rightSideInner"> 
<?php
if (!isset($imageArry)) {
	for ($i = 0 ; $i < 15 ; $i++) {
	?>	
	<div style="display: flex">
	<figure style="height: initial; display: block;">
		<image style="width: 80%; height: auto display: block;" src="<?= $image['filename'] ?? 'images/plants dancing.jpg' ?>" alt="<?= $image['description'] ?? '' ?>" class="apendix" /><br>
	</figcaption><?= $image["identifier"] ?? 'stuff' ?> </figcaption>
	</figure>
	</div>
	<?php
	}
}
?>
</div>
</div>
</div>html/includes/header3.php
</div>

</div>
<?php
if (isset($_SESSION['layoutOfSite']['enableMovingBars'])) {
    if ($_SESSION['layoutOfSite']['enableMovingBars'] == 1) {
 
?>
<div id="rightLowerSidebar" class="rightLowerSidebar">
	
	</div>

<?php

    }
}
?>
</div>
</div>

</body>
</html>
