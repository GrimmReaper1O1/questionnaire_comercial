<?php
	include "includes/header3b.php";
		if (isset($_SESSION['id'])) {
		
			
	
			?>
	<script> if (typeof sessionStorage.getItem('start') == 'undefined') {
		windows.location.replace("/index.php");
	}
	</script>
	<div id="main" class="main">
		<div class="mainbody">
			<br>
	<?php 
if (isset($_SESSION['layoutOfSite']['enableMovingBars'])) {
    if ($_SESSION['layoutOfSite']['enableMovingBars'] == 0) {
		?>
		<div class="heightHeader">
		</div>
		<?php
	}

}

?>

<div style="height: 200px;">
</div>

			<?php



	if (isset($_GET['reset'])) {	
		unset($_SESSION['gate']);
		unset($_SESSION['allQuestions']);//
		unset($_SESSION['questionDesc']);//
		unset($_SESSION['sortedIds']);//
		unset($_SESSION['countedNumberOfQuestionsPerQuestion']);//
		unset($_SESSION['pageQuestionIds']);//
		unset($_SESSION['fast']);//
		unset($_SESSION['info']);//
		unset($_SESSION['numeral']);//
		unset($_SESSION['runs']);//
		
		unset($_SESSION['setFirst']);//
		unset($_SESSION['questionLimitNumber']);//
		unset($_SESSION['qr']);
		unset($_SESSION['pagesIds']);
		unset($_SESSION['loopNumber']);//
		unset($_SESSION['page']);
		unset($_SESSION['countOfPageQuestions']);//
		unset($_SESSION['choiceArray']);
	
		unset($_SESSION['countedIds']);
		unset($_SESSION['sourcedQuestions']);
		$_SESSION['reset'] = 'yes';
	if (!isset($_SESSION['countOfPageQuestions'])) {
		$questionPossition = $cms->getQuestions()->selectSubjectViaTableIdAndClassId();
	
		$_SESSION['numberOfQuestionsOnPage'] = $questionPossition['number_of_questions'];
				
		$numeralOfRem = $questionPossition['number_of_removal'];
	} else {
		$numeralOfRem = $_SESSION['number_of_removal'];
		$numberOfQuestionsOnPage = $_SESSION['countOfPageQuestions'];
	}
	

}

	if (isset($_GET['unset'])) {	
	
unset($_SESSION['countedNumberOfQuestionsPerQuestion']);
unset($_SESSION['sortedIds']);
unset($_SESSION['loopNumber']);
unset($_SESSION['questionDesc']);

//unset($_SESSION['countOfPageQuestions']);
	}
	if (isset($_GET['newpg'])) {
		unset($_SESSION['gate']);	
		$_SESSION['reset'] = 'yes';
		unset($_SESSION['fast']);
		unset($_SESSION['countedNumberOfQuestionsPerQuestion']);
		unset($_SESSION['pageQuestionIds']);
		unset($_SESSION['sortedIds']);
		unset($_SESSION['questionLimitNumber']);
		unset($_SESSION['qr']);
		unset($_SESSION['info']);
		unset($_SESSION['runs']);
		unset($_SESSION['loopNumber']);
		unset($_SESSION['countOfPageQuestions']);//
		unset($_SESSION['numeral']);
		unset($_SESSION['setFirst']);
		
		unset($_SESSION['questionDesc']);
		unset($_SESSION['countedIds']);
		unset($_SESSION['sourcedQuestions']);
		
			}
			
		$page = $_GET['page'] ?? 1;
	if (isset($_GET['newpg']) || isset($_GET['refresh']) || isset($_GET['reset'])) {
		$_SESSION['page'] = $page;
	} 
	
		


	?>

	<?php
	// echo $_SESSION['fast'];


		if ((isset($_GET['reset']) ||  isset($_GET['refresh']) || isset($_GET['newpg'])) && !isset($_GET['buffer'])) {
		if (!isset($_SESSSION['fast'])) {
		
		if (isset($_SESSION['numberOfQuestionsOnPage'])) {
		$numeralOfRem = $_SESSION['numeralOfRem'];
		$numberOfQuestionsOnPage = $_SESSION['numberOfQuestionsOnPage'];

	}
if (!isset($_SESSION['countedNumberOfQuestionsPerQuestion'])) { 
	
	// if (!isset($_SESSION['countedIds'])) {
	// $_SESSION['countedIds'] = $cms->getQuestions()->countQuestionIds();
	
	
	
	// } else {
	// 	$countedIds = $_SESSION['countedIds'];
	// }
	if (isset($_GET['newpg']) || isset($_GET['reset'])) {
		$questionIds = $cms->getQuestions()->selectQuestionIdsPagination($page, $numberOfQuestionsOnPage);
	$_SESSION['sourcedQuestions'] = count($questionIds[1]);
	}
	if (isset($questionIds)) {
		$pageQuestionIds = $cms->getQuestions()->selectQuestionInformationIdFromQuestionIds($questionIds[1]);
		$_SESSION['countOfPageQuestions'] = count($pageQuestionIds);

	}

 if(!isset($_SESSION['sortedIds'])) {

$sortedIds = $cms->getQuestions()->sortArrayViaQuestionIdsArray($questionIds[1], $pageQuestionIds);

$_SESSION['sortedIds'] = $sortedIds;
$pagesIds = $sortedIds;

} 	else {
	$pagesIds = $_SESSION['sortedIds'];
}

if ($_SESSION['sortedIds']['a' . 0] != 'empty') {
		



		
	
	
		
		$counted = count($pagesIds);	
		

	for ($i = 0 ; $i < $counted ; $i++ ) {
	$countedNumberOfQuestionsPerQuestion['a' . $i] = count($pagesIds['a' . $i]);

	}
	
	
	$_SESSION['countedNumberOfQuestionsPerQuestion'] = $countedNumberOfQuestionsPerQuestion;
	$countedNumberOfQuestionsPerQuestion = $_SESSION['countedNumberOfQuestionsPerQuestion'];
	$pagesIds = $_SESSION['sortedIds'];
}
	} else { 
	$countedNumberOfQuestionsPerQuestion = $_SESSION['countedNumberOfQuestionsPerQuestion'];
	$pagesIds = $_SESSION['sortedIds'];
	} 



	if ($_SESSION['sortedIds']['a' . 0] != 'empty') {


			if (!isset($_SESSION['loopNumber'])) {
				$loopNumber = count($pagesIds);
				$_SESSION['loopNumber'] = $loopNumber;

		}	else {
			$loopNumber = $_SESSION['loopNumber']; }
		}
	}
		$totalPages = $_SESSION['totalPages'];


	if ($_SESSION['sortedIds']['a' . 0] != 'empty') {
	if (isset($_GET['fast'])) {
		$_SESSION['fast'] = 'on';
	}

$info = $cms->getQuestions()->selectQuestionAllAtOnce($pagesIds, $countedNumberOfQuestionsPerQuestion);
$runs = $_SESSION['runs'];




$sourcedQuestions = $_SESSION['sourcedQuestions'];
$info['numeralOfRem'] = $_SESSION['numeralOfRem'];
	}}
	
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_GET['refresh']) && !isset($_GET['reset'])) {


?>



<?php 
} else {
?>
<script>
var posted;
</script>
<?php
}
if (isset($_GET['buffer'])) {

	?> <div class="width100">
	<form action="questionnaire.php?page=<?= $_SESSION['page'] ?>" method="POST">
		<?php 
		for ($i = 0 ; $i < count($_SESSION['countedNumberOfQuestionsPerQuestion']) ; $i++ ) {
	
			?>
	
	<br>
	<div class="qanswer">
	<div id="<?= $i ?>">
		
	
	<br>
	<h4 id="a<?= $i ?>"></h4>
	<br>
	</div>
		</div>
	<br>
	
	<?php
		} ?><div class="marginAuto width20">
		<input class="marginAuto width100" type="submit" value="SUBMIT!">
		</form>
		<form action="questionnaire.php?page=<?= $_SESSION['page'] ?>&newpg=yes<?php if (isset($_SESSION['fast'])) { echo "&fast=yes"; } ?>" method="POST">
		<input class="marginAuto width100" type="submit" value="RESET PAGE QUESTIONS!">
		</form>
		<form action="resBuff.php?tp=<?= $_SESSION['totalPages'] ?>" method="POST">
		<input class="marginAuto width100" type="submit" value="CHECK QUESTION STATS!">
		</from>
		<br>
		<br>
		<br></div>	
		<div style="text-align: center; margin: 0 auto;" ><h1>PAGE:<?= $_SESSION['page'] ?><h1></div>
	
	</div>
		
		<?php
	}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_GET['refresh']) && !isset($_GET['reset'])) {
	if (isset($_SESSION['fast'])) { ?>
	
		<form action="questionnaire.php?refresh=yes&fast=yes&page=<?= $_SESSION['page'] ?>" method="POST">

	<?php } else { ?>
	
		<form action="questionnaire.php?refresh=yes&page=<?= $_SESSION['page'] ?>" method="POST">


	<?php } ?>

		<h4 class="reply" id="reply"></h4>
		<input style="display: block; margin-left: auto; margin-right: auto;" type="submit" value="NEXT QUESTION SET!"></form>
	
	</form>
	
	
	<?php
	
	?>
	
	
	


<?php
}

if (!isset($_GET['reset']) && !isset($_GET['refresh']) && !isset($_GET['buffer']) && !isset($_GET['newpg'])) {

	?>
	<script type="module">
import {runTwo, saveToIndexedDB, openDB, loadFromIndexedDB} from './src/loadMod.js';
// type module will not run until loaded
let posted = <?= json_encode($_POST) ?>;
var databaseName = "QuestionnaireClass<?= $_SESSION['site']['cId'] ?>";
var key = "qS<?= $_SESSION['subject'] ?>C<?= $_SESSION['site']['cId'] ?>P<?= $page ?? 1?>";
var storeName = "QuestionnaireSubject<?= $_SESSION['subject'] ?>Class<?= $_SESSION['site']['cId'] ?>Page<?= $_SESSION['page'] ?>";
console.log(sessionStorage.getItem('pass'));
let runOrNot = 0;
let place = sessionStorage.getItem('status');
let arry = JSON.parse(place);
  var  qAnsw = sessionStorage.getItem(<?php echo '"page' . $_SESSION['page'] . '"'; ?>);
arry['qAnsw'] = JSON.parse(qAnsw);

// var numeral = sessionStorage.getItem('numeral');
var rem = sessionStorage.getItem('rem');
// var arry = sessionStorage.getItem('status');
// var arr = sessionStorage.getItem('status2');
// var qAnsw = sessionStorage.getItem('qAnsw');
// let qr = sessionStorage.getItem('qr');
// let arry2 = JSON.parse(arry);
// arry2['qAnsw'] = qAnsw;
// console.log(arry2);
// numeral = JSON.parse(numeral);
// arry2.numeral = numeral;







console.log(arry);
arry = runTwo(arry, posted, '<?= $_SESSION['layoutOfSite']['coqaab'] ?? 'white' ?>', <?= $_SESSION['layoutOfSite']['soqipip'] ?? 80 ?>, 
'<?= $_SESSION['layoutOfSite']['cotiqaab'] ?? 'black' ?>', '<?= $_SESSION['layoutOfSite']['qbc'] ?? 'black' ?>');
let qr = arry['qr'];


sessionStorage.setItem('qr', JSON.stringify(qr));
saveToIndexedDB(storeName, {id: JSON.stringify(arry)}, key, databaseName);
sessionStorage.setItem("status", JSON.stringify(arry));
sessionStorage.setItem(<?php echo '"page' . $_SESSION['page'] . '"'; ?>, JSON.stringify(arry['qAnsw']));
sessionStorage.setItem('qAnsw', JSON.stringify(arry['qAnsw']));
 console.log(JSON.parse(sessionStorage.getItem('page<?= $_SESSION['page'] ?>')));



</script>
<?php

}




// print_r($info);
if (isset($info)) {
	?>







  


<?php if (isset($_GET['reset']) || (isset($_GET['reset']) && isset($_GET['fast'])) || isset($_GET['refresh']) || isset($_GET['newpg'])) { ?>
<script type="module">
	
	sessionStorage.setItem('start', 'on');
	import {loadFromIndexedDB, saveToIndexedDB,} from './src/loadMod.js';
	var databaseName = "QuestionnaireClass<?= $_SESSION['site']['cId'] ?>";
var key = "qS<?= $_SESSION['subject'] ?>C<?= $_SESSION['site']['cId'] ?>P<?= $page ?? 1?>";
var storeName = "QuestionnaireSubject<?= $_SESSION['subject'] ?>Class<?= $_SESSION['site']['cId'] ?>Page<?= $_SESSION['page'] ?>";

var arr = <?= json_encode($info) ?>;
console.log(arr);
var arry = {
		<?php
for ($i = 0 ; $i < $sourcedQuestions ; $i++) { ?> 
	 a<?= $i ?>: {
		0: {}, numeralPos: '<?= $i ?>',
	 }, 
	 
<?php }
 


?> qr: {}, qAnsw: {},
qLength: <?php echo ($sourcedQuestions); ?>,
length: <?php echo ($sourcedQuestions + 4); ?>,

};

 <?php if (isset($_GET['reset'])) { 
	   ?>
arry['fast'] = arr['fast'];
if (arr.hasOwnProperty('info')) {
		for (let i = 0; i < arry.qLength ; i++) {
	   		arry['qr']['a'+i] = 0;
	   	if (typeof arr['info'] != 'undefined') {
						arry['a' + i][arr['runs']-1] = arr['info'][i];
		}
    }							 
}

			


console.log('here');
	var qAnsw;
	 qAnsw = {qNumeral: {
	<?php for ($i = 0; $i < $_SESSION['sourcedQuestions']; $i++) {
		?>
	  <?= $i ?>: {right: 0, wrong: 0,},
	<?php } ?>
	
	}, length: <?= $_SESSION['sourcedQuestions'] ?>,};
arry['qAnsw'] = qAnsw;
	

 




 
 <?php 
  			
   
   ?>

   console.log(arry);
  
console.log(qAnsw);
sessionStorage.setItem('numeral', JSON.stringify(arr['numeral']));
sessionStorage.setItem('rem', arr['numeralOfRem']);
sessionStorage.setItem('status', JSON.stringify(arry));
sessionStorage.setItem('status2', JSON.stringify(arr));
sessionStorage.setItem('qr', JSON.stringify(arry['qr']));
console.log(arry['qr']);
sessionStorage.setItem(<?php echo '"page' . $_SESSION['page'] . '"'; ?>, JSON.stringify(arry['qAnsw']));
  window.location.replace('/questionnaire.php?buffer=yes&page=<?= $_SESSION['page'] ?><?php if (isset($_GET['fast'])) { echo '&fast=yes'; } ?>');

</script>
<?php }
 ?>


 <?php if (isset($_GET['refresh']) || isset($_GET['newpg']) || (isset($_GET['newpg']) && isset($_GET['fast']))) { ?>
	loadFromIndexedDB(storeName, key, databaseName).then(function (resolve) {



		<?php if (isset($_GET['refresh']) || (isset($_GET['newpg']) && isset($_GET['fast']))) { ?>
	arry = JSON.parse(resolve['id']);
	console.log(arry);
	
<?php } ?>
<?php if (isset($_GET['newpg']) && isset($_GET['fast'])) { ?>
	

     arry['qAnsw'] = JSON.parse(sessionStorage.getItem(<?php echo '"page' . $_SESSION['page'] . '"'; ?>));
	
	
	if (arry['qAnsw'] === null) {

	var qAnsw;
	 qAnsw = {qNumeral: {
	<?php for ($i = 0; $i < $_SESSION['sourcedQuestions']; $i++) {
		?>
	  <?= $i ?>: {right: 0, wrong: 0,},
	<?php } ?>
	
	}, length: <?= $_SESSION['sourcedQuestions'] ?>,};
arry['qAnsw'] = qAnsw;
	}
  	 
				var numeral;
				arry['fast'] = arr['fast'];
				 if (arr.hasOwnProperty('info')) {
					
		for (var i = 0; i < arry.qLength ; i++) {
	   arry['numeral'] = {};
	   arry['qr'] = {};
	   
   }			 





		arry['qr'] = {};
		for (let i = 0; i < arry.qLength ; i++) {
	   arry['numeral'][i] = 0;
	   arry['qr']['a'+i] = 0;
	   
		} 
	
	
	} 
	console.log('first');

   <?php } else { ?>
console.log('second');

	arry['qAnsw'] = JSON.parse(sessionStorage.getItem(<?php echo '"page' . $_SESSION['page'] . '"'; ?>));
	var qAnsw = arry['qAnsw'];
	<?php } ?>
			arry['numeral'] = {};
				for (var i = 0 ; i < arry.qLength; i++ ) {						
						arry['fast'] = arr['fast'];
						arry['numeral'][i] = arr['numeral'][i];
			   		if (typeof arr['info'] != 'undefined') {
						arry['a' + i][arr['runs']-1] = arr['info'][i];
					}
				} 
	
	
			
	
			sessionStorage.setItem('numeral', JSON.stringify(arry['numeral']));
			sessionStorage.setItem('rem', arr['numeralOfRem']);
		let qr = {};
		qr = sessionStorage.getItem('qr');
		console.log('below');
		console.log(qr);
		arry['qr'] = JSON.parse(qr);	
		
	
	
sessionStorage.setItem('status', JSON.stringify(arry));
sessionStorage.setItem('status2', JSON.stringify(arr));
sessionStorage.setItem(<?php echo '"page' . $_SESSION['page'] . '"'; ?>, JSON.stringify(arry['qAnsw']));

var object = arry;
window.location.replace('/questionnaire.php?buffer=yes&page=<?= $_SESSION['page'] ?><?php if (isset($_GET['fast'])) { echo '&fast=yes'; } ?>');
 
}).catch(function (error) {
 
	sessionStorage.setItem('pass', 'catch');


 console.log('here again');
                 console.log(arr);
				 console.log(arry);
              
              
  
				 var numeral;
	 
		
					if (arr.hasOwnProperty('info')) {
		for (let i = 0; i < arry.qLength ; i++) {
	   arry['numeral'][i] = 0;
	   arry['qr']['a'+i] = 0;
	   arry['numeralOfRem'] = arr['numeralOfRem'];
	   
   }			 
	// may need to put fast elsewhere; 
					 let counter = 0;
					 for (var i = 0 ; i < arry.qLength; i++ ) {
						arry['fast'] = arr['fast'];
						arry['numeral'] = arr['numeral'];
			   		if(typeof arr['info'] != 'undefined') {
						arry['a' + i][arr['runs']-1] = arr['info'][i];
					}
				} 
			}


arry['qr'] = {};  
for (let i = 0; i < arry.qLength ; i++) {
	 
	arry['qr']['a'+i] = 0;
	   

	}




	<?php 
if (isset($_SESSION['reset']) && !isset($_SESSION['cId'.$_SESSION['site']['cId']]['subject'.$_SESSION['subject']]['page'.$_SESSION['page']])) {
?>
var reset = 'yes';

<?php 
$_SESSION['cId'.$_SESSION['site']['cId']]['subject'.$_SESSION['subject']]['page'.$_SESSION['page']] = 'set';
// echo $_SESSION['cId'.$_SESSION['site']['cId']]['subject'.$_SESSION['subject']]['page'.$_SESSION['page']];

unset($_SESSION['reset']);
} else { 
	?>
var reset = 'no';
	<?php
}
?>


if (reset == 'yes') {
	var qAnsw = {qNumeral: {
	<?php for ($i = 0; $i < $_SESSION['sourcedQuestions']; $i++) {
		?>
	  <?= $i ?>: {right: 0, wrong: 0,},
	<?php } ?>
	
	}, length: <?= $_SESSION['sourcedQuestions'] ?>,};
arry['qAnsw'] = qAnsw;
} else {
    arry['qAnsw'] = JSON.parse(sessionStorage.getItem(<?php echo '"page' . $_SESSION['page'] . '"'; ?>));
	
}	




console.log(arry);
sessionStorage.setItem('numeral', JSON.stringify(arry['numeral']));
sessionStorage.setItem('rem', arr['numeralOfRem']);
sessionStorage.setItem('status', JSON.stringify(arry));	 
sessionStorage.setItem('status2', JSON.stringify(arr));
sessionStorage.setItem(<?php echo '"page' . $_SESSION['page'] . '"'; ?>, JSON.stringify(arry['qAnsw']));

	 var object = arry;
 window.location.replace('/questionnaire.php?buffer=yes&page=<?= $_SESSION['page'] ?><?php if (isset($_GET['fast'])) { echo '&fast=yes'; } ?>');

console.log("it got here");





}); 
</script>








<?php		
}

}
}
		
		
		
		if (isset($_GET['buffer'])) {
?>
<script type="module">
import {runOne, saveToIndexedDB, loadFromIndexedDB, } from './src/loadMod.js';
<?php if (!isset($_SESSSION['fast'])) { ?> 

var databaseName = "QuestionnaireClass<?= $_SESSION['site']['cId'] ?>";
var key = "qS<?= $_SESSION['subject'] ?>C<?= $_SESSION['site']['cId'] ?>P<?= $page ?? 1?>";
var storeName = "QuestionnaireSubject<?= $_SESSION['subject'] ?>Class<?= $_SESSION['site']['cId'] ?>Page<?= $_SESSION['page'] ?>";
<?php } ?>

var numeral = sessionStorage.getItem('numeral');
var rem = sessionStorage.getItem('rem');
var arry = sessionStorage.getItem('status');
var arr = sessionStorage.getItem('status2');
var qAnsw = sessionStorage.getItem('qAnsw');
let qr = sessionStorage.getItem('qr');
let arry2 = JSON.parse(arry);
var  qAnsw = sessionStorage.getItem(<?php echo '"page' . $_SESSION['page'] . '"'; ?>);
arry2['qAnsw'] = JSON.parse(qAnsw);

console.log(arry2['qAnsw']);
numeral = JSON.parse(numeral);
arry2.numeral = numeral;
console.log(arry2);
let result = runOne(arry2, rem);
console.log(result);
sessionStorage.setItem('status', JSON.stringify(result));

// <?php if (!isset($_SESSSION['fast'])) { ?> 
	let arry3 = JSON.stringify(result);

saveToIndexedDB(storeName, {id: arry3}, key, databaseName);

// }
<?php } ?>
</script>
	<div style="text-align: center;">
	<?php
}
	
	$end = microtime(true);
		echo ($end - $start);
} 
	?>
	</div>
</div>
</div>


<?php
if (isset($_SESSION['layoutOfSite']['enableMovingBars'])) {
    if ($_SESSION['layoutOfSite']['enableMovingBars'] == 1) {
 
?>
<div id="rightLowerSidebar" class="rightLowerSidebar">
	
	</div>
	</div>
	</div>

<?php

    }
}

if ($_SESSION['totalPages'] > 1 && isset($_GET['buffer'])) {
?>




<div id="pagination" class="pagination">
	<div class="pageWidthPombw">
<?php 
$questionnaire = "questionnaireBuf.php";
$option = ''; 
echo get_pagination_links($_SESSION['page'], $_SESSION['totalPages'], $questionnaire, $option);
?> 
</div>
</div>

<?php } ?>
</body>
</html>