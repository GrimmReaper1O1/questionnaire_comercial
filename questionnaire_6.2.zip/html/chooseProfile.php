<?php
include "includes/headerStyle.php";
  ?>
<br><br><br><br><br>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_GET['nonupdate'])) {
    if (isset($_POST['yes'])) {
    $cms->getMember()->updateUserStyle();
    unset($_SESSION['styleId']);
    header("Location: classes.php");
    exit;
    }
}
}

if (isset($_GET['update'])) {
 
    $_SESSION['styleId'] = $_GET['id'];
 


?>
<div class="main">
<?php 
if (isset($_SESSION['layoutOfSite']['disableMovingBars'])) {
	if ($_SESSION['layoutOfSite']['disableMovingBars'] == 0) {
		?>
		<div class="heightHeader">
		</div>
		<?php
	}

}

?>
<div class="mainbody">
    <div class="margin80">
        
    <div class="centeredText"><?php echo $_SESSION['styleId']; ?>
<br><br>
<h2>Are you sure you are happy with this style?</h2>
<form id="form1" action="chooseProfile.php?nonupdate=yes" method="POST">

    <button form='form1' type="submit" name="yes" >Yes!</button>&nbsp;
    <button form='form1' type="submit" name="no" >No! </button>
</form>
        </div>
    </div>
</div>
</div>

</div>
<?php
}




if (!isset($_GET['update']) && !isset($_GET['nonupdate'])) {
   $results = $cms->getMember()->selectStyles();
   ?>


<div class="main">
<?php 
if (isset($_SESSION['layoutOfSite']['enableMovingBars'])) {
    if ($_SESSION['layoutOfSite']['enableMovingBars'] == 1) {
		?>
		<div class="heightHeader">
		</div>
		<?php
	}

}

?>
    <div class="margin80">
        <div class="centeredText">
<?php
if ($results !== false) {
foreach ($results as $styles) {
     ?>
<p>
<a href="chooseProfile.php?update=yes&id=<?= $styles['id'] ?>"><?= $styles['profile_name'] ?></a><br>
</p>

<?php
}
}
?>
        </div>
    </div>
    <?php
    if (isset($_SESSION['layoutOfSite']['disableMovingBars'])) {
    if ($_SESSION['layoutOfSite']['disableMovingBars'] == 1) {
 
?>
<div id="rightLowerSidebar" class="rightLowerSidebar">
	
	</div>

<?php

    }
}

?>
</div>
</div>
<?php
}
?>
</body>
</html>