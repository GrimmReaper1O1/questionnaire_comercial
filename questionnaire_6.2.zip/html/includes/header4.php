<?php
require '../../src/bootstrap.php';
if (isset($_SESSION['administrator']['admin'])) {
	if (isset($_GET['cId'])) {
		$_SESSION['site']['cId'] = $_GET['cId'];
		
	}
	$start = microtime(true);
   if (!isset($_SESSION['layoutOfSite']['disableMovingBars'])) {
	$_SESSION['layoutOfSite']['disableMovingBars'] = 0;
   }
   
	$siteH = "Questionnaire! " . "<a href='../classes.php?reset=yes'>Classes</a> | <a href='../bioOne.php'>Results</a> |";
	if ($_SESSION['administrator']['admin'] != 1) { 
	$siteH = $siteH . ' | <a href="../library/library.php">Library</a> ';  }  
	if ($_SESSION['administrator']['admin'] == 1) { $siteH = $siteH . '| <a href="../library/library.php">Students Library</a> '; } 
	$siteH = $siteH . ' | <a href="../enterMathematics.php">Mathematics</a> | <a href="../changeInfo.php">Settings</a> | <a href="../contactUs.php">Contact Us</a> ';
	
	if ($_SESSION['administrator']['admin'] == 1) {
		if ($_SESSION['administrator']['root'] == 1) {
			$siteH = $siteH . ' | <a href="adminLibrary/upload_pdf.php">Upload to library</a>';
		}
		$siteH = $siteH . " | <a href='userAdmin/set_administrator_options.php'>Administer users, library, and classes</a> | <a href='classes.php'>Administer classes</a>"; } 
		
		$siteH = $siteH . ' | <a href="../logout.php">Sign Out</a>';
	
   $length = strlen($siteH);
   
	if (!isset($_SESSION['hobbip'])) { 
		$_SESSION['layoutOfSite']['hobbip'] = $_SESSION['layoutOfSite']['hobbip'] ?? 60; 
		$_SESSION['layoutOfSite']['porsw'] = $_SESSION['layoutOfSite']['porsw'] ?? 7;
		$_SESSION['layoutOfSite']['polsw'] = $_SESSION['layoutOfSite']['polsw'] ?? 7;
		$_SESSION['layoutOfSite']['pombw'] = $_SESSION['layoutOfSite']['pombw'] ?? 86;
   }
	if ($_SESSION['layoutOfSite']['hobbip'] > 60) {
	
		if ($length < 20 && $length >= 10 ) {
			$height2 = ceil((floatval($_SESSION['layoutOfSite']['hobbip']) -4) / 2);
			} elseif ($length < 50 && $length >= 20 ) {
	$height2 = ceil((floatval($_SESSION['layoutOfSite']['hobbip']) -4) / 3);
	} elseif ($length < 60 && $length >= 50) {
		$height2 = ceil((floatval($_SESSION['layoutOfSite']['hobbip']) -4) / 3.5);
	
	} elseif ($length < 80 && $length >= 60) {
		$height2 = ceil((floatval($_SESSION['layoutOfSite']['hobbip']) -4) / 4.5);
	
	} elseif ($length < 100 && $length >= 80) {
		$height2 = ceil((floatval($_SESSION['layoutOfSite']['hobbip']) -4) / 5.5);
	
	} elseif ($length < 120 && $length >= 100) {
		$height2 = ceil((floatval($_SESSION['layoutOfSite']['hobbip']) -4) / 6.5);
	
	} else {
		$height2 = ceil((floatval($_SESSION['layoutOfSite']['hobbip']) -4) / 1.5);
	}
	} elseif ($_SESSION['layoutOfSite']['hobbip'] <= 60 && $length < 15 && ($_SESSION['layoutOfSite']['porsw'] + $_SESSION['layoutOfSite']['polsw']) >= 40) {
		$height2 = (intval($_SESSION['layoutOfSite']['hobbip']) -4);
	} elseif ($_SESSION['layoutOfSite']['hobbip'] <= 60 && $length >= 30  && ($_SESSION['layoutOfSite']['porsw'] + $_SESSION['layoutOfSite']['polsw']) >= 20) {
		$height2 = (intval($_SESSION['layoutOfSite']['hobbip']) -4) / 2;
	} elseif ($_SESSION['layoutOfSite']['hobbip'] <= 60 && $length >= 45  && ($_SESSION['layoutOfSite']['porsw'] + $_SESSION['layoutOfSite']['polsw']) >= 0) {
		$height2 = (intval($_SESSION['layoutOfSite']['hobbip']) -4) / 4;
	} else {
		$height2 = (intval($_SESSION['layoutOfSite']['hobbip']) -4);
	}
	if (!isset($_SESSION['layoutOfSite']['tWritting'])) {
	   $titleWritting = 'white';
	} else {
	   $titleWritting = $_SESSION['layoutOfSite']['tWritting'];
	}
	$_SESSION['layoutOfSite']['siteH2'] = '<span style="font-size: ' . $height2 . 'px; font-weith: bold; colour: ' . $titleWritting . ';">' . $siteH . '</span>';
	
	
	?>
	<!DOCTYPE html>
	<html>
	<title>questionnaire</title>
	
		<head>
		<meta http-equiv=”expires” content=”-1” />
		<meta http-equiv="Content-Type" 
		  content="text/html; charset=utf-8" />
		  <meta http-equiv="Content-Type" 
		  content="application/javascript; charset=utf-8" />
		  <link rel="stylesheet" type="text/css" href="../CSS/styleSheet.css"   />
		
			<style> 
			
  a {color: <?= $_SESSION['layoutOfSite']['writing'] ?? 'white' ?> !important;}
 a:visited {color: <?= $_SESSION['layoutOfSite']['writing'] ?? 'white' ?> !important;}
 a:hover {color: <?= $_SESSION['layoutOfSite']['writing'] ?? 'white' ?> !important;}
 a:active {color: <?= $_SESSION['layoutOfSite']['writing'] ?? 'white' ?> !important;}
 body {
 color: <?= $_SESSION['layoutOfSite']['writing'] ?? 'white' ?>;
 background-color: <?= $_SESSION['layoutOfSite']['mbc'] ?? 'blue' ?>;
 height: 100%; 
 margin: 0px;
 }
 
 
 

 .mainTitleBar { 
	<?php
	if (isset($_SESSION['layoutOfSite']['enableMovingBars'])) { ?>
	 color: <?= $_session['layoutOfSite']['tWriting'] ?? 'white' ?>; 
	 height: <?= $_SESSION['layoutOfSite']['hobbip'] ?? '60' ?>px;  
	<?php
	
		 if ($_SESSION['layoutOfSite']['disableMovingBars'] == 1) {
		 ?>
			 position: fixed;
			 top: 0;
			 left: 0;
			 z-index: 10;
		 <?php
		 }
	 } else {
		 ?>
		position: fixed;
		top: 0;
		left: 0;
		z-index: 10;
		color: white;
		height: 60;
	 <?php
	 }
 
	 ?>
	 }

	 .leftInnerTitleBar {
 
 <?php if (isset($_SESSION['layoutOfSite']['ecb'])) { if ($_SESSION['layoutOfSite']['ecb'] == 1) { ?>
	background-image: url('<?= "../uploads/" . $_SESSION['layoutOfSite']["cbp"] ?? ""?>');
	background-size: contain; 
	background-repeat: no-repeat; 
	 <?php } 
} ?>   
	border-bottom: 3px solid <?= $_SESSION['layoutOfSite']['lBarc'] ?? 'black' ?>; 
	height:  <?= $_SESSION['layoutOfSite']['hobbip'] -2 ?? '28' ?>px; 
	width: <?= $_SESSION['layoutOfSite']['polsw'] ?? '7' ?>%;  
	background-color: 
	<?php
		if (isset($_SESSION['layoutOfSite']['efhb'])) {
		if ($_SESSION['layoutOfSite']['efhb'] == 1) {
	  if ($_SESSION['layoutOfSite']['els'] == 1) { ?> <?=  $_SESSION['layoutOfSite']['lBarc'] . '; border-bottom: 3px solid ' . $_SESSION['layoutOfSite']['lBarc'] ?> ; <?php } else { ?> <?= $_SESSION['layoutOfSite']['tc'] ?>;  border-bottom: 3px solid <?= $_SESSION['layoutOfSite']['lBarc'] ?> ;<?php } 
}  else { ?>
		<?= $_SESSION['layoutOfSite']['tc'] ?>; border-bottom: 3px solid <?= $_SESSION['layoutOfSite']['mboc'] ?> ;


	<?php }} else { ?> blue; <?php } ?>	
	 }

.middleTitleBar {

 <?php 
	if (isset($_SESSION['layoutOfSite']['dmbpb'])) {
	if ($_SESSION['layoutOfSite']['dmbpb'] == 0) { ?>
	 background-image: url('<?= "../uploads/" . $_SESSION['layoutOfSite']['mbp'] ?? '' ?>'); 
	 background-size: contain; 
	 background-repeat: no-repeat; 
	 <?php } 
} ?>   
	 width: <?= $_SESSION['layoutOfSite']['pombw'] ?? '86' ?>%; 
	 height:  <?= $_SESSION['layoutOfSite']['hobbip'] -2 ?? '28' ?>px; 
	 background-color: <?= $_SESSION['layoutOfSite']['tc'] ?? 'blue' ?>; 
	 border-bottom: 3px solid <?= $_SESSION['layoutOfSite']['mboc'] ?? 'black' ?>; 
	 color: <?= $_SESSION['layoutOfSite']['tWritting'] ?? 'white' ?> !important;

}

.rightTitleBar {
 border-bottom: 3px solid <?= $_SESSION['layoutOfSite']['mboc'] ?? 'black' ?>;  
 width: <?= $_SESSION['layoutOfSite']['porsw'] ?>%; 
 height:  <?= $_SESSION['layoutOfSite']['hobbip'] -2 ?? '28' ?>px; 
 background-color: 
 <?php
	if (isset($_SESSION['layoutOfSite']['efhb'])) {
	if ($_SESSION['layoutOfSite']['efhb'] == 1) {
		if ($_SESSION['layoutOfSite']['ers'] == 1) { ?> <?= $_SESSION['layoutOfSite']['lBarc'] . '; border-bottom: 3px solid ' . $_SESSION['layoutOfSite']['rSideColour'] ?>; <?php } else { ?><?= $_SESSION['layoutOfSite']['tc'] ?>; ; border-bottom: 3px solid <?= $_SESSION['layoutOfSite']['mboc'] ?> ;<?php } } 
	   else { ?>
		<?= $_SESSION['layoutOfSite']['tc'] ?>; border-bottom: 3px solid <?= $_SESSION['layoutOfSite']['mboc'] ?> ;

	  <?php } } else { ?> blue; <?php }	
	?>
}

 .leftLowerSidebar {
  width: <?= $_SESSION['layoutOfSite']['polsw'] ?? "7" ?>%;  
  background-color: <?= $_SESSION['layoutOfSite']['lBarc'] ?? 'black' ?>;
 <?php if (isset($_SESSION['layoutOfSite']['disableMovingBars'])) {
	 if ($_SESSION['layoutOfSite']['disableMovingBars'] == 1) {
		 ?>
		 position: fixed;
		 left: 0;
		 top: 0;
		 z-index: 9;
		 height: 100%;
		 <?php
	 } else {
		 ?>
	 display: flex;
     
	 overflow: auto;
		 <?php
	 }
 } else {
	 ?>
	 position: fixed;
	 left: 0;
	 top: 0;
	 z-index: 9;
	 height: 100%;
	 <?php
 }
 ?>
 }
 .mainbody {
	-webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
	<?php
if (isset($_SESSION['layoutOfSite']['enableBackgroundPicture'])) {
if ($_SESSION['layoutOfSite']['enableBackgroundPicture'] == 1) { ?>
		background-image: url('<?= "../uploads/" . $_SESSION['layoutOfSite']['mabp'] ?? '' ?>'); 
		background-size: contain; 
		background-repeat: no-repeat; 
		<?php } 
}
?>
}

 .main {

	width: <?= $_SESSION['layoutOfSite']['pombw']  ?? '86' ?>%;
	
	
	<?php

if (isset($_SESSION['layoutOfSite']['disableMovingBars'])) {
	if ($_SESSION['layoutOfSite']['disableMovingBars'] === 0) {
		?>
		box-sizing: border-box;
		display: flex;
     
	 overflow: auto;
		
		<?php
	} else {
		?>
		margin: 0 auto;
	<?php
	}
} else {
	?>
	margin: 0 auto;
<?php
}
?>

}
.rightLowerSidebar {
	 width: <?= $_SESSION['layoutOfSite']['porsw'] ?? '7' ?>%; 
	 
	 background-color: <?= $_SESSION['layoutOfSite']['rSideColour'] ?? 'black' ?>;
	 <?php if (isset($_SESSION['layoutOfSite']['disableMovingBars'])) {
	 if ($_SESSION['layoutOfSite']['disableMovingBars'] == 1) {
		 ?>
		 position: fixed;
		 right: 0;
		 top: 0;
		 z-index: 9;
		 height: 100%;
		 <?php
	 } else {
		 ?>
	 display: flex;
     
	 overflow: auto;
		 <?php
	 }
 } else {
	 ?>
	 position: fixed;
	 right: 0;
	 top: 0;
	 z-index: 9;
	 height: 100%;
	 <?php
 }
 ?>
 }
.pagination {
	width: <?= $_SESSION['layoutOfSite']['pombw'] ?? '' ?>%;
	background-color: <?= $_SESSION['layoutOfSite']['mbc'] ?? 'blue' ?>;

}
.heightHeader {
		height: <?= $_SESSION['layoutOfSite']['hobbip'] ?? 60 ?>px;
		width: 100%;
	}




	#content {

        height:100%;
        padding: 0px 0;
        overflow: hidden;
    }

    .full-height {    
      height: 100%;  
      width: 100%;
    
      display: flex;
      overflow: auto;
    }
 
    
  

 
    
  


    
</style>
</head>
	<body>





	<div id="mainTitleBar" class="mainTitleBar">
			<div id="leftInnerTitleBar" class="leftInnerTitleBar">
				</div>
			
			   
			<div id="middleTitleBar" class="middleTitleBar"><?= $siteH ?? 'Questionniare!'  ?>
			</div>
			<div id="rightTitleBar" class="rightTitleBar">
			</div>
			
			
 
		</div>






		<?php 

 if (isset($_SESSION['layoutOfSite']['disableMovingBars'])) {
	 if ($_SESSION['layoutOfSite']['disableMovingBars'] == 1) { 
	?>
	<div class="full-height">
	<?php
	if ($_SESSION['layoutOfSite']['dls'] == 0) { ?>
		 <div id="leftLowerSidebar" class="leftLowerSidebar">
 
		 </div>
		 <?php } 
	if ($_SESSION['layoutOfSite']['drs'] == 0) {
		 ?>

		 <div id="rightLowerSidebar" class="rightLowerSidebar">
		 
		 </div>
 <?php
	}
 } else {
	 ?>
	 <div class="content">
<div class="full-height">
		 <div id="leftLowerSidebar" class="leftLowerSidebar">
 
		 </div>
	 <?php
 }
 } else { ?>
	 
	<div id="leftLowerSidebar" class="leftLowerSidebar">

	</div>
	<div id="rightLowerSidebar" class="rightLowerSidebar">
	
	</div><?php
} ?>

<?php

} else {
	header('login.php');
	exit();
}