<?php
?>
<html>
    <head><meta http-equiv=”expires” content=”-1” />
	<meta http-equiv="Content-Type" 
      content="text/html; charset=utf-8">
	  <meta http-equiv="Content-Type" 
      content="application/javascript; charset=utf-8">
	<link href="CSS/styleSheet.css" rel="stylesheet" type="text/css">
	</head>
    <body>
    <h1><a href="login.php">Log In!</a> | <a href="index.php">Back To Main Page!</a></h1>