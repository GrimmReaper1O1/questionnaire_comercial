<?php
?>
<html>
    <body>
        
<div style="float: left; width: 80%">
<div style="width: 50%;">
<div style="color: black; background: white; width: 100% padding: 25%;">Name of website.</div>
<div style=" color: white; width: 100%; height: 30px; margin: 0 auto; height: 30px; background-color: blue;  border-bottom: 1px solid black; ">
<div style="float: left; display: inline-block; height: 100%; width: 7%; background-color: blue; border-bottom: 2px solid black;"></div><div style="float: left; display: inline-block; width: 86%; text-align: center;">Quesitonnaire!</div><div style="float: left; display: inline-block; width: 7%; background-color: blue; height: 100%; border-bottom: 2px solid black;"></div>
</div>
<div style="float: left; width: 7%; height: 400px; background-color: black;">
</div>
<div style=" display: inline-block; float: left; width: 86%; height: 400px; background-color: blue;">
<div style="display: block; height: 370px; width: 100%; margin: 0 auto; ">    
<div style="text-align: center;">
<br><br><br>
<h7> THIS IS YOUR TEXT COLOUR.</h7><br><p>
    <a style="position: relative; color: white;" href="colourChange.php">Link colour</a><p><br></div>
    <div style="text-align: justified !important;"><p>This is some writing and it shows where the text is, so it needs to be here. Please don't complain about the content.</p>
</div>
</div>

<div style="position: relative; color: white; width:100% height: 30px; text-align: center;">-1-2-3-</div>
</div>
<div style="position: relative; float: left; width: 7%; height: 400px; background-color: black;">
</div>
</div>
</div>
</div>
</div>
</div>
</div>




</div>
<div style="float: left; width: 20%">


</div>
</div>