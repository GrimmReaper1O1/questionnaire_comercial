<?php
include '../includes/header4.php';
if ($_SESSION['administrator']['admin'] == 1) {
$error = '';
$error2 = '';
$message = '';
if (isset($_GET['delete'])) {
	$cms->getQuestions()->deleteVideo();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

$moved = false;


		try {
    $upload_path = '../uploads/';
    $max_size = 25000000000;
    $allowed_types = ['video/webm',];
    $allowed_exts = ['webm',];

      $error2 = ($_FILES['file']['size'] <= $max_size) ? '' : 'Your file is too large. It must be under 2MB';
      $type = mime_content_type($_FILES['file']['tmp_name']);
      $error2 .= in_array($type, $allowed_types) ? '' : 'Your file is of the wrong type. It must be a pdf, doc, docx, odt, txt, or rtf.';
      $ext = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
      $error2 .= in_array($ext, $allowed_exts) ? '' : 'It must have the right file extension.';

       if ($error2 === '') {
        $filename = create_filename($_FILES['file']['name'], $upload_path);
        $destination = $upload_path . $filename;
        $moved = move_uploaded_file($_FILES['file']['tmp_name'], $destination);


       }

} catch (Error $e) {
    $error .= "You didn't select a file.";
}
       if ($moved === true) {


  try {



      $result = $cms->getQuestions()->deleteVideo();

      if ($result[1] > 0) {
        $message .= 'The videos database entry was deleted. <br>';
      }

			if ($result[0] == true) {
				$message .= 'The previous video was also deleted. <br>';
			}


	    $cms->getQuestions()->insertVideo($filename, $_POST['alt'], $_SESSION['id']);
		$message .= "Your document updated successfully! ";




  	} catch(Exception $e) {
        $error2 .= "We're sorry! There was a problem. Please try again.";
   }

   }

}

$video = $cms->getQuestions()->selectVideo();


?>
<div class="heightHeader"></div>
<div id="main" class="main mainbody">
	<div style="text-align: right !important;">
		<div class="inline width20">
		<br><br>
		<span><a href="introductionToSubject.php?id=<?= $_SESSION['subject'] ?>">BACK TO INTRODUCTION!</a></span>
		<br><br>
	</div>
</div>
<?php
if ($video != false) {
?>
<br><br><br>

	<div class="centeredText">
		<video style="width: 80%; display: inline-block;"  poster="<?= $row['posterFilename'] ?? '' ?>"
		id="subjectVideo"
		type="video/webm" preload="auto"
		controls >

		<source src="../uploads/<?= $video['file_name'] ?? '' ?>" type="video/mp4" />
		<source src="../uploads/<?= $video['file_name'] ?? '' ?>" type="video/webm" />
	</video><br>
	</div>
<?php } ?>

<br>
<div class="centeredText">
	<?php
	if ($video != false) {
	?>

	<span> <a href="uploadVideo.php?delete=<?= $video['id'] ?>">DELETE VIDEO!</a></span>
<?php
}
?>
</div>
<br>
<br>
<?php


 echo $message . $error2 . $error;  ?>
<form id='apendix' action="uploadVideo.php" method="POST" enctype="multipart/form-data">
  <label>Description of video:</label><input type="text" name="alt" /><br>
<label>Video file choice:</label><input type="file" name="file" /><br>
<button form="apendix" type="submit">Submit!</button>
</form>


<div class="addHeight">
</div>
</div>
<?php
include '../includes/footer4.php'; ?>
</body>
</html>





<?php
} else {
  header('Location: ../classes.php');
}
