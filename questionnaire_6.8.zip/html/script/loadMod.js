//
// async function loadFromIndexedDB(storeName, key, database){
//     return new Promise(
//       function(resolve, reject) {
//         dbRequest = indexedDB.open(database);
//
//         dbRequest.onerror = function(event) {
//           var database    = event.target.result;
//           reject(error('the request failed'));
//         }
//
//         dbRequest.onupgradeneeded = function(event) {
//           // Objectstore does not exist. Nothing to load
//           event.target.transaction.abort();
//           alert('on upgrade needed');
//           reject(Error('Not found'));
//
//         }
//
//         dbRequest.onsuccess = function(event) {
//           var database      = event.target.result;
//           var transaction   = database.transaction([storeName], 'readwrite');
//           var objectStore   = transaction.objectStore(storeName);
//           var objectRequest = objectStore.get(key);
//           // alert('got to dbRequest success');
//           // transaction.addEventListener("error", () => {
//           //   alert('error getting new item');
//           // });
//
//                     objectRequest.onsuccess = function(event) {
//                       // alert('went on success')
//                       if (objectRequest.result) {
//                         // alert('resolving'); console.log(objectRequest.result);
//                         setTimeout(() => (resolve(objectRequest.result)), 5000);
//                       } else { reject();}
//
//                     }
//           transaction.onerror = function(event) {
//             alert('went on error');
//           }
//
//           objectRequest.onerror = function(event) {
//             // var database    = event.target.result;
//             // alert('says error')
//             // reject(Error('problem'));
//
//           }
//
//         }
//
//       }
//     )
//
//   }
async function loadFromIndexedDB(storeName, key, database) {
    return new Promise((resolve, reject) => {
        const dbRequest = indexedDB.open(database);

        dbRequest.onerror = (event) => {
            console.error('Database error:', event);
            reject(Error('Database open failed'));

        };

        dbRequest.onupgradeneeded = (event) => {
            const db = event.target.result;
            if (!db.objectStoreNames.contains(storeName)) {
                db.createObjectStore(storeName, { autoIncrement: true });
            }
            // Optionally reject if you want to stop loading when upgrade is needed

            reject(Error('Database upgrade needed'));
        };

        dbRequest.onsuccess = (event) => {
            const db = event.target.result;
            const transaction = db.transaction([storeName], 'readwrite');
            const objectStore = transaction.objectStore(storeName);
            const objectRequest = objectStore.get(key);

            objectRequest.onsuccess = (event) => {
                if (objectRequest.result) {

                  setTimeout(() => (resolve(objectRequest.result)),);
                } else {
                    reject(Error('No data found for key: ' + key));
                }
            };

            objectRequest.onerror = (event) => {
                console.error('Object request error:', event);
                reject(Error('Error retrieving object'));

            };

            transaction.onerror = (event) => {
                console.error('Transaction error:', event);

                reject(Error('Transaction failed'));
            };
        };
    });
}

  function h4 (text) {
    var elemented = "<h4>" + text + "</h4>";
    return elemented;
  }
  function paragraph(text) {
    var para = "<p>"+text+"</p>";
    para.textContent = text;
    return para;
  }
  function paragraphs(text) {
  var paragraphs = text.split(/\r\r|\r\n/);

  var htmlParagraphs = [];

  paragraphs.forEach(function(paragraphText) {
    paragraphText = paragraphText.trim();

    var htmlParagraph = "<p>" + paragraphText + "</p>";

    htmlParagraphs.push(htmlParagraph);
  });

  var htmlOutput = htmlParagraphs.join("");


    return htmlOutput;
  }


  function countValues(obj) {
    let count = 0;

    for (let key in obj) {

        count++;
      }

    return count;
  }


  function runOne (arry, numeralOfRemoval) {

document.addEventListener("DOMContentLoaded", function() {
const radioGroup = {}
for (var i = 0 ; i < arry.qLength ; i++) {
radioGroup[i] = {
    init: function() {
        const radioButtons = document.querySelectorAll('.r'+i+'adio-button');
        radioButtons.forEach(function(radioButton) {
            radioButton.addEventListener('click', function() {
                // Disable all other radio buttons
                radioButtons.forEach(function(rb) {
                    if (rb !== radioButton) {
                        rb.disabled = true;
                    }
                });
            });
        });
    },
}
radioGroup[i].init()
}
})
var text = '';
var newtext = '';
var finalText = '';
for (let i = 0 ; i <= (arry.qLength - 1); i++) {
var div1 = document.getElementById('a'+i);
if (arry) {
}       var key = {}
    key[i] = 'a' + i;
if (numeralOfRemoval != arry.qAnsw.rightAndWrong[i]['right']) {

text = arry1['a' + i][arry1['numeral'][i]]['question'];
newtext = paragraphs(text);
finalText = "Question: " + newtext;
for (let c = 1 ; c < 9 ; c++) {
var keyzero = {};
keyzero[c] = 'pa' + c;
if (arry1['a' + i][arry1['numeral'][i]][keyzero[c]] != 'empty') {
var text = arry1['a' + i][arry1['numeral'][i]][keyzero[c]];
newtext = paragraphs(text);
finalText += '<input type="radio" name="' + i + 'a' + c + '" class="r'+i+'adio-button" onclick="radioGroup['+i+']">' + "Answer: " + newtext;
var keyone = {};
    keyone[c] = 'hint' + c;
if (arry1['a' + i][arry1['numeral'][i]][keyone[c]] != 'empty') {
text = arry1['a' + i ][arry1['numeral'][i]][keyone[c]];
newtext = paragraphs(text);
finalText += "Hint: " + newtext;
            }
        }
    }
    div1.innerHTML += finalText;
} else {
    div1.innerHTML = "QUESTION COMPLETE!";
}
}
console.log('runhere');
return arry;
}



  function saveToIndexedDB(storeName, object, key, databaseName){
    return new Promise(
      function(resolve, reject) {
        if (object.id === undefined) reject(Error('object has no id.'));
        var dbRequest = indexedDB.open(databaseName);

        dbRequest.onerror = function(event) {
          reject(Error("IndexedDB database error"));
        };

        dbRequest.onupgradeneeded = function(event) {
          var database    = event.target.result;

        };

        dbRequest.onsuccess = function(event) {
          var database      = event.target.result;
          var transaction   = database.transaction([storeName], 'readwrite');
          var objectStore   = transaction.objectStore(storeName);
          var objectRequest = objectStore.put(object, key); // Overwrite if exists

          objectRequest.onerror = function(event) {
            reject(Error('Error text'));
          };

          objectRequest.onsuccess = function(event) {
            resolve('Data saved OK');

          };
          objectRequest.oncomplete = function(event) {
            var data = event.target.result;
            data.close();
          }
        };
      }
    );
  };

  async function updateDelDB(storeName, databaseName, version){
        var dbRequest = indexedDB.open(databaseName, version);

        dbRequest.onupgradeneeded = (event) => {
        var database    = event.target.result;

       database.createObjectStore(storeName, {autoincrement: true});



        };

        dbRequest.onsuccess = function(event) {

          var data = event.target.result;
          data.close();
        }

        dbRequest.onerror = function(event) {

          };

        };


        function openDB(storeName, databaseName){
          var dbRequest = indexedDB.open(databaseName);

          dbRequest.onupgradeneeded = function(event) {
            var database    = event.target.result;
            var objectStore = database.createObjectStore(storeName, {autoincrement: true});

          };

          dbRequest.onsuccess = function(event) {
          }

          dbRequest.onerror = function(event) {
              reject(Error('Error text'));
            };

          };
          function deleteDB(databaseName) {
          var db = indexedDB.deleteDatabase(databaseName);
          db.onsuccess = function (event) {

              window.location.replace('/questionnaire.php?reset=yes');

          }
          db.oncomplete = function (event) {
            var database = event.target.result;
            database.close();
          }

          db.onerror = function (event) {

          }
        }

        function createStoreDB(storeName, databaseName){
          var dbRequest = indexedDB.open(databaseName);

          dbRequest.onupgradeneeded = function(event) {

          };

          dbRequest.onsuccess = function(event) {
            var database    = event.target.result;
            var objectStore = database.createObjectStore(storeName, {autoincrement: true});

          }

          dbRequest.onerror = function(event) {
              reject(Error('Error text'));
            };

          };

          (function(){

console.log(storeName+key+databaseName);
            loadFromIndexedDB(storeName, key, databaseName).then(function (resolve) {
              arry1 = JSON.parse(resolve['id']);
              // it semes the above must be on the first line for it to function
              // var arr = JSON.parse(sessionStorage.getItem('arr'));
              // var arry1 = JSON.parse(sessionStorage.getItem('arry'));
              arry1.fast = 'yes';
              console.log(arry1);
              console.log(arr);
              console.log('above');

             // if ((refresh != 'undefined') || ((newpg != 'undefined') && (fast != 'undefined'))) {
            arry1 = JSON.parse(resolve['id']);
            console.log(arry1);
            // }

            if ((reset == 'yes') || ((newpg == 'yes') && (arry.fast == 'yes'))) {


               // arry1['qAnsw'] = JSON.parse(sessionStorage.getItem(pg));


          //   if (arry1['qAnsw'] === null) {
          //
          //     var qAnsw = {};
          //   qAnsw.rightAndWrong = {};
          //   for (var i = 0; i < sourcedQuestions; i++){
          //   qAnswq.numeral = { i: {right: 0, wrong: 0,},};
          // }




            }

                  var numeral;

                   if (arr.hasOwnProperty('info')) {

               arry1['numeral'] = {};
               arry1['qr'] = {};







              for (let i = 0; i < arry1.qLength ; i++) {
               arry1['numeral'][i] = 0;
               arry1['qr']['a'+i] = 0;

              }

} else {
            console.log('second');
            if (arr.hasOwnProperty('info')) {

        for (let i = 0; i < arry.qAnsw.length ; i++) {

        // arry.numeral[i] = 0;
        arry1.qr['a'+i] = 0;
        arry1.numeralOfRem = arr['numeralOfRem'];

        }
        // may need to put fast elsewhere;
             let counter = 0;
             for (var i = 0 ; i < arry1.qAnsw.length; i++ ) {
               arry1['a'+i] = {};
             }
             for (var i = 0 ; i <= arry1.qLength-1; i++ ) {

            if (typeof arr['info'][i] != 'undefined') {
                 for (var c = 1; c <= arr['maxNumeral'][i]+1; c++) {
                if ((c == arr['runs'])){
                 console.log(c+'numeral');

                 console.log(arry1['a'+i][0]);
                 arry1['a'+i][0][c-1] = arr['info'][i];
                 console.log(arr['info'][i]);

               }
              }
             }
           }
          }
        }
            var qAnsw = arry1['qAnsw'];
console.log('did it get here');
                             arry1['numeral'] = {};


                sessionStorage.setItem('numeral', JSON.stringify(arry1['numeral']));
                sessionStorage.setItem('rem', arr['numeralOfRem']);
              let qr = {};
              qr = sessionStorage.getItem('qr');
              console.log('below');
              console.log(qr);
              arry1['qr'] = JSON.parse(qr);

            arry1.numeral = arr.numeral;

            sessionStorage.setItem('arry', JSON.stringify(arry1));
            sessionStorage.setItem('arr', JSON.stringify(arr));

            var object = arry1;
            let localstring = '/questionnaire.php?buffer=yes&page='+ pageNo;
console.log(arry1);
            if (arry1['fast'] == 'yes') { localstring += '&fast=yes'; }
console.log('arry1 above');
console.log(pg);
            window.location.replace(localstring);
console.log('one');
}).catch(function (error) {
console.log(error);
console.log('is this it?');
            let reset = sessionStorage.getItem('res');
            let arr = JSON.parse(sessionStorage.getItem('arr'));
            let arry1 = JSON.parse(sessionStorage.getItem('arry'));
            let arryFirst = JSON.parse(sessionStorage.getItem('arryFirst'));
            let pg = sessionStorage.getItem('pg');
            let qAnsw = {};
            qAnsw.rightAndWrong = JSON.parse(sessionStorage.getItem(pg));

            console.log(newpg);


            console.log(arryFirst);
            console.log(arr);
            console.log(sessionStorage.getItem(';lk;l;lklk;;;k;;k;klklj'));
            console.log('above2');
            console.log(pg);
            if (reset == 'yes' || newpg == 'yes') {
              console.log('did it get here');
              sessionStorage.removeItem('res');
              arry1 = arryFirst;
              arry1.maxNumeral = arr['maxNumeral'];
            }

            console.log(arry1);
          sessionStorage.setItem('pass', 'catch');



          console.log(arry1);
          arry1.numeral = [];
          if (typeof arr['info'] != 'undefined') {
          console.log(arry1.qAnsw);
            for (let i = 0; i < arry1.qAnsw.length ; i++) {

             // arry.numeral[i] = 0;
             arry1.qr['a'+i] = 0;
             arry1.numeralOfRem = arr['numeralOfRem'];

           }
          // may need to put fast elsewhere;

            let counter = 0;
            console.log(arr);
                   for (var i = 0 ; i <= arry1.qLength-1; i++ ) {

                  if (typeof arr['info'][i] != 'undefined') {
                       for (var c = 1; c <= arr['maxNumeral'][i]+1; c++) {
                      if ((c == arr['runs'])){
                       console.log(c+'numeral');

                       console.log(arry1['a'+i][0]);
                       arry1['a'+i][0][c-1] = arr['info'][i];
                       console.log(arr['info'][i]);

                     }
                    }
                   }
                 }


                    arry1.numeral = arr['numeral'];

            }
          console.log(arry1);

          arry1['qr'] = {};
          for (let i = 0; i < arry1.qLength ; i++) {

          arry1['qr']['a'+i] = 0;


          }







          if (reset == 'yes') {




          sessionStorage.removeItem('reset');
          } else {
            arry1.qAnsw.rightAndWrong = JSON.parse(sessionStorage.getItem(pg));

          }

          var complete = 0;
          for (var i = 0; i < arry1.length; i++) {
            let counter = 0;
            for (var c = 0; c < arry1.maxNumeral[i]; c++) {
              if (typeof arry1['a'+i][0][c] != 'undefined') {
                counter++;
                console.log('got here one');
              }
              if (counter == arry1.maxNumeral[i]) {
                complete++;
                console.log(arry1.maxNumeral[i]+ " " + counter);
              }
            }
          }
          console.log('complete above');
          if (complete == arry1.length) {
            console.log('success');
          arry1['fast'] = 'yes';

          } else {
          arry1['fast'] = 'no';
          }
          arry1.db = arr.db;
          if (arry1['fast'] == 'yes') {
            console.log('got hereeo!');
            saveToIndexedDB(arry1.db.sN, {id: JSON.stringify(arry1)}, arry1.db.ky, arry1.db.dN);
            }
          arry1.numeral = arr.numeral;

          sessionStorage.setItem('numeral', JSON.stringify(arry1['numeral']));
          sessionStorage.setItem('rem', JSON.stringify(arr['numeralOfRem']));
          sessionStorage.setItem('arry', JSON.stringify(arry1));
          sessionStorage.setItem('arr', JSON.stringify(arr));
          sessionStorage.setItem(pg, JSON.stringify(arry1.qAnsw.rightAndWrong));
          console.log(arr);
          console.log(arry1);
           var object = arry1;
           console.log('arry1 below');
           console.log(arry1);
           let localstring = '/questionnaire.php?buffer=yes&page='+ pageNo;
           if (arry1['fast'] == 'yes') { localstring += '&fast=yes'; }
          // window.location.replace(localstring);
          console.log(localstring);




            });





          }())
