
async function loadFromIndexedDB(storeName, key, database) {
  return new Promise((resolve, reject) => {
    const dbRequest = indexedDB.open(database);

    dbRequest.onerror = (event) => {
      console.error('Database error:', event);
      reject(Error('Database open failed'));

    };

    dbRequest.onupgradeneeded = (event) => {
      var db = event.target.result;
      if (!db.objectStoreNames.contains(storeName)) {
        db.createObjectStore(storeName, {keyPath: 'id', autoIncrement: true });
      }
      // Optionally reject if you want to stop loading when upgrade is needed

      reject(Error('Database upgrade needed'));
    };

    dbRequest.onsuccess = (event) => {
      var db = event.target.result;
      var transaction = db.transaction([storeName], 'readwrite');
      var objectStore = transaction.objectStore(storeName);
      var objectRequest = objectStore.get(key);

      objectRequest.onsuccess = (event) => {
        if (objectRequest.result) {

          resolve(objectRequest.result);
        } else {
          reject(Error('No data found for key: ' + key));
        }
      };

      objectRequest.onerror = (event) => {
        console.error('Object request error:', event);
        reject(Error('Error retrieving object'));

      };

      transaction.onerror = (event) => {
        console.error('Transaction error:', event);

        reject(Error('Transaction failed'));
      };
    };
  });
}

function h4 (text) {
  var elemented = "<h4>" + text + "</h4>";
  return elemented;
}
function paragraph(text) {
  var para = "<p>"+text+"</p>";
  para.textContent = text;
  return para;
}
function paragraphs(text) {
  var paragraphs = text.split(/\r\r|\r\n/);

  var htmlParagraphs = [];

  paragraphs.forEach(function(paragraphText) {
    paragraphText = paragraphText.trim();

    var htmlParagraph = "<p>" + paragraphText + "</p>";

    htmlParagraphs.push(htmlParagraph);
  });

  var htmlOutput = htmlParagraphs.join("");


  return htmlOutput;
}


function countValues(obj) {
  let count = 0;

  for (let key in obj) {

    count++;
  }

  return count;
}


function saveToIndexedDB(storeName, object, key, databaseName){
  return new Promise(
    function(resolve, reject) {
      if (object.id === undefined) reject(Error('object has no id.'));
      var dbRequest = indexedDB.open(databaseName);

      dbRequest.onerror = function(event) {
        reject(Error("IndexedDB database error"));
      };

      dbRequest.onupgradeneeded = function(event) {db
        var database    = event.target.result;

        if (!database.objectStoreNames.contains(storeName)) {
          database.createObjectStore(storeName, { keyPath: 'id', autoIncrement: true   });
        }
      };

      dbRequest.onsuccess = function(event) {
        var database      = event.target.result;
        var transaction   = database.transaction([storeName], 'readwrite');
        var objectStore   = transaction.objectStore(storeName);
        var objectRequest = objectStore.put(object, key); // Overwrite if exists

        objectRequest.onerror = function(event) {
          reject(Error('Error text'));
        };

        objectRequest.onsuccess = function(event) {

          setTimeout(() => (resolve(event.target.result)),);

        };
        objectRequest.oncomplete = function(event) {
          var data = event.target.result;
          data.close();
        }
      };
    }
  );
};





function runOne (arry, numeralOfRemovaloval) {

  let layout = JSON.parse(localStorage.getItem('layout'));
  let text, newText, finalText;
  let $holdingDiv = $('#questions');
  let $div = {};
    
  for (let a = 0; a < arry.qLength; a++) {

  $div[a] = $('<div>',
  {
    class:  'individualQuestions',
  });

  }
  let $firstInnerDiv = {}, $secondInnerDiv = {}, $el = {};
  for (let i = 0; i < arry.qLength; i++) {

    for (let b = 0; b < 8 ;b++) {
      $el[b] = $('<input>', {
        type: 'radio',
        class: 'r'+i+'adio-button',
        name: i+'a'+(b),
        onclick: 'radioGroup['+i+']',
      } );
    }

    if (numeralOfRemovaloval != arry.qAnsw.rightAndWrong['a'+i]['right']) {

      let num = arry.numeral[i];

      let key = 'a'+i;

      text = arry[key][0][num]['question'];
      newtext = paragraphs(text);
      finalText = "Quesiton: " + newtext + ' <br>';

      $firstInnerDiv[i] = $('<div>').html(finalText);
      $secondInnerDiv[i] = $('<div>');
      let keyzero = {};
      let keyone = {};
      let text1, text2, text3, text4;
      for (let c = 1; c < 9 ;c++) {
        $secondInnerDiv[i].append($el[c]);
          text1 = '';
          text3 = '';
          text2 = '';
          text4 = '';
          keyzero[c] = 'pa' + c;
          keyone[c] = 'hint' + c;
          if (arry['a'+i][0][arry['numeral'][i]][keyzero[c]] != 'empty') {
            text1 = arry['a'+i][0][arry['numeral'][i]][keyzero[c]];
            text1 = 'Answer: ' + text1;
            text1 = paragraphs(text1);
            text2 = text1 + '<br>';
            $firstInnerDiv[i].append($el[c-1]);

          }
          if (arry['a'+i][0][arry['numeral'][i]][keyone[c]] != 'empty') {
          text3 = 'Hint: ' + arry['a'+i][0][arry['numeral'][i]][keyone[c]];
          text3 = paragraphs(text3) + '<br>';

        }
        text4 = text2 + text3;
        let span = {};
            span[c] = $('<span>').html(text4);
        $firstInnerDiv[i].append(span[c]);

    }
    $div[i].append($firstInnerDiv[i]);
    
  } else {
    
    $div[i].html('<h4>COMPLETE!</h4>');
    
    
  }
  
  $div[i].css({'color': layout.cotiqp, 'background-color': layout.coqaab, 'border': '3px solid ' + layout.qbc,'border-radius': '75px', 'width': layout.soqipip + "%", 'margin': '0 auto', 'padding': '40px', });
  $holdingDiv.append($('<div>').css({'height': '30px'}));
    $holdingDiv.append($div[i]);


  }


  let $button = $('<button>', {
    id: 'next',
  });
  $button.addClass('width100 marginAuto');
  $button.text('Submit!');
  let $centeredDiv = $('<div>');
  $centeredDiv.addClass('marginAuto width20');
  $centeredDiv.append($button);
  $holdingDiv.append($centeredDiv);



    let radioGroup = [];

    for (let i = 0 ; i < arry.qLength ; i ++ ) {
      radioGroup[i] = {
        init: function() {
          const $radioButtons = $('.r'+i+'adio-button');
          $radioButtons.click( function() {
          // When one radio button is checked, uncheck others with the same class
          if ($(this).is(':checked')) {
              $radioButtons.not(this).prop('disabled', true);
          }
      });
        }
      }
      radioGroup[i].init();
    }

  return arry;
  }




function runTwo (arry, posted) {
  let layout = JSON.parse(localStorage.getItem('layout'));
 

  let $div = $('#reply');
  
  let $div2 = {};
  let counter;
  for (var i = 0; i < arry.qLength; i++ ) {
    counter = 0;

    for (let c = 1 ; c < 9 ; c++ ) {
      key = (c-1);
     if(typeof posted[i][key] != 'undefined') {
      if (posted[i][key].checked == true) {
       
        $div2[counter] = $('<div>', {
          class: 'individualQuestions',
        });
      }


      if (posted[i][key].checked == true) {
        let text1 = arry['a' + i][0][arry['numeral'][i]]['question'];
        let text2 = arry['a' + i][0][arry['numeral'][i]]['answ' + c];
        let text3 = arry['a' + i][0][arry['numeral'][i]]['hint' + c];
        let text4 = arry['a' + i][0][arry['numeral'][i]]['pa' + c];
        let breakLine = '<br><br>';

        let question, answer, reply, hint;
        question = 'Question: ' + paragraphs(text1);
        answer = 'Answer given: ' + paragraphs(text4);
        reply = 'Reply: ' + paragraphs(text2);


        if (arry['a' + i][0][arry['numeral'][i]]['hint' + c] != 'empty') {

          hint = "Hint given: " + paragraphs(text3);

        } else {
          hint = 'empty';
        }
        $br = $('<br>');
        $div2[counter].append(question);
        $div2[counter].append($br)
        $div2[counter].append(answer);
        $div2[counter].append($br)
        $div2[counter].append(reply);
        $div2[counter].append($br)
        if (hint != 'empty') {
          $div2[counter].append(hint)
          $div2[counter].append($br);
        }
        if (arry['a' + i][0][arry['numeral'][i]]['correct'] === 'answ'+ c && posted[i][c-1].checked == true ) {


          arry['qAnsw']['rightAndWrong']['a'+i]['right']++;
        } else {
          arry['qAnsw']['rightAndWrong']['a'+i]['wrong']++;
        }
      }
    }
  }
    for (let c = 1 ; c < 9 ; c++ ) {

      key = (c-1);
      if(typeof posted[i][key] != 'undefined') {
      if (posted[i][key].checked == true) {
        $div2[counter].css({'color': layout.cotiqp, 'background-color': layout.coqaab, 'border': '3px solid ' + layout.qbc,'border-radius': '75px', 'width': layout.soqipip + "%", 'margin': '0 auto', 'padding': '40px', });
        // $div2[i].attr('style', 'color: ' + layout.cotiqp + ' !important;');
        $div.append($('<div>').css({'height': '30px'}));
        $div.append($div2[counter]);
        counter++;
      }
    }
  }
  }
  let $button = $('<button>', {
    id: 'reset',
  });
  $button.addClass('width100 marginAuto')
  $button.text('Next question set!');
  let $centeredDiv = $('<div>');
  $centeredDiv.addClass('marginAuto width20');
  $centeredDiv.append($button);
  $div.append($centeredDiv);
  
  arry['qAnsw'];
 

  return arry;
  
}



(function(){
  var arry1, arry;
    loadFromIndexedDB(storeName, key, databaseName).then(function (resolve) {
      arry1 = JSON.parse(resolve['id']);
  
      var complete = 0;
      for (var i = 0; i < arry1.length; i++) {
        let counter = 0;
        for (var c = 0; c < arry1.maxNumeral[i]; c++) {
          if (typeof arry1['a'+i][0][c] != 'undefined') {
            counter++;
          }
      console.log(counter+' '+(arry1.maxNumeral[i]));
          if (counter == arry1.maxNumeral[i]) {
            complete++;
            console.log(complete+' '+ arry1.maxNumeral[i]);
      
          }
        }
      }
      console.log(complete+' '+arry1.qLength)
      if (complete == arry1.qLength) {
      
        
        arry1['complete'] = 1;
        // saveToIndexedDB(arry1.db.sN, {id: JSON.stringify(arry1)}, arry1.db.ky, arry1.db.dN);
        console.log(complete+'got to complete'+arry1.qLength);
      } else {
        
      
      }
   
  
      console.log('arry1 below');
      console.log(arry1);
  
      var numeral;
      let reset = JSON.parse(sessionStorage.getItem('res'));
      
      
      
      if (reset[pageNo-1] == 1) {
        reset[pageNo-1] = 0;
        sessionStorage.setItem('res', JSON.stringify(reset));
        for (let i = 0; i < arry1.qLength; i++) {
          arry1.qAnsw.rightAndWrong['a'+i].right = 0;
          arry1.qAnsw.rightAndWrong['a'+i].wrong = 0;
          
        }
      }
   
      if (arr.hasOwnProperty('info')) {
        if (reset == 'yes') {
          arry1['numeral'] = {};
        arry1['qr'] = {};
      }
  
      arry1.runs = arr.runs;
  
  
  
  
        for (let i = 0; i < arry1.qLength ; i++) {
          // arry1['numeral'][i] = 0;
          arry1['qr']['a'+i] = 0;
  
        }
  
        for (var i = 0 ; i < arry1.qAnsw.length; i++ ) {
          arry1['a'+i] = {};
        }
        for (var i = 0 ; i <= arry1.qLength-1; i++ ) {
  
          if (typeof arr['info'][i] != 'undefined') {
            for (var c = 1; c <= arr['maxNumeral'][i]+1; c++) {
              if ((c == arr['runs'])){
  
                arry1['a'+i][0][c-1] = arr['info'][i];
  
              }
            }
          }
        }
      }
      
  
      
      sessionStorage.setItem(pg, JSON.stringify(arry1.qAnsw.rightAndWrong));
      
      
      // arry1['numeral'] = {};
  
      
      let qr = {};
      qr = sessionStorage.getItem('qr');
      arry1['qr'] = JSON.parse(qr);
      if (arry1.complete == 0) {
      arry1.numeral = arr.numeral;
      } else {

for (let i = 0; i < arry1.qLength; i ++) {
      let counted = arry1.maxNumeral[i];
			
			
						
				if (arry1.numeral[i] < counted) {
				
									arry1.numeral[i] = (arry1.numeral[i] +1);
				
								} else {
									arry1.numeral[i] = 0;
									
								}
							}
      }

      arry1.qAnsw.rightAndWrong = JSON.parse(sessionStorage.getItem(pg));
      console.log(arry1);
      saveToIndexedDB(arry1.db.sN, {id: JSON.stringify(arry1)}, arry1.db.ky, arry1.db.dN).then(function(resolve){
        
      }).catch(function(error){
        console.log(error);
      });
  
      
   
  
            
            (function(){
              
              
              
              
              let result = runOne(arry1, arry1.numeralOfRemoval);
  
              
  
              
              let $nextButton = $('#next');
                $nextButton.click(function(e) {
                  e.preventDefault()
                let $radio = [];
                for (let i = 0 ; i < arry1.qLength; i++) {
                  $radio[i] = $('.r'+i+'adio-button');
  
                }
                $questionsDiv = $('#questions');refresh
                $questionsDiv.html('');
                $('html,body').scrollTop(0);
                
  
                let runOrNot = 0;
                let pg = sessionStorage.getItem('pg')
                let qAnsw = JSON.parse(sessionStorage.getItem(pg));
  
                arry1.db = arr.db;
                arry = runTwo(arry1, $radio);
                let qr = arry['qr'];
               console.log(arry);
                  saveToIndexedDB(arry1.db.sN, {id: JSON.stringify(arry)}, arry1.db.ky, arry1.db.dN).then(function(resolve){
  
                  }).catch(function(error){
                    console.log(error);
                  });;
                
                  sessionStorage.setItem(pg, JSON.stringify(arry.qAnsw.rightAndWrong));
                  $resetButton = $('#reset');
                  $resetButton.click(function(event) {
                  let localstring = '/questionnaire.php?refresh=yes&page='+ pageNo;
                  if (arry1.complete == 1) { localstring += '&fast=yes'; }
                  window.location.replace(localstring)
                })
  
  
              });
  
  
  
  
  
  
              
            }());
  
     
  
        }).catch(function (error) {
  
  
  console.log(error);
  
      let reset = JSON.parse(sessionStorage.getItem('res'));
      
      console.log(reset);
      
      console.log(pageNo);
      
      if (reset[pageNo-1] == 1) {
        reset[pageNo-1] = 0;
        console.log('got here');
        arry1 = arryFirst;
        arry1.maxNumeral = arr['maxNumeral'];
        arry1.numeralOfRemoval = arryFirst.numeralOfRemoval;
        sessionStorage.setItem('res', JSON.stringify(reset));
        for (let i = 0; i < arry1.qLength; i++) {
          arry1.qAnsw.rightAndWrong['a'+i].right = 0;
          arry1.qAnsw.rightAndWrong['a'+i].wrong = 0;
          
        }
      }
      arry1.runs = 1;
     arry1.numeral = [];
     if (typeof arr['info'] != 'undefined') {
        for (let i = 0; i < arry1.qAnsw.length ; i++) {
  
          // arry.numeral[i] = 0;
          arry1.qr['a'+i] = 0;
          arry1.numeralOfRemoval = arr['numeralOfRemoval'];
  
        }
        // may need to put fast elsewhere;
  
        let counter = 0;
       ;
        for (var i = 0 ; i <= arry1.qLength-1; i++ ) {
  
          if (typeof arr['info'][i] != 'undefined') {
            for (var c = 1; c <= arr['maxNumeral'][i]+1; c++) {
              if ((c == arr['runs'])){
  
                arry1['a'+i][0][c-1] = arr['info'][i];
  
  
              }
            }
          }
        }
  
  
        arry1.numeral = arr['numeral'];
  
      }
  
  
      arry1['qr'] = {};
      for (let i = 0; i < arry1.qLength ; i++) {
  
        arry1['qr']['a'+i] = 0;
  
  
      }
  
  
  
  
  
  
  
      arry1.numeral = arr.numeral;
      console.log(arry1);
      console.log('arry1 above');
      sessionStorage.setItem(pg, JSON.stringify(arry1.qAnsw.rightAndWrong));
  
      saveToIndexedDB(arry1.db.sN, {id: JSON.stringify(arry1)}, arry1.db.ky, arry1.db.dN).then(function(resolve){
  
      }).catch(function(error){
        console.log(error);
      });
  
  
      (function(){
  
  
        var pg = sessionStorage.getItem('pg');
  
  
        arry1.qAnsw.rightAndWrong = JSON.parse(sessionStorage.getItem(pg));
        let result = runOne(arry1, arry1.numeralOfRemoval);
  
  
  
  
          let $nextButton = $('#next');
          $nextButton.click(function(e) {
          e.preventDefault()
          let $radio = [];
          for (let i = 0 ; i < arry1.qLength; i++) {
            $radio[i] = $('.r'+i+'adio-button');
  
          }
          $questionsDiv = $('#questions');
          $questionsDiv.html('');
          $('html,body').scrollTop(0);
  
          let runOrNot = 0;
          let removal = sessionStorage.getItem('removal');
  
          let pg = sessionStorage.getItem('pg')
          let qAnsw = JSON.parse(sessionStorage.getItem(pg));
  
          arry = runTwo(arry1, $radio);
          sessionStorage.setItem(pg, JSON.stringify(arry.qAnsw.rightAndWrong));
          console.log('arry below');
          console.log(arry);
          if (refresh == 'yes' || reset == 'yes' || newpg == 'yes') {
          saveToIndexedDB(arry1.db.sN, {id: JSON.stringify(arry)}, arry1.db.ky, arry1.db.dN).then(function(resolve){
  
          }).catch(function(error){
            console.log(error);
          });
          }
  
          $resetButton = $('#reset');
          $resetButton.click(function(event) {
            let localstring = '/questionnaire.php?refresh=yes&page='+ pageNo;
            if (arry1['complete'] == 1) { localstring += '&fast=yes'; }
            window.location.replace(localstring)
          })
  
  
        });
  
  
  
  
  
  
  
      }());
  
  
  
  
    });
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  }())