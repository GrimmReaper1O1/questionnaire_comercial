<?php
include "../src/bootstrap.php";
unset($_SESSION['runs']);
$page = $_GET['page'] ?? 1;
if (!isset($_SESSION['countedIds'])) {
$_SESSION['countedIds'] = $cms->getQuestions()->countQuestionIds();

$_SESSION['totalPages'] = ceil($_SESSION['countedIds']['count'] / $_SESSION['numberOfQuestionsOnPage']);
}

?>
<!DOCTYPE html>
<html>
<body style="background-color: blue;">
	<?= $_SESSION['version'] ?>
	<script type='module'>
		function openDB(storeName, databaseName){
			var dbRequest = indexedDB.open(databaseName);
			
			dbRequest.onupgradeneeded = function(event) {
				var db    = event.target.result;
				var data = {};
				var objectStore = {};
			<?php
			for ($i = 1 ; $i <= $_SESSION['totalPages'] ; $i++) {
				?>
				data = "QuestionnaireSubject<?= $_SESSION['subject'] ?>Class<?= $_SESSION['site']['cId'] ?>Page";
				data += <?= $i ?>;
				console.log(data);
				console.log(<?= $_SESSION['totalPages'] ?>)
				if (!db.objectStoreNames.contains("QuestionnaireSubject<?= $_SESSION['subject'] ?>Class<?= $_SESSION['site']['cId'] ?>Page<?= $i ?>")) {
				db.createObjectStore(data, {keypath: 'id'});

			}
			
			<?php
			}
			
			?>


		};

		dbRequest.onsuccess = function(event) {
			var db = event.target.result;
			db.close();
		}

		dbRequest.onerror = function(event) {
			reject(Error('Error text'));
		};

	};

	import {deleteDB, loadFromIndexedDB, updateDelDB, saveToIndexedDB, createStoreDB} from './script/load.js';
	var databaseName = "QuestionnaireClass<?= $_SESSION['site']['cId'] ?>S<?= $_SESSION['subject'] ?>";
	var key = "id";
	var storeName = "QuestionnaireSubject<?= $_SESSION['subject'] ?>Class<?= $_SESSION['site']['cId'] ?>Page<?= $page ?? 1?>"

	var version = localStorage.getItem("QuestionnaireSubject<?= $_SESSION['subject'] ?>Class<?= $_SESSION['site']['cId'] ?>");

	console.log(version);
	var test = 'on';
	var page = <?= $page ?? 1 ?>;
	if ( page == 1 && test == <?php if (isset($_SESSION['gate'])) {echo "'on'";} else {echo "'off'";} ?>) {
		sessionStorage.clear();
		var qr = {};
		for (let i = 0; i < <?= $_SESSION['numberOfQuestionsOnPage'] ?> ; i++) {

			qr[i] = 0;

		}

		var string = JSON.stringify(qr);
		console.log(string);
		sessionStorage.setItem('qr', string);
		<?php
		unset($_SESSION['cId'.$_SESSION['site']['cId']]['subject'.$_SESSION['subject']]);
		
		?>
	}
	if (version != <?= $_SESSION['version'] ?? 1 ?>) {
		localStorage.setItem("QuestionnaireSubject<?= $_SESSION['subject'] ?>Class<?= $_SESSION['site']['cId'] ?>",  "<?= $_SESSION['version'] ?? 1?>");
		console.log(version); console.log(<?= $_SESSION['version'] ?>)
		var test = 'on';
		var page = <?= $page ?? 1 ?>;
		if ( page == 1 && test == <?php if (isset($_SESSION['gate'])) {echo "'on'";} else {echo "'off'";} ?>) {
			sessionStorage.clear();
			var qr = {};
			for (let i = 0; i < <?= $_SESSION['numberOfQuestionsOnPage'] ?> ; i++) {

				qr[i] = 0;

			}

			var string = JSON.stringify(qr);
			console.log(string);
			sessionStorage.setItem('qr', string);
			<?php
			unset($_SESSION['cId'.$_SESSION['site']['cId']]['subject'.$_SESSION['subject']]);
		
			?>
		}

		deleteDB(databaseName);



		sessionStorage.setItem('start', 'on');

		await openDB(storeName, databaseName, version)

		window.location.replace('/questionnaire.php?reset=yes&page=<?= $page ?? 1 ?>');

	} else {

		var test = 'on';
		var page = <?= $page ?? 1 ?>;
		if ( page == 1 && test == <?php if (isset($_SESSION['gate'])) {echo "'on'";} else {echo "'off'";} ?>) {
			sessionStorage.clear();
			var qr = {};
			for (let i = 0; i < <?= $_SESSION['numberOfQuestionsOnPage'] ?> ; i++) {

				qr[i] = 0;

			}

			var string = JSON.stringify(qr);
			console.log(string);
			sessionStorage.setItem('qr', string);
			<?php
			unset($_SESSION['cId'.$_SESSION['site']['cId']]['subject'.$_SESSION['subject']]);
			
			?>
		}
		loadFromIndexedDB(storeName, key, databaseName).then(function (resolve) {
			let arry = resolve.id;
			arry = JSON.parse(arry);
			console.log(arry);



			if (arry.complete === 1) {

console.log('one');
				<?php if (isset($_SESSION['gate'])) {  ?>
					window.location.replace('/questionnaire.php?reset=yes&fast=yes&page=<?= $page ?? 1 ?>');	
<?php } else { ?>
				window.location.replace('/questionnaire.php?newpg=yes&fast=yes&page=<?= $page ?? 1 ?>');
		<?php } ?>
		
			} else {
console.log('two');
				<?php if (isset($_SESSION['gate'])) {  ?>
					window.location.replace('/questionnaire.php?reset=yes&page=<?= $page ?? 1 ?>&runs='+arry.runs);	
<?php } else { ?>
				window.location.replace('/questionnaire.php?newpg=yes&page=<?= $page ?? 1 ?>&runs='+arry.runs);
		<?php } ?>
			}}).catch(function (error){
console.log('three');
console.log(error);

				window.location.replace('/questionnaire.php?reset=yes&page=<?= $page ?? 1 ?>');
			});
		}



	</script>
</body>
</html>
