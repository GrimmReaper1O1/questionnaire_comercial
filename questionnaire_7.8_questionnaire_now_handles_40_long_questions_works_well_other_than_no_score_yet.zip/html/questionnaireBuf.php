<?php
include "../src/bootstrap.php";

$page = $_GET['page'] ?? 1;

$_SESSION['countedIds'] = $cms->getQuestions()->countQuestionIds();

$_SESSION['totalPages'] = ceil($_SESSION['countedIds']['count'] / $_SESSION['numberOfQuestionsOnPage']);


?>
<!DOCTYPE html>
<html>
<body style="background-color: blue;">
	<script type='module'>
	import {deleteDB, loadFromIndexedDB,  saveToIndexedDB, createStoreDB} from './script/load.js';
	console.log(<?= $_SESSION['version'] ?>);
	var databaseName = "QuestionnaireSubject<?= $_SESSION['subject'] ?>Class<?= $_SESSION['site']['cId'] ?>";

			let	storeName = "QuestionnaireSubject<?= $_SESSION['subject'] ?>Class<?= $_SESSION['site']['cId'] ?>Page<?= $_SESSION['page'] ?? 1 ?>";

	function openDB(storeName, databaseName){
		var dbRequest = indexedDB.open(databaseName);

		dbRequest.onupgradeneeded = function(event) {
			var db    = event.target.result;
			var data = {};
			var objectStore = {};
<?php
				for ($i = 1 ; $i <= $_SESSION['totalPages'] + 1 ; $i++) {
					?> if (!db.objectStoreNames.contains("QuestionnaireSubject<?= $_SESSION['subject'] ?>Class<?= $_SESSION['site']['cId'] ?>Page<?= $i ?>")) {
    db.createObjectStore("QuestionnaireSubject<?= $_SESSION['subject'] ?>Class<?= $_SESSION['site']['cId'] ?>Page<?= $i ?>", {keypath: 'id'}, );
}
<?php }
?>
request.onsuccess = function(event) {
console.log("Database opened successfully.");
};

request.onerror = function(event) {
console.error("Database error: " + event.target.error);
};



		};
}



	var key = "qS<?= $_SESSION['subject'] ?>C<?= $_SESSION['site']['cId'] ?>P<?= $page ?? 1?>";


	var version = JSON.parse(localStorage.getItem("S<?= $_SESSION['subject'] ?>C<?= $_SESSION['site']['cId'] ?>"));

	console.log(version);
	var test = 'on';
	var page = <?= $page ?? 1 ?>;
	if ( (page == 1) && (test == <?php if (isset($_SESSION['gate'])) {echo "'on'";} else {echo "'off'";} ?>)) {

console.log(page);


	<?php

		unset($_SESSION['gate']);
?>
	}
	if (version !== <?= $_SESSION['version']  ?>) {
		localStorage.setItem("S<?= $_SESSION['subject'] ?>C<?= $_SESSION['site']['cId'] ?>",  JSON.stringify(<?= $_SESSION['version'] ?? 1?>));
		console.log(version); console.log(<?= $_SESSION['version'] ?>)
		var test = 'on';
		var page = <?= $page ?? 1 ?>;
		if ( page == 1 && test == <?php if (isset($_SESSION['gate'])) {echo "'on'";} else {echo "'off'";} ?>) {

	<?php
			unset($_SESSION['gate']);
			?>
		}
 openDB(storeName, databaseName);
		saveToIndexedDB(storeName, {id: 'empty string'}, key, databaseName).then(function(resolve){
			console.log('completed save of empty string')
		}).catch(function(error){
			console.log(error);
		});



	console.log('one');



		window.location.replace('/questionnaire.php?reset=yes&page=<?= $page ?? 1 ?>');

	} else {

		var test = 'on';
		var page = <?= $page ?? 1 ?>;

		loadFromIndexedDB(storeName, key, databaseName).then(function (resolve) {
			let arry = resolve.id;
			arry = JSON.parse(arry);
			console.log(arry);



			if (arry['fast'] == 'yes') {


console.log('two');
				window.location.replace('/questionnaire.php?newpg=yes&fast=yes&page=<?= $page ?? 1 ?>');
			} else {
console.log('three');

window.location.replace('/questionnaire.php?reset=yes&page=<?= $page ?? 1 ?>');
			} }).catch(function (error){

console.log('four');
loadFromIndexedDB(storeName, key, databaseName).then(function (resolve) {
			let arry = resolve.id;
			arry = JSON.parse(arry);
			console.log(arry);



			if (arry['fast'] == 'yes') {


console.log('two');
				window.location.replace('/questionnaire.php?newpg=yes&fast=yes&page=<?= $page ?? 1 ?>');
			} else {
console.log('three');

// window.location.replace('/questionnaire.php?reset=yes&page=<?= $page ?? 1 ?>');
			} }).catch(function (error){

console.log('four');loadFromIndexedDB(storeName, key, databaseName).then(function (resolve) {
			let arry = resolve.id;
			arry = JSON.parse(arry);
			console.log(arry);



			if (arry['fast'] == 'yes') {


console.log('two');
				window.location.replace('/questionnaire.php?newpg=yes&fast=yes&page=<?= $page ?? 1 ?>');

			} else {
console.log('three');

window.location.replace('/questionnaire.php?reset=yes&page=<?= $page ?? 1 ?>');
			} }).catch(function (error){
				window.location.replace('/questionnaire.php?reset=yes&page=<?= $page ?? 1 ?>');
console.log(error);
console.log('four');
			});

			});
		});
}



	</script>
</body>
</html>
