
async function loadFromIndexedDB(storeName, key, database) {
  return new Promise((resolve, reject) => {
    const dbRequest = indexedDB.open(database);

    dbRequest.onerror = (event) => {
      console.error('Database error:', event);
      reject(Error('Database open failed'));

    };

    dbRequest.onupgradeneeded = (event) => {
      const db = event.target.result;
      if (!db.objectStoreNames.contains(storeName)) {
        db.createObjectStore(storeName, { keyPath: 'id', autoIncremovalent: true});
      }
      // Optionally reject if you want to stop loading when upgrade is needed

      reject(Error('Database upgrade needed'));
    };

    dbRequest.onsuccess = (event) => {
      const db = event.target.result;
      const transaction = db.transaction([storeName], 'readwrite');
      const objectStore = transaction.objectStore(storeName);
      const objectRequest = objectStore.get(key);

      objectRequest.onsuccess = (event) => {
        if (objectRequest.result) {

          setTimeout(() => (resolve(objectRequest.result)),);
        } else {
          reject(Error('No data found for key: ' + key));
        }
      };

      objectRequest.onerror = (event) => {
        console.error('Object request error:', event);
        reject(Error('Error retrieving object'));

      };

      transaction.onerror = (event) => {
        console.error('Transaction error:', event);

        reject(Error('Transaction failed'));
      };
    };
  });
}




async function updateDelDB(storeName, databaseName, version){
  var dbRequest = indexedDB.open(databaseName, version);

  dbRequest.onupgradeneeded = (event) => {
    var database    = event.target.result;

    database.createObjectStore(storeName, {keyPath: 'id', autoIncrement: true});



  };

  dbRequest.onsuccess = function(event) {

    var data = event.target.result;
    data.close();
  }

  dbRequest.onerror = function(event) {

  };

};


function openDB(storeName, databaseName){
  var dbRequest = indexedDB.open(databaseName);

  dbRequest.onupgradeneeded = function(event) {
    var database    = event.target.result;
    var objectStore = database.createObjectStore(storeName, { keyPath: 'id', autoIncrement: true });

  };

  dbRequest.onsuccess = function(event) {
    console.log('success');
  }

  dbRequest.onerror = function(event) {
    reject(Error('Error text'));
  };

};


function deleteDB(databaseName) {
  var db = indexedDB.deleteDatabase(databaseName);
  db.onsuccess = function (event) {



  }
  db.oncomplete = function (event) {
    var database = event.target.result;
    database.close();
  }

  db.onerror = function (event) {

  }
}

function createStoreDB(storeName, databaseName) {
  return new Promise((resolve, reject) => {
    var dbRequest = indexedDB.open(databaseName, 1); // Second argument is the version

    dbRequest.onupgradeneeded = function(event) {
      var db = event.target.result;

      // Check if the object store already exists to avoid recreating it
      if (!db.objectStoreNames.contains(storeName)) {
        db.createObjectStore(storeName, { keyPath: 'id', autoIncrement: true });
      }
    };

    dbRequest.onsuccess = function(event) {
      var database = event.target.result;
      resolve(database); // Resolve the Promise with the database instance
    };

    dbRequest.onerror = function(event) {
      reject(new Error('Error opening IndexedDB: ' + event.target.error));
    };
  });
}
function saveToIndexedDB(storeName, object, key, databaseName) {
  return new Promise(function(resolve, reject) {
    if (object.id === undefined) reject(Error('Object has no id.'));

    var dbRequest = indexedDB.open(databaseName);

    dbRequest.onerror = function(event) {
      reject(Error("IndexedDB database error"));
    };

    dbRequest.onupgradeneeded = function(event) {
      var database = event.target.result;

      // Create object store if it doesn't exist
      if (!database.objectStoreNames.contains(storeName)) {
        database.createObjectStore(storeName, { keyPath: 'id', autoIncrement: true });
      }
    };

    dbRequest.onsuccess = function(event) {
      var database = event.target.result;
      var transaction = database.transaction([storeName], 'readwrite');
      var objectStore = transaction.objectStore(storeName);
      var objectRequest = objectStore.put(object, key); // Overwrite if exists

      objectRequest.onerror = function(event) {
        reject(Error('Error saving data: ' + event.target.error));
      };

      objectRequest.onsuccess = function(event) {
        resolve('Data saved OK');
      };
    };
  });
}


export {loadFromIndexedDB, updateDelDB, saveToIndexedDB, openDB, deleteDB, createStoreDB};
