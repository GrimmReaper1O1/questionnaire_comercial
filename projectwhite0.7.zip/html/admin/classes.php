<?php 
include '../includes/header4.php';
if ($administrator['admin'] == 1) {
if (isset($_GET['page'])) {
$page = $_GET['page'];
$_SESSION['page'] = $page;
} else {$page = 1; }
$limit = 1;
$letter = $_GET['letter'] ?? 1;
$letterString = 'A B C D E F G H I J K L M N O P Q R S T U V W X Y Z';
$letterArray = preg_split('/[\s]+/', $letterString);
$error = '';
if (isset($_GET['unset'])) {
	unset($_SESSION['letter']);
	unset($_SESSION['search']);
	unset($_SESSION['new']);
	unset($_SESSION['updateClassName']);
	
	
	
}
if (isset($_GET['reset'])) {
	unset($_SESSION['subject']);
	unset($_SESSION['letter']);
	unset($_SESSION['search']);
	$_SESSION['new'] = 1;
	unset($_SESSION['updateClassName']);
	unset($_SESSION['classId']);
}
if (isset($_GET['updateClassName'])) {
	$_SESSION['updateClassName'] = $_GET['updateClassName'];
	
}
if (isset($_GET['desc'])) {
	$_SESSION['classId'] = $_GET['desc'];
}
if (isset($_POST['description'])) {

	
	if ($_POST['description'] != '') {
	$result = $cms->getQuestions()->updateClassDescription($_SESSION['classId'], $_POST['description']);
	if ($result == 1) {
		$error .= "THE UPDATE OF DESCRIPTION WAS SUCCESSFULL!<br>";
	}
	else
	{
		$error .= "FOR SOME REASON THE UPDATE OF DESCRIPTION WAS NOT SUCCESSFULL.<br>";
	}
	
	}
	
}
if (isset($_POST['name'])) {
	$result = $cms->getQuestions()->updateClassName($_SESSION['updateClassName'], $_POST['name']);
	
	if ($result > 0) {
		$error .= "THE UPDATE WAS SUCCESSFULL!";
		} else {
		$error .= "THE UPDATE WAS NOT SUCCESSFULL.";
		}
	}

if (isset($_GET['makeLive'])) {
	$result = $cms->getQuestions()->updateClassMakeLive($_GET['cid']);
	
	if ($result > 0) {
		$error .= "THE CLASS IS NOW LIVE!<br>";	
	} else { 
		$error .= "THE CLASS STILL IS NOT LIVE!<br>";
	}
	
}
if (isset($_GET['takeDown'])) {
	$result = $cms->getQuestions()->updateClassNotLive($_GET['cid']);
	
	if ($result > 0) {
		$error .= "THE CLASS HAS BEEN TAKEN DOWN!<br>";
} else {
		$error .= "THE CLASS HAS NOT BEEN TAKEN DOWN.<br>";
}

}

if (isset($_GET['letter'])) {
	$_SESSION['letter'] = $_GET['letter'];
	
}

if (isset($_SESSION['updateClassName']) || isset($_POST['name'])) {
	?>
	
	
	<?= $error ?><br>
	<a href="classes.php?reset=yes">BACK TO CLASSES</a><br>
	<form action="classes.php?updateClassName=<?= $_SESSION['updateClassName'] ?>" method="POST">
	<label for="name">Name:</label><br>
	<input type="text" name="name" value="<?= $_POST['name'] ?? '' ?>">
	<input type="submit" value="SUBMIT!">
	
	<?php
	
	
}



if((isset($_SESSION['new']) || isset($_SESSION['letter'])) && !isset($_POST['name']) && !isset($_SESSION['updateClassName'])) {


foreach($letterArray as $letters) { ?>
<?= "-" ?><a href="classes.php?unset=yes&letter=<?= $letters ?>"><?= $letters ?></a><?= "-" ?>
<?php
} ?>

<h1>Welcome to the administrative functions of questionnaire!</h1><br>
<h3><a href="classes.php?reset=yes">Please select the class you want to view via alphabetical order.</a><br> 
<a href="search_for_class.php">Or, search for a class.</a></h3><br><br>
<?php
echo $error;

}

if (isset($_GET['desc']) || isset($_POST['description'])) {
	
	?>  <?= $error ?><br>
		PLEASE ENTER THE NEW Description
		<a href="classes.php?reset=yes">BACK TO MAIN PAGE!</a>		
		<form action="classes.php" method="POST">
		<label for="description">ENTER NEW DESCRIPTION:</label><br>
		<input type="text" name="description" size="100"><br>
		<input type="submit" value="SUBMIT!">
		</form>
	<?php
	}




if (isset($_SESSION['letter']) && !isset($_SESSION['updateClassName']) && !isset($_POST['name'])) {
	$classesArray = $cms->getQuestions()->selectAllClassesViaLetter($page, $limit, $_SESSION['letter']);
echo $error;
	

}



if (isset($_SESSION['new']) && !isset($_SESSION['updateClassName']) && !isset($_POST['name'])) {
$classesArray = $cms->getQuestions()->selectAllClasses($page, $limit);
 
}

if (isset($classesArray[1])) {
if ($classesArray[0] != false) {
$totalResults = $classesArray[0]['count'];
$totalPages = ceil($totalResults / $limit);


foreach($classesArray[1] as $class) {
	?><?php if ( $class['live'] == 1 ) { echo "LIVE!<br>"; } else { echo "NOT LIVE!<br>"; } ?>
	<a href="classes.php?makeLive=yes&cid=<?= $class['class_id'] ?>">MAKE LIVE CLASS LIVE!</a><br>
	<a href="classes.php?takeDown=yes&cid=<?= $class['class_id'] ?>">TAKE DOWN CLASS!</a><br>
	<h4>Class:<br>
	<a href="adminSubjectsAndQuestionClassifications.php?unset=yes&class=<?= $class['class_id'] ?>"><?= $class['class_name'] ?></a></h4>
	<a href="classes.php?updateClassName=<?= $class['class_id'] ?>">UPDATE CLASS NAME</a><br><br>
	<a href="delete_class.php?class=<?= $class['class_id'] ?>">DELETE CLASS</a><br><br>
	<a href="classes.php?unset=yes&desc=<?= $class['class_id'] ?>">CHANGE DESCRIPTION</a><br>
	<h5>Description:</h5><br>
	<p><?php echo paragraph($class['description_of_class']); ?></p><br><br>
	
	
<?php 
}


echo "-";
for ($i = 1; $i <= $totalPages; $i++) {
    echo '<a href="classes.php?page=' . $i . '">' . $i . '</a> - ';
}

} }
	
} else {
    header("Location: how_dare_you.php");
    exit();
} ?>