<?php
include "../../includes/header5.php";
if ($administrator['admin'] == 1) {
$resultsPerPage = 1;

$letter = $_GET['letter'] ?? 1;
$f = 0;
$sF = 0;
$error = '';
$sA = 0;
$sD = 0;
$sT = 0;
$limit = 20;



if (isset($_GET['unset'])) {
unset($_SESSION['title']);
unset($_SESSION['authors']);
unset($_SESSION['description']);
unset($_SESSION['letter']);
unset($_SESSION['alphabet']);
unset($_SESSION['page']);
unset($_SESSION['class2']);
unset($_SESSION['class_id']);
}

if (isset($_GET['reset'])) {
unset($_SESSION['title']);
unset($_SESSION['authors']);
unset($_SESSION['description']);
unset($_SESSION['letter']);
unset($_SESSION['alphabet']);
unset($_SESSION['class_id']);
$_SESSION['alphabet'] = 1;

}



$_SESSION['page'] = isset($_GET['page']) ? $_GET['page'] : 1;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	if ($_POST['class'] == '') {
		$nC = 1;
		
	} 
}
	if (isset($_GET['class'])) {
		$_SESSION['class_id'] = $_GET['class'];
		
	}
	if (isset($_GET['letter'])) {

		$_SESSION['letter'] = $_GET['letter'];
	}
	
	if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	if ($_POST['title'] != '') {
		
		$_SESSION['title'] = $_POST['title'];
	
	}
	if ($_POST['author'] != "") {
		
		$_SESSION['authors'] = $_POST['author'];
	
	}
	if ($_POST['description'] != '') {
		
		$_SESSION['description'] = $_POST['description'];
	
	}
	if ($_POST['class'] != '') {
		
		$_SESSION['class2'] = $_POST['class'];
	
	}
	}
	if (isset($_SESSION['alphabet'])) {
		$array = $cms->getLibrary()->searchAlphabeticallyPaginationNC($limit);	
		$totalResults = $array[0]['count'];
		$totalPages = ceil($totalResults / $limit);
		
	}

    if (isset($_SESSION['letter'])) {
		$array = $cms->getLibrary()->searchViaLetterPaginationNC($limit);
		$totalResults = $array[0]['count'];
		$totalPages = ceil($totalResults / $limit);

	}



	if (isset($_SESSION['title'])) {
		if ($nC = 1) {
		$array = $cms->getLibrary()->selectTitleFromLibraryNC($limit);
		} else {
		$array = $cms->getLibrary()->selectTitleFromLibrary($limit);
		}
		$totalResults = $array[0]['count'];
		$totalPages = ceil($totalResults / $limit);
   
		

	}

	if (isset($_SESSION['authors'])) {
		if ($nC = 1) {	
		$array = $cms->getLibrary()->selectAuthorFromLibraryNC($limit);
		} else {
		$array = $cms->getLibrary()->selectAuthorFromLibrary($limit);
		}
		$totalResults = $array[0]['count'];
		$totalPages = ceil($totalResults / $limit);
	}

	if (isset($_SESSION['description'])) {
		if ($nC = 1) {
		$array = $cms->getLibrary()->selectDescriptionFromLibraryNC($limit);
		} else {
		$array = $cms->getLibrary()->selectDescriptionFromLibrary($limit);
		}
		$totalResults = $array[0]['count'];
		$totalPages = ceil($totalResults / $limit);
   
	}

	
	
	if (isset($_SESSION['class_id'])) {
	unset($_SESSION['class2']);
		$_SESSION['class'] = $_SESSION['class_id'];
	$array = $cms->getLibrary()->searchAlphabeticallyPagination($limit);
	
		$totalResults = $array[0]['count'];
		$totalPages = ceil($totalResults / $limit);
   

	}

if (isset($_SESSION['class2'])) {
			
		
		$array2 = $cms->getLibrary()->selectClassFromLibraryPagination($limit);
	
		$totalResults = $array2[0]['count'];
		$totalPages = ceil($totalResults / $limit);
   
		

	}












if ($_SERVER['REQUEST_METHOD'] === 'POST') {



if ($_POST['title'] != '' && $_POST['author'] != '' && $_POST['description'] == '') {
$f = 1;	
}
if ($_POST['title'] != '' && $_POST['author'] == '' && $_POST['description'] != '') {
$f = 1;
}
if ($_POST['title'] == '' && $_POST['author'] != '' && $_POST['description'] != '') {
$f = 1;
}
if ($_POST['title'] != '' && $_POST['author'] != '' && $_POST['description'] != '') {
$f = 1;
}



}







if (isset($array)) {
	if ($array == false) {
		$sF = 1;
	}
}

if (isset($array2)) {
	if ($array2 == false) {
		$sF = 1;
	}
}


$letterString = 'A B C D E F G H I J K L M N O P Q R S T U V W X Y Z';

$letterArray = preg_split('/[\s]+/', $letterString);




if ($f === 1) {
	$error .= "You can't search for more than one option. <br>";
	unset($array);
}

if ($sF === 1) {
	$error .= "There was a problem. The search failed to find anything. <br>";
	unset($array);
}



echo $error;
?>
<div>
 
<?php
foreach($letterArray as $letters) { ?>
<?= "-" ?><a href="adminLibrary.php?unset=yes&letter=<?= $letters ?>"><?= $letters ?></a><?= "-" ?>
<?php
} ?>
 <br><br>
<div id='main'>
<form action="adminLibrary.php?unset=yes" method="POST">
  <label for="classCheck">Use class from previous page:</label><input type="checkbox" name="classCheck"><br>
  <label for="class">Class name:</label><br>
  <input type="text" name="class" size="100"><br>
  <label for="title">Title:</label><br>
  <input type="text" name="title" size="100" value="<?= $_SESSION['title'] ?? '' ?>"><br>
  <label for="author">Author or authors:</label><br>
  <input type="text" name="author" size="100" value="<?= $_SESSION['authors'] ?? '' ?>"><br>
  <label for="description">Description:</label><br>
  <input type="text" name="description" size="100" value="<?= $_SESSION['description'] ?? '' ?>"><br>
<input type="submit" value="SUBMIT!">
</form>


<?php
if (isset($array)) {
	if ($array[1] != false) {
foreach($array[1] as $documents) { ?>
ID:<?= $documents['id'] ?><br>

<a href="<?= '../' . $documents['file_location']?>">VIEW DOCUMENT</a><br><br>
Title: <?= $documents['title'] ?><br><br>
Authors: <?= $documents['authors'] ?><br><br>
Description: <?php
$description = paragraph($documents['description']);
echo '<p>' . $description . '</p>'; ?><br><br>



<?php }
echo "-";
for ($i = 1; $i <= $totalPages; $i++) {
    echo '<a href="library.php?page=' . $i . '">' . $i . '</a> - ';
}
	}
} 

if (isset($array2)) {

	if ($array2[1] != false) {
foreach($array2[1] as $documents) { ?>

Class Name:<a href="adminLibrary.php?class=<?= $documents['class_id'] ?>"><?= $documents['class_name'] ?></a><br>


<?php }
echo "-";
for ($i = 1; $i <= $totalPages; $i++) {
    echo '<a href="library.php?page=' . $i . '">' . $i . '</a> - ';
}
	}
} 


?></div>
</div>
<?php
} else {
    header("Location: how_dare_you.php");
    exit();
}
