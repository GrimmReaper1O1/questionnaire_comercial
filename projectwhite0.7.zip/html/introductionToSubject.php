<?php
include "includes/header3.php";
if (isset($_GET['id'])) {
$id = $_GET['id'] ?? '';
$_SESSION['subject'] = $id;
}


if (isset($_GET['id'])) {
	$row = $cms->getQuestions()->selectSubjectViaTableIdAndClassId();
	$introduction = $row['introduction'] ?? '';
}
	?>
<h1><b>SUBJECT:</B> <a href="questionair.php?unset=yes&id=<?= $_SESSION['subject'] ?? '' ?>"><?= ' ' . $row['subject_information'] ?? '' ?></a></h1><br>
<?php echo '<p>' . paragraph($introduction) . '</p>'; ?>
<?php
for ($i = 1; $i <= 10; $i++) {
if ($row['link' . $i] != 'empty') {
	?>
		<a href="<?= $row['link' . $i] ?>"><?= $row['link_description' . $i] ?></a><br>
	<?php
}
}