<?php

for ($i = 0; $i < 4; $i++) {
	echo $i;
} 
echo "here";