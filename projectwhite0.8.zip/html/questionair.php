
<?php
include "includes/header3.php";
if (isset($_GET['reset'])) {
	unset($_SESSION['page']);
	
	
}
if  (isset($_GET['unset'])) {
unset($_SESSION['rowAndCounter']);
		}

$_SESSION['page'] = $_GET['page'] ?? 1;
if (isset($_GET['id'])) {
	$_SESSION['subject'] = $_GET['id'];
}
if (!isset($_SESSSION['rowAndCounter'])) {
	
$row = $cms->getQuestions()->selectSubjectViaTableIdAndClassId($_SESSION['subject']);
$counter = $cms->getQuestions()->countQuestionIdsViaSubjectAndClass();
$_SESSION['rowAndCounter']['row'] = $row;
$_SESSION['rowAndCounter']['counter'] = $counter;

}
if ($_SESSION['rowAndCounter']['row'] != false) {
	if ($_SESSION['rowAndCounter']['row']['number_of_questions'] == 2) {
		$_SESSION['number_of_questions'] = $row['number_of_questions'];
	}

}

if ($_SESSION['rowAndCounter']['row'] != false) {
	if(isset($_SESSION['rowAndCounter']['row']['number_of_questions'])) {
		$limit = $_SESSION['rowAndCounter']['row']['number_of_questions'];	
	} else {
		$limit = 3;
	}
	if(isset($_SESSION['rowAndCounter']['row']['number_of_removal'])) {
		$numberOfRemoval = $_SESSION['rowAndCounter']['row']['number_of_removal'];
	} else {
		$numberOfRemoval = 4;
	}

}




//if (isset($x)) {

if (isset($_SESSION['page_question_count']) && isset($_POST['submit2'])) {
	for($i = 0; $i < $_SESSION['page_question_count']; $i++) {
		
		for($c = 0; $c < $_SESSION['number_of_questions'] + 1; $c++) {
			if (isset($_POST[$i . 'a' . $c])) {
				echo "<b>Message:</b><br>";
				echo "<p>" . paragraph($_SESSION[$i .'answ' . $c]) . "</p><br>";
				echo "<b>Quesiton:</b><br>";
				echo "<p>" . paragraph($_SESSION[$i .'question']) . "</p><br>";
				echo "<b>Answer chosen:</b><br>";
				echo "<p>" . paragraph($_SESSION[$i .'pa' . $c]) . "</p><br>";
				echo "<b>Hint given:</b><br>";
				echo "<p>" . paragraph($_SESSION[$i .'hint' . $c]) . "</p><br><br>";
				
			if ($_SESSION[$i . 'correct'] == 'answ' . $c && isset($_POST[$i . 'a' . $c])) {	
				$_SESSION['question' . $i]++;
			}
			
	
			}
		}
	} ?>

<form action-"questionair.php" method='POST'>
<input type="submit" name='submit' value="AGAIN!">
</form>


<?php
}







if ((isset($_POST['submit']) || isset($_GET['unset']))) {
	
	
	$_SESSION['number_of_questions'] = $_SESSION['rowAndCounter']['row']['number_of_questions'];
	
	if (isset($_GET['unset'])) {
		 
	$questionDesc = $cms->getQuestions()->selectAllQuestionsFromSubjectPagination($_SESSION['page'], $limit);
	$_SESSION['questionDesc'] = $questionDesc;
	
	}
	

	

	if  (isset($_GET['unset'])) {
		$_SESSION['page_question_count'] = count($_SESSION['questionDesc'][1]);
		echo count($_SESSION['questionDesc'][1]);
		for($c = 0; $c < $limit; $c++) {
			unset($_SESSION['lastNum' . $c]); 
		}
		if (isset($_GET['unset'])) {
					for($i = 0; $i < $limit; $i++) {
					unset($_SESSION['question' . $i]);
					
					}
		for($c = 0; $c < $limit; $c++) {
			$_SESSION['lastNum' . $c] = $c;
			$_SESSION['question' . $c] = 0;
		}
	
		}
	
}


	if ($_SESSION['questionDesc'][1] != false) {

?>

<form action="questionair.php" method="POST">

<?php

		for($c = 0; $c < $limit; $c++) {

			
			if (isset($_SESSION['questionDesc'][1][$c])) {
				if (isset($_GET['unset'])) {
					unset($_SESSION['count'][$c]);
				}
				
			if (!isset($_SESSION['count']['$c'])) {
				
			$_SESSION['count'][$c] = $cms->getQuestions()->countNumberOfQuestions($_SESSION['questionDesc'][1][$c]['question_id']);
			}
			$count1 = $_SESSION['count'][$c]['count'];
			$totalPages = ceil(($_SESSION['rowAndCounter']['counter']['count'] / $limit));
			$info = $cms->getQuestions()->selectQuestion($_SESSION['questionDesc'][1][$c]['question_id'], $count1, $_SESSION['lastNum' . $c]);
			$_SESSION['lastNum' . $c] = $info[0]['offset'];
			$_SESSION['description' . $c] = $_SESSION['questionDesc'][1][$c]['description'];
		
			if ($info[1] != false) {  
			if (isset($info[1]['question'])) { ?>	
<?php 
				echo $_SESSION['question' .$c];
				if ($_SESSION['question' . $c] < $numberOfRemoval) {
						echo "<p>" . $info[1]['question'] . "</p>" ?><br>
				
<?php			
						$_SESSION[$c . 'question'] = $info[1]['question'];
						$_SESSION[$c . 'correct'] = $info[1]['correct'];
				
					for($i = 1; $i <= 8; $i++) {

						if ($info[1]['pa' . $i] != 'empty') {
?>

<input type="radio" name="<?= $c . "a" . $i ?>"> <p>
<?php 
							echo paragraph($info[1]['pa' . $i]); ?></p>

<?php 
						}	
	
						if ($info[1]['hint' . $i] != 'empty') { echo paragraph($info[1]['hint' . $i]); } ?></p>	
<?php 
							$_SESSION[$c .'answ' . $i] = $info[1]['answ' . $i];
							$_SESSION[$c . 'pa' . $i] = $info[1]['pa' . $i];
							$_SESSION[$c . 'hint' . $i] = $info[1]['hint' . $i];
							
						}
					}
				?> 
				
<br><br>
			<?php				
			}else { 
 
						echo "There is no question information assigned to question ID:" . $questionDesc[1][$c]['question_id'];

					}
					} 
		}
		}
	 

?> 

<input type="submit" name="submit2" value="SUBMIT!">
</form>
<form action="questionair.php?unset=yes&page=<?= $_SESSION['page'] ?>" method="POST">
				<input type="submit" value="RESET PAGE!">
				</form>
		<?php		
	// if ($infFalse > 0) {		echo "There is no quesiton information assigned.";}
for($i = 1; $i <= $totalPages; $i++){
?>
<a href="questionair.php?unset=yes&page=<?= $i ?>"><?= $i ?>-</a>
<?php
}
}
}

//}