<?php 
include '../../includes/header5.php';
if ($administrator['admin'] == 1) {
if ($_SERVER["REQUEST_METHOD"] === "POST") {
$firstName = $_POST['firstName'] ? $_POST['firstName'] : NULL;
$lastName = $_POST['lastName'] ? $_POST['lastName'] : NULL;

$email = $_POST['email'] ? $_POST['email'] : NULL;
if ($email != NULL && $firstName == NULL && $lastName == NULL) {
$array = $cms->getMember()->selectViaEmailArray($email);    
if ($array == false) {
    echo "THERE WAS A PROBLEM THE INFORAMTION COULD NOT BE FOUND.";
}
}
if ($email == NULL && $firstName != NULL && $lastName != NULL) {
$array = $cms->getMember()->selectViaFirstLastName($firstName, $lastName);    
if ($array == false) {
    echo "THERE WAS A PROBLEM. THE INFORMATION COULD NOT BE FOUND.";
}
}
if ($email != NULL && ($firstName != NULL || $lastName != NULL)) {
	echo "YOU MAY NOT ENTER EITHER NAMES AND EMAIL TOGETHER.";
}
if ($email == NULL && $firstName == NULL && $lastName != NULL) {
	$array = $cms->getMember()->selectAdminViaLastName($lastName);
	
}
}

?>
<form action="search_via_email.php" method="POST">
<label name="email">EMAIL:<label><input type="text" name="email"><br>
<label name="firstName">FIRST NAME:<label>
<input type="type" name="firstName"><br>
<label name="lastName">LAST NAME:<label>
<input type="type" name="lastName"><br>
<input type="submit" value="SUBMIT!"><br>
<br><br>
<?php

if (isset($array)) {
	foreach($array as $info) {
	?>
	EMAIL:<?= $info['email'] ?><br>
	FULL NAME:<?= $info['concat_full_name'] ?><br>
	PHONE NUMBER:<?= $info['phone_number'] ?><br>
<br>
<br>
<?php	
	}
	
}

} else {
    header("Location: how_dare_you.php");
    exit();
}