
<?php
include "../../includes/header5.php";

if ($administrator['admin'] == 1) {
?>

    <?php if ($administrator['admin'] == 10) { ?>
    <a href="allow_entry_to_users.php">Allow entry to users</a><br>
    <?php }?>
    <?php if ($administrator['admin'] == 10) { ?>
    <a href="assign_user_to_new_class.php">Assign user to a new class</a><br>
    <?php }   ?>
    <?php if ($administrator['admin'] == 1 || $administrator['can_delete_all'] == 10) { ?>
    <a href="createAdministrator.php">Create administrative account</a><br>
    <?php } ?>
    <?php if ($administrator['admin'] == 1) { ?>
    <a href="create_new_class.php">Create new class</a><br>
	<?php }   ?>
	<?php if ($administrator['admin'] == 10) { ?>
    <a href="create_user_and_assign_class.php">Create user and assign class</a><br>
    <?php }   ?>
    <?php if ($administrator['can_remove_class'] == 1 || $administrator['root'] == 1) { ?>
    <a href="delete_class.php">Delete class</a><br>
	
	<?php }   ?>
    <?php if ($administrator['admin'] == 1 || $administrator['root'] == 1) { ?>
    
	<a href="../adminLibrary/delete_document.php?unset=yes">Delete document</a><br>
	
	   <?php }   ?>
    <?php if ($administrator['admin'] == 10) { ?>
	
	<a href="delete_subject_from_class.php">Delete subject from class</a><br>
    <?php }   ?>
    <?php if ($administrator['admin'] == 10) { ?>
    <a href="delete_user_from_class.php">Delete user</a><br>
    <?php }   ?>
    <?php if ($administrator['admin'] == 1) { ?>
    <a href="../adminLibrary/adminLibrary.php?unset=yes">Admin Library</a><br>
    
    <?php }	?>
    <?php if ($administrator['admin'] == 10) { ?>

  
	 <a href="search_for_user.php">Search for user in classes</a><br>
 

    <?php }
    if ($administrator['admin'] == 1) { ?>
    <a href="show_all_administrators.php">Show all administrators</a><br>
    <?php }   ?>

    <?php if ($administrator['root'] == 1) { ?>

    <?php }   ?>
    <?php if ($administrator['root'] == 1) { ?>

    <?php }   ?>
 
  
    <?php if ($administrator['admin'] == 1) { ?>

    <?php }   ?>
    <?php if ($administrator['admin'] == 1) { ?>
    <a href="search_via_email.php">Search via name or email</a><br>
    <a href="../adminLibrary/upload_pdf.php">Upload a pdf, docx, or doc file to the library</a><br>
    <?php  }?>



<?php
include "../../includes/footer.php";
} else {
    header("Location: how_dare_you.php");
    exit();
}
