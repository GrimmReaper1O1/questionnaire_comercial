<?php
include "../includes/header4.php";
for ($i = 1; $i <= 10; $i++) {
$link['a' . $i] = $_POST['link' . $i] ?? 'empty';
$description['a' . $i] = $_POST['description' . $i] ?? 'empty';
if ($link['a' . $i] == '') {
	$link['a' . $i] = 'empty' ;
}
if ($description['a' . $i] == '') {
	$description['a' . $i] = 'empty' ;
}
}
$subjectDescription = $_POST['subjectDescription'] ?? 'empty';
$numberOfQuestions = $_POST['numberOfQuestions'] ?? '4';
$failureInsert = 0;
$failureFound = 0;
$failureUpdate = 0;
$success = 0;
$failure = 0;
$failureLength = 0;
$failureNumber = 0;
if (isset($_GET['info'])) {
	$_SESSION['info'] = $_GET['info'];
}
if (isset($_GET['id'])) {
	$_SESSION['subject'] = $_GET['id'];
	echo $_SESSION['subject'];
	}
if (isset($_GET['id']) || isset($_SESSION['subject']) || isset($_POST['subjectName']) || isset($_GET['update'])) {
	
	$row = $cms->getQuestions()->selectSubjectViaTableIdAndClassId();
	$introduction = $row['introduction'] ?? '';

}

if (isset($_POST['numberOfQuestions'])) {
				if ($_POST['numberOfQuestions'] >= 2 && $_POST['numberOfQuestions'] <= 8) {
		
		$result = $cms->getQuestions()->updateSubjectsInitial($_POST['subjectName'], $numberOfQuestions,
		$link['a1'], $link['a2'], $link['a3'], $link['a4'], $link['a5'], $link['a6'], $link['a7'], $link['a8'], 
		$link['a9'], $link['a10'], $description['a1'], $description['a2'], $description['a3'], $description['a4'], 
		$description['a5'], $description['a6'], $description['a7'], $description['a8'], $description['a9'], $description['a10'], 
		$subjectDescription);
	if ($result > 0) {
		echo "<h4>THE UPDATE WAS SUCCESSFULL!</h4><br>";
		$success = 1;		
		$_SESSION['subjectQuestions'] = $_POST['numberOfQuestions'];
	
		} else { 
			echo "<h4>THE UPDATE WAS NOT SUCCESSFULL.</h4><br>";
			$failure = 1;
		}
			} else { $failureNumber = 1; }
			
}
	
		




if ((isset($_POST['subjectName']) && $success == 0 && ($failure == 1 || $failureNumber == 1 
		|| $failureFound == 1 || $failureLength == 1)) || isset($_GET['update'])) {
		
			if ($failureFound == 1) {
			echo "<h4>THE SUBJECT NAME WAS ALREADY ENTERED PREVIOUSLY.</h4>";
		}   if ($failureLength == 1) {
			echo "<h4>THE SUBJECT NAME MUST BE FILLED.</h4>";
		}
			if ($failureNumber == 1) {
			echo "<h4>THERE WAS A FAILURE TO UPLOAD THE NUMBER OF REMOVAL.</h4>";
			}
			
		
		?>	<form action="introductionToSubject.php?unset=yes" method="POST">
			<input type="submit" value="RETURN TO SELECTION!">
			<form action="introductionToSubject.php" method="POST">
			<label for="subjectName">PLEASE ENTER THE SUBJECT NAME.</label><br>
			<input type="text" name="subjectName" value="<?= $row['subject_information'] ?? '' ?>" size="100"><br>
			<label for="subjectDescription">Subject description:</label><br>	
			<textarea rows='40' cols='80' name='subjectDescription'><?= $row['introduction'] ?? "" ?></textarea><br>
			<label for="numberOfQuestions">PLEASE ENTER THE NUMBER OF QUESTIONS<BR>
			DISPLAYED ON EACH PAGE OF THE QUESTIONAIR.<br>
			DO NOT ENTER LESS THAN TWO OR<br>
			MORE THAN EIGHT.<br>
			</label>
			<input type="number" name="numberOfQuestions" value="<?= $row['number_of_questions'] ?? '' ?>" size="1"><br>
			<label for="removeQuestion">PLEASE ENTER THE NUMBER WHICH DICTATES<BR>
			THE REMOVAL OF QUESTIONS UPON COMPLETION.<br>
			</label>
			<input type="number" name="removeQuestion" value="<?= $row['number_of_removal'] ?? '' ?>" size="2"><br>		
			<?php
			
			for($i = 1; $i <= 10; $i++) {
			?>
			<label for="link<?= $i ?>">Please enter the link <?= $i ?>:</lable><br>
			<input type="text" name="link<?= $i ?>" value="<?php if(isset($row['link' . $i])) { if($row['link' . $i] != 'empty') { echo $row['link' . $i]; } }?>"><br>
			<label for="description<?= $i ?>">Please enter the description <?= $i ?? '' ?>:</lable><br>
			<textarea rows='15' cols='80' name='description<?= $i ?>'><?php if(isset($row['link' . $i])) { if($row['link_description' . $i] != 'empty') { echo $row['link_description' . $i]; } } ?></textarea><br>
				<?php
			}
			if ($failureNumber == 1) {
				echo "<h4>THE NUMBER MUST BE BETWEEN OR EQUAL TO TWO TO EIGHT.</H4>";
			}?>
		
			<input type="submit" value="SUBMIT!">
			</form>
		
			<?php
		}
	







if ((isset($_SESSION['info']) ||  isset($_POST['unset']) || !isset($_POST['subjectName'])) && !isset($_GET['update'])) {
	
	?>
	<a href="introductionToSubject.php?update=yes">UPDATE PAGE!</a><br>
<h1><b>SUBJECT:</B> <a href="adminSubjectsAndQuestionClassifications.php?info=<?= $_SESSION['info'] ?? '' ?>&id=<?= $_SESSION['subject'] ?? '' ?>"><?= $row['subject_information'] ?? '' ?></a></h1><br>



<?php echo '<p>' . paragraph($introduction) . '</p>'; ?>
<?php
for ($i = 1; $i <= 10; $i++) {
if ($row['link' . $i] != 'empty') {
	?>
		<a href="<?= $row['link' . $i] ?>"><?= $row['link_description' . $i] ?></a><br>
	<?php
}
}
}