<?php
namespace MySite\CMS;
class CMS
{
    public $db        = null;                   // Stores reference to Database object
    public $database = null;
    public $questions = null;
    public $token = null;
    public $member = null;
 
    
    public function __construct($dsn, $uid, $pass)
    {
        
        $this->db = new Database($dsn, $uid, $pass); // Create Database object
        
    }
  

    public function getToken()
    {
        if($this->token === null) {
            $this->token = new Token($this->db);
        }
        return $this->token;
    }
    public function getQuestions()
    {
        if($this->questions === null) {
            $this->questions = new Questions($this->db);
        }
        return $this->questions;
    }
    public function getMember()
    {
        if($this->member === null) {
            $this->member = new Member($this->db);
        }
        return $this->member;
    }

}
