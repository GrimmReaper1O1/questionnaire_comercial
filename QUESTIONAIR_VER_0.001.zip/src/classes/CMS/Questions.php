<?php
namespace MySite\CMS;                                   // Declare namespace

class Questions
{
protected $db;
public function __construct(Database $db)
{
    $this->db = $db;
}
	public function selectAllFromSubjects() {
		$sql = "select table_id, subject_information from tables";
		return $this->db->runSql($sql)->fetchAll();
	}
	public function selectSubjectViaTableId($tableId) {
		$arguments['tableId'] = $tableId;
		$sql = "select * from tables where table_id like :tableId";
		return $this->db->runSql($sql, $arguments)->fetch();
	}
	public function selectSubjectViaSubjectName($name) {
		$arguments['name'] = $name;
		$sql = "select * from tables where subject_information like :name";
		return $this->db->runSql($sql, $arguments)->fetch();	
	}
	public function updateSubjects($subject, $id) {
		$arguments['entry'] = $subject;
		$arguments['id'] = $id;
		$sql = "update tables set subject_information = :entry where table_id like :id";
		return $this->db->runSql($sql, $arguments)->rowCount();
	}
	public function updateSubjectsInitial($subject, $id, $numberOfQuestions) {
		$arguments['entry'] = $subject;
		$arguments['id'] = $id;
		$arguments['number'] = $numberOfQuestions;
		$sql = "update tables set subject_information = :entry, number_of_questions = :number where table_id like :id";
		return $this->db->runSql($sql, $arguments)->rowCount();
	}
	public function selectQuestionViaDescription($id, $description) {
		$arguments['description'] = $description;
		$arguments['id'] = $id;
		$sql = "select * from question_ids where table_id like :id and description like :description";
		return $this->db->runSql($sql, $arguments)->fetch();
	}
	public function insertQuestionDescription($tableId, $description){
		$arguments['id'] = $tableId;
		$arguments['description'] = $description;
		$sql = "insert into question_ids (table_id, description) values (:id, :description)";
		return $this->db->runSql($sql, $arguments);
	}
	public function selectQuestions($id, $page, $limit) {
		$arguments['id'] = $id;
		$sql = "select count(*) as count from (select t.subject_information, q.question_id, q.table_id, q.description from question_ids ";
		$sql .= "q inner join tables t on t.table_id = q.table_id where q.table_id like :id) t";
		$results[0] = $this->db->runSql($sql, $arguments)->fetch();
		$offset = ($page - 1) * $limit;
		$limit = strval($limit);
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$limit = preg_replace($patterns, $replacements, $limit);
		$sql = "select * from (select t.subject_information, q.question_id, q.table_id, q.description from question_ids ";
		$sql .= "q inner join tables t on t.table_id = q.table_id where q.table_id like :id) t order by question_id ";
		$sql .= "offset " . $offset . " rows fetch next " . $limit . " rows only";
		$results[1] = $this->db->runSql($sql, $arguments)->fetchAll();
		return $results;
	}
	
	public function insertQuestion($tableNumber, $question, $pa1, $pa2, $pa3, $pa4, $pa5, $pa6, $pa7, $pa8,
	$answ1, $answ2, $answ3, $answ4, $answ5, $answ6, $answ7, $answ8, $correctAnsw, $questionId,
	$hint1, $hint2, $hint3, $hint4, $hint5, $hint6, $hint7, $hint8) {
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$tableNumber = preg_replace($patterns, $replacements, $tableNumber);
		$arguments['question'] = $question;
		$arguments['pa1'] = $pa1;
		$arguments['pa2'] = $pa2;
		$arguments['pa3'] = $pa3;
		$arguments['pa4'] = $pa4;
		$arguments['pa5'] = $pa5;
		$arguments['pa6'] = $pa6;
		$arguments['pa7'] = $pa7;
		$arguments['pa8'] = $pa8;
		$arguments['answ1'] = $answ1;
		$arguments['answ2'] = $answ2;
		$arguments['answ3'] = $answ3;
		$arguments['answ4'] = $answ4;
		$arguments['answ5'] = $answ5;
		$arguments['answ6'] = $answ6;
		$arguments['answ7'] = $answ7;
		$arguments['answ8'] = $answ8;
		$arguments['correct'] = $correctAnsw;
		$arguments['questionId'] = $questionId;
		$arguments['hint1'] = $hint1;
		$arguments['hint2'] = $hint2;
		$arguments['hint3'] = $hint3;
		$arguments['hint4'] = $hint4;
		$arguments['hint5'] = $hint5;
		$arguments['hint6'] = $hint6;
		$arguments['hint7'] = $hint7;
		$arguments['hint8'] = $hint8;
		
		$sql = "insert into question_information" . $tableNumber . " (question, pa1, pa2, pa3, pa4, pa5, pa6, pa7, pa8, ";
		$sql .= "answ1, answ2, answ3, answ4, answ5, answ6, answ7, answ8, correct, question_id, hint1, hint2, hint3, ";
		$sql .= " hint4, hint5, hint6, hint7, hint8) values ";
		$sql .= "(:question, :pa1, :pa2, :pa3, :pa4, :pa5, :pa6, :pa7, :pa8, :answ1, :answ2, :answ3, :answ4, :answ5, ";
		$sql .= ":answ6, :answ7, :answ8, :correct, :questionId, :hint1, :hint2, :hint3, :hint4, :hint5, :hint6, :hint7, :hint8)";
		return $this->db->runSql($sql, $arguments);
	}
	public function updateQuestion($id, $tableNumber, $question, $pa1, $pa2, $pa3, $pa4, $pa5, $pa6, $pa7, $pa8,
	$answ1, $answ2, $answ3, $answ4, $answ5, $answ6, $answ7, $answ8, $correctAnsw, $questionId,
	$hint1, $hint2, $hint3, $hint4, $hint5, $hint6, $hint7, $hint8) {
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$tableNumber = preg_replace($patterns, $replacements, $tableNumber);
		$arguments['question'] = $question;
		$arguments['id'] = $id;
		$arguments['pa1'] = $pa1;
		$arguments['pa2'] = $pa2;
		$arguments['pa3'] = $pa3;
		$arguments['pa4'] = $pa4;
		$arguments['pa5'] = $pa5;
		$arguments['pa6'] = $pa6;
		$arguments['pa7'] = $pa7;
		$arguments['pa8'] = $pa8;
		$arguments['answ1'] = $answ1;
		$arguments['answ2'] = $answ2;
		$arguments['answ3'] = $answ3;
		$arguments['answ4'] = $answ4;
		$arguments['answ5'] = $answ5;
		$arguments['answ6'] = $answ6;
		$arguments['answ7'] = $answ7;
		$arguments['answ8'] = $answ8;
		$arguments['correct'] = $correctAnsw;
		$arguments['questionId'] = $questionId;
		$arguments['hint1'] = $hint1;
		$arguments['hint2'] = $hint2;
		$arguments['hint3'] = $hint3;
		$arguments['hint4'] = $hint4;
		$arguments['hint5'] = $hint5;
		$arguments['hint6'] = $hint6;
		$arguments['hint7'] = $hint7;
		$arguments['hint8'] = $hint8;
		$sql = "update question_information" . $tableNumber . " set question = :question, pa1 = :pa1, pa2 = :pa2, pa3 = :pa3, ";
		$sql .= "pa4 = :pa4, pa5 = :pa5, pa6 = :pa6, pa7 = :pa7, pa8 = :pa8, answ1 = :answ1, answ2 = :answ2, answ3 = :answ3, ";
		$sql .= "answ4 = :answ4, answ5 = :answ5, answ6 = :answ6, answ7 = :answ7, answ8 = :answ8, correct = :correct, ";
		$sql .= "question_id = :questionId, hint1 = :hint1, hint2 = :hint2, hint3 = :hint3, hint4 = :hint4, hint5 = :hint5, ";
		$sql .= "hint6 = :hint6, hint7 = :hint7, hint8 = :hint8 where id like :id";
		return $this->db->runSql($sql, $arguments)->rowCount();
	}
	public function selectQuestion($questionNumber) {
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$_SESSION['subject'] = preg_replace($patterns, $replacements, $_SESSION['subject']);
		$arguments['questionId'] = $questionNumber;
		$sql = "select count(*) as count from question_information" . $_SESSION['subject'];
		$sql .= " where question_id like :questionId";
		$count = $this->db->runSql($sql, $arguments)->fetch();
		$offset = rand(0, $count['count'] - 1);


		$sql = "select * from question_information" . $_SESSION['subject'];
		$sql .= " where question_id like :questionId order by id offset $offset rows fetch next 1 rows only";
		return $this->db->runSql($sql, $arguments)->fetch();
	}
	public function selectQuestionViaQuestion($question, $questionId, $subjectId) {
		$arguments['question'] = $question;
		$arguments['questionId'] = $questionId;
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$subjectId = preg_replace($patterns, $replacements, $subjectId);
		$sql = "select * from question_information" . $subjectId . " where question like :question and question_id like :questionId";
		return $this->db->runSql($sql, $arguments)->fetch();
}
		public function selectQuestioninformation($questionId, $page, $limit, $subjectId) {
		$arguments['questionId'] = $questionId;
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$limit = strval($limit);
		
		
		$sql = "select count(*) as count from (select * from question_information" . $subjectId;
		$sql .= " where question_id like :questionId) t";
		$results[0] = $this->db->runSql($sql, $arguments)->fetch();
		$offset = ($page - 1) * $limit;
		
		
		$limit = preg_replace($patterns, $replacements, $limit);
		$sql = "select * from (select s.id, s.question, s.question_id, s.correct, s.pa1, s.pa2, s.pa3, s.pa4, s.pa5, s.pa6, s.pa7, s.pa8, ";
		$sql .= "s.answ1, s.answ2, s.answ3, s.answ4, s.answ5, s.answ6, s.answ7, s.answ8, ";
		$sql .= "s.hint1, s.hint2, s.hint3, s.hint4, s.hint5, s.hint6, s.hint7, s.hint8, q.description from question_information" . $subjectId;
		$sql .= " s left outer join question_ids q on s.question_id = q.question_id ";
		$sql .= "where q.question_id like :questionId) t order by question_id ";
		$sql .= "offset " . $offset . " rows fetch next " . $limit . " rows only";
		$results[1] = $this->db->runSql($sql, $arguments)->fetchAll();
		return $results;
	}
	public function updateSubjectsTable($id) {
		$arguments['id'] = $id;
		$sql = "update tables set subject_information = 'empty', number_of_questions = null where table_id like :id";
		return $this->db->runSql($sql, $arguments)->rowCount();
	}
	public function deleteQuestionIds($id) {
		$arguments['id'] = $id;
		$sql = "delete from question_ids where table_id like :id";
		return $this->db->runSql($sql, $arguments)->rowCount();
	}
	public function deleteAllEntriesFromQuesitonInformation($subjectId) {
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$subjectId = preg_replace($patterns, $replacements, $subjectId);
		$sql = "delete from question_information" . $subjectId;
		return $this->db->runSql($sql)->rowCount();
}
	public function selectQuestionViaQuestionId($id, $subjectId) {
		$arguments['id'] = $id;
		$patterns[0] = '/;/';
		$patterns[1] = '/go/';
		$replacements[0] = '';
		$replacements[1] = '';
		$subjectId = preg_replace($patterns, $replacements, $subjectId);
		$sql = "select * from question_information" . $subjectId . " where id like :id";
		return $this->db->runSql($sql, $arguments)->fetch();
	}

}