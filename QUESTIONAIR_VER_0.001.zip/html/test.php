<?php
include "../src/bootstrap.php";
$_SESSION['subject'] = '1';
$entry = $cms->getQuestions()->selectQuestion(1);
echo $entry['question'];