<?php
include "../../src/bootstrap.php";
$subjectsArray = $cms->getQuestions()->selectAllFromSubjects();
$page = $_GET['page'] ?? 1;
$limit = 10;
if (isset($_GET['unset'])) {
	unset($_SESSION['subject']);
}
if (isset($_GET['id']) || isset($_SESSION['subject'])) {
if (isset($_GET['id'])) {
$_SESSION['subject'] = $_GET['id'];
}
$questions = $cms->getQuestions()->selectQuestions($_SESSION['subject'], $page, $limit);
$totalQuestions = $questions[0]['count'];
$totalPages = ceil($totalQuestions / $limit);
echo '<a href="adminSubjectsAndQuestionClassifications.php?unset=yes">BACK TO MAIN ADMINISTRATIVE PAGE!</a><br>';
echo "<h1>" . $questions[1][0]['subject_information'] . "</h1><br>";
foreach($questions[1] as $question) {

	?>
	<h4>ID: <?= $question['question_id'] ?></h4><br>
	<h3>DESCRIPTION OF QUESTION:</h3><br>
	<h4><p><a href="questionsAndAnswers.php?id=<?= $question['question_id'] ?>"><?= $question['description'] ?></a></p></h4><br><br><br>

<?php
} echo "-";
for($i = 1; $i <= $totalPages; $i++){
?>
<a href="adminSubjectsAndQuestionClassifications.php?page=<?= $i ?>"><?= $i ?>-</a>
<?php
}
} else {
echo "<h1>SELECT THE SUBJECT TO ALTER</h1><br>";	
	
foreach($subjectsArray as $subjects) {
	?>
	<h4>ID: <?= $subjects['table_id'] ?> </h4><br>
	<h3>SUBJECT: <?php if ($subjects['subject_information'] != 'empty') 
	{ ?><a href="adminSubjectsAndQuestionClassifications.php?id=<?= $subjects['table_id'] ?>"><?= $subjects['subject_information'] ?></a>
<br> <a href="fillQuestionair.php?id=<?= $subjects['table_id'] ?>">ADD QUESTIONS OR ALTER SUBJECT NAME.</a>
	<?php }	else { echo '<br> <a href="fillQuestionair.php?id=' . $subjects['table_id'] . '">FILL SUBJECT!</a>'; } 
	if ($subjects['subject_information'] != 'empty') {?></h3>
	<a href="deleteAllQuestionsFromSubject.php?id=<?= $subjects['table_id'] ?>">DELETE ALL INFORMATION FROM TABLE ABOVE!</a><br><br><br>
	<?php
}
}
}