<?php 
include '../../src/bootstrap.php';
$id = $_GET['id'] ?? 'no';

if ($id != 'no') {
	$result = $cms->getQuestions()->deleteAllEntriesFromQuesitonInformation($id);
	$result2 = $cms->getQuestions()->deleteQuestionIds($id);
	$result3 = $cms->getQuestions()->updateSubjectsTable($id);
	if ($result > 0) {
		echo "<h4>ALL ENTRIES WERE DELETED FROM THE QUESTION INFORMATION TABLE IN SUBJECT!</h4><br>";
	} else {
		echo "<h4>THERE WAS A PROBLEM DELETING THE QUESTION INFORMAITON FROM THE TABLE.<br>PLEASE TRY AGAIN.</h4>";
	}
	if ($result2 > 0) {
		echo "<h4>ALL QUESTION DESCRIPTIONS WERE DELETED!</h4><br>";
	} else {
		echo "<h4>THERE WAS A PROBLEM DELETING THE QUESTION DESCRIPTIONS.<br>PLEASE TRY AGAIN.</h4>";
	}
    if ($result3 > 0) {
		echo "<h4>ALL SUBJECTS WERE RESET TO EMPTY!</h4><br>";
	} else {
		echo "<h4>THERE WAS A PROBLEM UPDATING THE SUBJECTS TO EMPTY. <br>PLEASE TRY AGAIN.</h4>";
	}
}
?>
<br><a href="adminSubjectsAndQuestionClassifications.php">CLICK HERE TO GO BACK TO THE ADMINISTRATIVE SUBJECTS PAGE!</a>