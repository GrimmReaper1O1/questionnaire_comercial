<?php 
include '../../src/bootstrap.php';
$page = $_GET['page'] ?? 1;
$limit = 2;

if (isset($_GET['id']) || isset($_SESSION['questionId'])) {
if (isset($_GET['id'])) {
$_SESSION['questionId'] = $_GET['id'];
}
$questions = $cms->getQuestions()->selectQuestionInformation($_SESSION['questionId'], $page, $limit, $_SESSION['subject']);
$totalQuestions = $questions[0]['count'];
$totalPages = ceil($totalQuestions / $limit);
echo '<a href="adminSubjectsAndQuestionClassifications.php?unset=yes">BACK TO MAIN ADMINISTRATIVE PAGE!</a><br>';
if (isset($questions[1][0])) {
echo "<h1>" . $questions[1][0]['description'] . "</h1><br>";
foreach($questions[1] as $question) {

	?>
	
	<h3>CORRECT ANSWER:</h3><br><?= $question['correct'] ?><br>
	<h3>QUESTION:</h3><br><p><?php echo paragraph($question['question']) ?> </p><br>
	<h3>POSSIBLE ANSWER ONE:</h3><br><?php echo paragraph($question['pa1']) ?> </p><br>
	<h3>ANSWER:</h3><br><?php echo paragraph($question['answ1']) ?> </p><br>
	<h3>HINT:</h3><br><?php echo paragraph($question['hint1']) ?> </p><br>
	<h3>POSSIBLE ANSWER TWO:</h3><br><?php echo paragraph($question['pa2']) ?> </p><br>
	<h3>ANSWER:</h3><br><?php echo paragraph($question['answ2']) ?> </p><br>
	<h3>HINT:</h3><br><?php echo paragraph($question['hint2']) ?> </p><br>
	<?php if ($question['pa3'] !== 'empty') { ?>
	<h3>POSSIBLE ANSWER THREE:</h3><br><?php echo paragraph($question['pa3']) ?> </p><br>
	<h3>ANSWER:</h3><br><?php echo paragraph($question['answ3']) ?> </p><br>
	<h3>HINT:</h3><br><?php echo paragraph($question['hint3']) ?> </p><br>
	<?php } if ($question['pa4'] != 'empty') { ?>
	<h3>POSSIBLE ANSWER FOUR:</h3><br><?php echo paragraph($question['pa4']) ?> </p><br>
	<h3>ANSWER:</h3><br><?php echo paragraph($question['answ4']) ?> </p><br>
	<h3>HINT:</h3><br><?php echo paragraph($question['hint4']) ?> </p><br>
	<?php } if ($question['pa5'] != 'empty') { ?>
	<h3>POSSIBLE ANSWER FIVE:</h3><br><?php echo paragraph($question['pa5']) ?> </p><br>
	<h3>ANSWER:</h3><br><?php echo paragraph($question['answ5']) ?> </p><br>
	<h3>HINT:</h3><br><?php echo paragraph($question['hint5']) ?> </p><br>
	<?php } if ($question['pa6'] != 'empty') { ?>
	<h3>POSSIBLE ANSWER SIX:</h3><br><?php echo paragraph($question['pa6']) ?> </p><br>
	<h3>ANSWER:</h3><br><?php echo paragraph($question['answ6']) ?> </p><br>
	<h3>HINT:</h3><br><?php echo paragraph($question['hint6']) ?> </p><br>
	<?php } if ($question['pa7'] != 'empty') { ?>
	<h3>POSSIBLE ANSWER SEVEN:</h3><br><?php echo paragraph($question['pa7']) ?> </p><br>
	<h3>ANSWER:</h3><br><?php echo paragraph($question['answ7']) ?> </p><br>
	<h3>HINT:</h3><br><?php echo paragraph($question['hint7']) ?> </p><br>
	<?php } if ($question['pa8'] != 'empty') { ?>
	<h3>POSSIBLE ANSWER EIGHT:</h3><br><?php echo paragraph($question['pa8']) ?> </p><br>
	<h3>ANSWER:</h3><br><?php echo paragraph($question['answ8']) ?> </p><br>
	<h3>HINT:</h3><br><?php echo paragraph($question['hint8']) ?> </p><br>
	<?php } ?>
	<h4><p><a href="updateQuestionAndAnswers.php?id=<?= $question['id'] ?>">UPDATE QUESTION!</a></p></h4><br><br><br>

<?php
} echo "-";
for($i = 1; $i <= $totalPages; $i++){
?>
<a href="questionsAndAnswers.php?page=<?= $i ?>"><?= $i ?>-</a>
<?php
}
}
}