<?php
include '../../src/bootstrap.php';
$result = $cms->getQuestions()->test();
print_r($result);