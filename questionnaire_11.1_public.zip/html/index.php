<?php
include "../src/bootstrap.php";
include "includes/header6.php";
?>
<h1><p>Welcome to Questionair.</p></h1>

<img src="images/plants dancing.jpg">


<?php
